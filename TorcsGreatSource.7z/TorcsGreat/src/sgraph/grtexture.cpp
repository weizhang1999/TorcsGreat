/***************************************************************************

    file                 : grtexture.cpp
    created              : Wed Jun 1 14:56:31 CET 2005
    copyright            : (C) 2005 by Bernhard Wymann
    version              : $Id: grtexture.cpp,v 1.2.2.1 2012/06/06 13:56:39 berniw Exp $

***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/*
	This classes/methods are used to handle texture compression and
	textures which are shared among multiple objects. In the long term
	they should obsolete parts of grutil.cpp.
*/

#include "grtexture.h"
#include "android_jni.h"

//int grManagedState::ms = 0;

bool doMipMap(const char* tfname, int mipmap)
{
	char* buf = (char*)malloc(strlen(tfname)+1);
	strcpy(buf, tfname);

	// find the filename extension.
	char* s = strrchr(buf, '.');
	if(s) {
		*s = 0;
	}

	// search for the texture parameters.
	s = strrchr(buf, '_');

	// no mipmap for "_n" and "shadow".
	if(s) {
		// check the "_n".
		if(strncmp(s, "_n", 4) == 0) {
			mipmap = FALSE;
		}
	}

	if(mipmap == TRUE) {
		// Check the shadow.
		s = strrchr((char*)tfname, '/');
		if(s == NULL) {
			s = (char*)tfname;
		} else {
			s++;
		}
		if(strstr(s, "shadow") != NULL) {
			mipmap = FALSE;
		}
	}
	free(buf);
	return mipmap;
}


/*
	The latter parts are derived from plib (plib.sf.net) and have this license:

	PLIB - A Suite of Portable Game Libraries
	Copyright (C) 1998,2002  Steve Baker

	This library is free software; you can redistribute it and/or
	modify it under the terms of the GNU Library General Public
	License as published by the Free Software Foundation; either
	version 2 of the License, or (at your option) any later version.

	This library is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	Library General Public License for more details.

	You should have received a copy of the GNU Library General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA

	For further information visit http://plib.sourceforge.net
*/

/*
	Modifications:
		Copyright (c) 2005 Bernhard Wymann
*/


// SGI texture loading function.
bool grLoadSGI(const char* fname, ssgTextureInfo* info)
{
//	LogError("inside grLoadSGI: fname = %s (success)", fname); // TODO: delete later
	grSGIHeader* sgihdr = new grSGIHeader(fname, info);
	bool returnval = sgihdr->loadSGI_bool;
	delete sgihdr;
	return returnval;
}

grSGIHeader::grSGIHeader(const char* fname, ssgTextureInfo* info)
{
	grSGIHeader* sgihdr = this;

	start = NULL;
	leng = NULL;

	bool success = openFile(fname);

	int mipmap = doMipMap(fname, TRUE);

	if(!success) {
		loadSGI_bool = false;
		return;
	}

	info->pImage = new GLubyte[sgihdr->xsize*sgihdr->ysize*sgihdr->zsize];
	GLubyte* ptr = info->pImage;

	unsigned char* rbuf = new unsigned char[sgihdr->xsize];
	unsigned char* gbuf = (sgihdr->zsize > 1) ? new unsigned char[sgihdr->xsize] : (unsigned char*)NULL;
	unsigned char* bbuf = (sgihdr->zsize > 2) ? new unsigned char[sgihdr->xsize] : (unsigned char*)NULL;
	unsigned char* abuf = (sgihdr->zsize > 3) ? new unsigned char[sgihdr->xsize] : (unsigned char*)NULL;

	for(int y = 0; y < sgihdr->ysize; y++) {
		int x;

		switch(sgihdr->zsize) {
			case 1:
				sgihdr->getRow(rbuf, y, 0);
				for(x = 0; x < sgihdr->xsize; x++) {
					*ptr++ = rbuf[x];
				}
				break;

			case 2:
				sgihdr->getRow(rbuf, y, 0);
				sgihdr->getRow(gbuf, y, 1);

				for(x = 0; x < sgihdr->xsize; x++) {
					*ptr++ = rbuf[x];
					*ptr++ = gbuf[x];
				}
				break;

			case 3:
				sgihdr->getRow(rbuf, y, 0);
				sgihdr->getRow(gbuf, y, 1);
				sgihdr->getRow(bbuf, y, 2);

				for(x = 0; x < sgihdr->xsize; x++) {
					*ptr++ = rbuf[x];
					*ptr++ = gbuf[x];
					*ptr++ = bbuf[x];
				}
				break;

			case 4:
				sgihdr->getRow(rbuf, y, 0);
				sgihdr->getRow(gbuf, y, 1);
				sgihdr->getRow(bbuf, y, 2);
				sgihdr->getRow(abuf, y, 3);

				for(x = 0; x < sgihdr->xsize; x++) {
					*ptr++ = rbuf[x];
					*ptr++ = gbuf[x];
					*ptr++ = bbuf[x];
					*ptr++ = abuf[x];
				}
				break;
		}
	}

	fclose(image_fd);
	image_fd = NULL;
	delete[] rbuf;
	delete[] gbuf;
	delete[] bbuf;
	delete[] abuf;

	if(info != NULL) {
		info->width = sgihdr->xsize;
		info->height = sgihdr->ysize;
		info->depth = sgihdr->zsize;
		info->alpha = (sgihdr->zsize == 2 || sgihdr->zsize == 4);
	}

	bool result = grMakeMipMaps(info->pImage, sgihdr->xsize, sgihdr->ysize, sgihdr->zsize, mipmap);
//	LogError("inside grSGIHeader: fname = %s result = %d", fname, result); // TODO: delete later

	loadSGI_bool = result;
}


bool grMakeMipMaps(GLubyte* image, int xsize, int ysize, int zsize, bool mipmap)
{
	if((xsize&(xsize-1)) != 0 || (ysize&(ysize-1)) != 0) {
		ulSetError(UL_WARNING, "Map is not a power-of-two in size!");
		return false;
	}

	auto eFormat = (zsize == 1) ? GL_LUMINANCE : (zsize == 2) ? GL_LUMINANCE_ALPHA : (zsize == 3) ? GL_RGB : GL_RGBA;
//	if(eFormat == GL_LUMINANCE) LogInfo("inside grMakeMipMaps eFormat == GL_LUMINANCE"); // TODO: delete later
//	if(eFormat == GL_RGB) LogInfo("inside grMakeMipMaps eFormat == GL_RGB"); // TODO: delete later
	if(mipmap) {
		ax_Build2DMipmaps(eFormat, (GLenum)eFormat, xsize, ysize, image);
	} else {
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); // The magnification filter can't specify the use of mipmaps
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexImage2D(GL_TEXTURE_2D, 0, eFormat, xsize, ysize, FALSE, (GLenum)eFormat, GL_UNSIGNED_BYTE, image);
		checkGlError("grMakeMipMaps: glTexImage2D");
	}
//	delete[] image; // TODO: delete later (check where is memory is freed)
	return true;
}
