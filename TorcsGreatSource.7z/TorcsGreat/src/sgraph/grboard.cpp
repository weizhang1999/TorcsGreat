/***************************************************************************

    file                 : grboard.cpp
    created              : Thu Aug 17 23:52:20 CEST 2000
    copyright            : (C) 2000-2017 by Eric Espie, Bernhard Wymann
    email                : torcs@free.fr
    version              : $Id: grboard.cpp,v 1.27.2.11 2017/02/13 22:57:17 berniw Exp $

 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/


#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <ssg.h>
#include <portability.h>

#include "grcam.h"
#include "grboard.h"
#include "grssgext.h"
#include "grshadow.h"
#include "grskidmarks.h"
#include "grsmoke.h"
#include "grcar.h"
#include "grmain.h"
#include "grutil.h"
#include <robottools.h>
#include <tgfclient.h>

#include "grboard.h"

static float grWhite[4] = {1.0, 1.0, 1.0, 1.0};
static float grRed[4] = {1.0, 0.0, 0.0, 1.0};
static float grBlue[4] = {0.0, 0.0, 1.0, 1.0};
static float grGreen[4] = {0.0, 1.0, 0.0, 1.0};
static float grBlack[4] = {0.0, 0.0, 0.0, 1.0};
static float grDefaultClr[4] = {0.9, 0.9, 0.15, 1.0};

#define NB_BOARDS  3
#define NB_LBOARDS 3

static float Winx = 0;
static float Winw = 800;
static float Winy = 0;
static float Winh = 600;

cGrBoard::cGrBoard(int myid)
{
	id = myid;
	trackMap = NULL;
	Winw = grWinw*600/grWinh;
}


cGrBoard::~cGrBoard()
{
	trackMap = NULL;
}


void cGrBoard::loadDefaults(tCarElt* curCar)
{
	const int BUFSIZE = 1024;
	char path[BUFSIZE];
	snprintf(path, BUFSIZE, "%s/%d", GR_SCT_DISPMODE, id);

	debugFlag = (int)GfParmGetNum(grHandle, path, GR_ATT_DEBUG, NULL, 1);
	boardFlag = (int)GfParmGetNum(grHandle, path, GR_ATT_BOARD, NULL, 2);
	leaderFlag = (int)GfParmGetNum(grHandle, path, GR_ATT_LEADER, NULL, 1);
	leaderNb = (int)GfParmGetNum(grHandle, path, GR_ATT_NBLEADER, NULL, 10);
	counterFlag = (int)GfParmGetNum(grHandle, path, GR_ATT_COUNTER, NULL, 1);
	GFlag = (int)GfParmGetNum(grHandle, path, GR_ATT_GGRAPH, NULL, 1);
	arcadeFlag = (int)GfParmGetNum(grHandle, path, GR_ATT_ARCADE, NULL, 0);

	trackMap->setViewMode((int)GfParmGetNum(grHandle, path, GR_ATT_MAP, NULL, trackMap->getDefaultViewMode()));

	if(curCar->_driverType == RM_DRV_HUMAN) {
		snprintf(path, BUFSIZE, "%s/%s", GR_SCT_DISPMODE, curCar->_name);
		debugFlag = (int)GfParmGetNum(grHandle, path, GR_ATT_DEBUG, NULL, debugFlag);
		boardFlag = (int)GfParmGetNum(grHandle, path, GR_ATT_BOARD, NULL, boardFlag);
		leaderFlag = (int)GfParmGetNum(grHandle, path, GR_ATT_LEADER, NULL, leaderFlag);
		leaderNb = (int)GfParmGetNum(grHandle, path, GR_ATT_NBLEADER, NULL, leaderNb);
		counterFlag = (int)GfParmGetNum(grHandle, path, GR_ATT_COUNTER, NULL, counterFlag);
		GFlag = (int)GfParmGetNum(grHandle, path, GR_ATT_GGRAPH, NULL, GFlag);
		arcadeFlag = (int)GfParmGetNum(grHandle, path, GR_ATT_ARCADE, NULL, arcadeFlag);
		trackMap->setViewMode((int)GfParmGetNum(grHandle, path, GR_ATT_MAP, NULL, trackMap->getViewMode()));
	}
}


void cGrBoard::selectBoard(int val)
{
	const int BUFSIZE = 1024;
	char path[BUFSIZE];
	snprintf(path, BUFSIZE, "%s/%d", GR_SCT_DISPMODE, id);

	switch(val) {
		case 0:
			boardFlag = (boardFlag+1)%NB_BOARDS;
			GfParmSetNum(grHandle, path, GR_ATT_BOARD, (char*)NULL, (tdble)boardFlag);
			break;
		case 1:
			counterFlag = (counterFlag+1)%NB_BOARDS;
			GfParmSetNum(grHandle, path, GR_ATT_COUNTER, (char*)NULL, (tdble)counterFlag);
			break;
		case 2:
			leaderFlag = (leaderFlag+1)%NB_LBOARDS;
			GfParmSetNum(grHandle, path, GR_ATT_LEADER, (char*)NULL, (tdble)leaderFlag);
			break;
		case 3:
			debugFlag = 1-debugFlag;
			GfParmSetNum(grHandle, path, GR_ATT_DEBUG, (char*)NULL, (tdble)debugFlag);
			break;
		case 4:
			GFlag = 1-GFlag;
			GfParmSetNum(grHandle, path, GR_ATT_GGRAPH, (char*)NULL, (tdble)GFlag);
			break;
		case 5:
			arcadeFlag = 1-arcadeFlag;
			GfParmSetNum(grHandle, path, GR_ATT_ARCADE, (char*)NULL, (tdble)arcadeFlag);
			break;
	}
	GfParmWriteFile(NULL, grHandle, "graph");
}


void cGrBoard::grDispDebug(float fps, tCarElt* car, tSituation* s)
{
	const int BUFSIZE = 256;
	char buf[BUFSIZE];

	int x = Winx+Winw-100;
	int y = Winy+Winh-30;

	snprintf(buf, BUFSIZE, "FPS: %.1f", fps);
	GfuiPrintString(buf, grRed, GFUI_FONT_LARGE_C, x, y, GFUI_ALIGN_HL_VB);
	bool bHuman = car->_driverType == RM_DRV_HUMAN;
	GfuiPrintString(car->_name, bHuman ? grWhite : grDefaultClr, GFUI_FONT_LARGE, Winx+Winw-25, 23, GFUI_ALIGN_HR_VB);
	snprintf(buf, BUFSIZE, "Lap: %d/%d (%s)", car->_laps, s->_totLaps, bHuman ? "human" : "robot");
	GfuiPrintString(buf, bHuman ? grWhite : grDefaultClr, GFUI_FONT_LARGE, Winx+Winw-25, 3, GFUI_ALIGN_HR_VB);

/*
	tRoadCam* curCam;

	curCam = car->_trkPos.seg->cam;

	y -= 15;
	snprintf(buf, BUFSIZE, "Seg: %s", car->_trkPos.seg->name);
	GfuiPrintString(buf, grWhite, GFUI_FONT_SMALL_C, x, y, GFUI_ALIGN_HL_VB);
	y -= 15;
	if(curCam) {
		snprintf(buf, BUFSIZE, "Cam: %s", curCam->name);
		GfuiPrintString(buf, grWhite, GFUI_FONT_SMALL_C, x, y, GFUI_ALIGN_HL_VB);
		y -= 15;
	}
*/
}

void cGrBoard::grDispGGraph(tCarElt* car)
{
//	LogInfo("inside GrBoard::grDispGGraph: car->index = %d", car->index); // TODO: delete later
	float X1, Y1, X2, Y2, xc, yc;

	X1 = (float)(Winx+Winw-100);
	Y1 = (float)(Winy+100);
	xc = (float)(Winx+Winw-30);
	yc = (float)(Y1-50);

	X2 = -car->_DynGC.acc.y/9.81f*25.0f+X1;
	Y2 = car->_DynGC.acc.x/9.81f*25.0f+Y1;
	glColor4f(1.0, 1.0, 1.0, 1.0);
	GLfloat vertices0[] = {X1-50, Y1, X1+50, Y1, X1, Y1-50, X1, Y1+50, xc, yc, xc, yc+100};
	GfDrawLine(vertices0, 6);

	const float THNSS = 2.0f;

	glColor4f(0.0, 0.0, 1.0, 1.0);
	GfDrawRect({X1-THNSS, Y1, X1+THNSS, Y1, X1-THNSS, Y1+car->ctrl.accelCmd*50.0f, X1+THNSS, Y1+car->ctrl.accelCmd*50.0f});

	GfDrawRect({X1-THNSS, Y1-car->ctrl.brakeCmd*50.0f, X1+THNSS, Y1-car->ctrl.brakeCmd*50.0f, X1-THNSS, Y1, X1+THNSS, Y1});

	GfDrawRect({X1-car->ctrl.steer*50.0f, Y1-THNSS, X1, Y1-THNSS, X1-car->ctrl.steer*50.0f, Y1+THNSS, X1, Y1+THNSS});

	GfDrawRect({xc-THNSS, yc, xc+THNSS, yc, xc-THNSS, yc+car->ctrl.clutchCmd*100.0f, xc+THNSS, yc+car->ctrl.clutchCmd*100.0f});

	glColor4f(1.0, 0.0, 0.0, 1.0);
	GLfloat vertices5[] = {X1, Y1, X2, Y2};
	GfDrawLine(vertices5, 2);
}


void cGrBoard::grDrawGauge(tdble X1, tdble Y1, tdble H, float* clr1, float* clr2, tdble val, const char* title)
{
	tdble curH;

	curH = MIN(val, 1.0f);
	curH = MAX(curH, 0.0f);
	curH *= H;

	const float THNSSBG = 2.0f;
	const float THNSSFG = 2.0f;
	const float THNSSBF = (THNSSBG+THNSSFG);
	glColor4fv(grBlack);
	GfDrawRect({X1-THNSSBF, Y1-THNSSBG, X1+THNSSBF, Y1-THNSSBG, X1-THNSSBF, Y1+H+THNSSBG, X1+THNSSBF, Y1+H+THNSSBG});

	glColor4fv(clr2);
	GfDrawRect({X1-THNSSFG, Y1+curH, X1+THNSSFG, Y1+curH, X1-THNSSFG, Y1+H, X1+THNSSFG, Y1+H});

	glColor4fv(clr1);
	GfDrawRect({X1-THNSSFG, Y1, X1+THNSSFG, Y1, X1-THNSSFG, Y1+curH, X1+THNSSFG, Y1+curH});
	GfuiPrintString(title, grBlue, GFUI_FONT_MEDIUM, (int)X1, (int)(Y1-THNSSBG-GfuiFontHeight(GFUI_FONT_MEDIUM)), GFUI_ALIGN_HC_VB);
}

void cGrBoard::grDispMisc(tCarElt* car)
{
	float* clr;

	if(car->_fuel < 5.0f) {
		clr = grRed;
	} else {
		clr = grWhite;
	}

	tdble fw = Winw/800.0f;

	grDrawGauge(545.0f*fw, 20.0f*fw, 80.0f, clr, grBlack, car->_fuel/car->_tank, "F");
	grDrawGauge(560.0f*fw, 20.0f*fw, 80.0f, grRed, grGreen, (tdble)(car->_dammage)/grMaxDammage, "D");
}

void cGrBoard::grDispCarBoard1(tCarElt* car, tSituation* s)
{
	float x, x2, y;
	const int BUFSIZE = 256;
	char buf[BUFSIZE];
	float* clr;
	float dy, dy2, dx;

	x = 10;
	x2 = 110;
	dy = GfuiFontHeight(GFUI_FONT_MEDIUM_C);
	dy2 = GfuiFontHeight(GFUI_FONT_SMALL_C);
	y = Winy+Winh-dy-5;
	snprintf(buf, BUFSIZE, "%d/%d - %s", car->_pos, s->_ncars, car->_name);
	dx = GfuiFontWidth(GFUI_FONT_MEDIUM_C, buf);
	dx = MAX(dx, (x2-x));

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glColor4f(0.1, 0.1, 0.1, 0.8);
	GfDrawRect({x-5, y+dy, x-5, y-5-dy2*9, x+dx+5, y+dy, x+dx+5, y-5-dy2*9});
	glDisable(GL_BLEND);

	GfuiPrintString(buf, grCarInfo[car->index].iconColor, GFUI_FONT_MEDIUM_C, x, y, GFUI_ALIGN_HL_VB);
	y -= dy;

	dy = GfuiFontHeight(GFUI_FONT_SMALL_C);

	GfuiPrintString("Fuel:", grWhite, GFUI_FONT_SMALL_C, x, y, GFUI_ALIGN_HL_VB);
	if(car->_fuel < 5.0) {
		clr = grRed;
	} else {
		clr = grWhite;
	}
	snprintf(buf, BUFSIZE, "%.1f l", car->_fuel);
	GfuiPrintString(buf, clr, GFUI_FONT_SMALL_C, x2, y, GFUI_ALIGN_HR_VB);
	y -= dy;

	if(car->_state&RM_CAR_STATE_BROKEN) {
		clr = grRed;
	} else {
		clr = grWhite;
	}

	GfuiPrintString("Damage:", clr, GFUI_FONT_SMALL_C, x, y, GFUI_ALIGN_HL_VB);
	snprintf(buf, BUFSIZE, "%d", car->_dammage);
	GfuiPrintString(buf, clr, GFUI_FONT_SMALL_C, x2, y, GFUI_ALIGN_HR_VB);
	y -= dy;
	clr = grWhite;

	GfuiPrintString("Laps:", clr, GFUI_FONT_SMALL_C, x, y, GFUI_ALIGN_HL_VB);
	snprintf(buf, BUFSIZE, "%d / %d", car->_laps, s->_totLaps);
	GfuiPrintString(buf, clr, GFUI_FONT_SMALL_C, x2, y, GFUI_ALIGN_HR_VB);
	y -= dy;

	GfuiPrintString("Total:", clr, GFUI_FONT_SMALL_C, x, y, GFUI_ALIGN_HL_VB);
	grWriteTime(clr, GFUI_FONT_SMALL_C, x2, y, s->currentTime, 0);
	y -= dy;

	GfuiPrintString("Curr:", clr, GFUI_FONT_SMALL_C, x, y, GFUI_ALIGN_HL_VB);
	if(!car->_commitBestLapTime) {
		clr = grRed;
	}
	grWriteTime(clr, GFUI_FONT_SMALL_C, x2, y, car->_curLapTime, 0);
	y -= dy;
	clr = grWhite;

	GfuiPrintString("Last:", clr, GFUI_FONT_SMALL_C, x, y, GFUI_ALIGN_HL_VB);
	grWriteTime(clr, GFUI_FONT_SMALL_C, x2, y, car->_lastLapTime, 0);
	y -= dy;

	GfuiPrintString("Best:", clr, GFUI_FONT_SMALL_C, x, y, GFUI_ALIGN_HL_VB);
	grWriteTime(clr, GFUI_FONT_SMALL_C, x2, y, car->_bestLapTime, 0);
	y -= dy;

	GfuiPrintString("Penalty:", clr, GFUI_FONT_SMALL_C, x, y, GFUI_ALIGN_HL_VB);
	grWriteTime(clr, GFUI_FONT_SMALL_C, x2, y, car->_penaltyTime, 0);
	y -= dy;

	GfuiPrintString("Top Speed:", clr, GFUI_FONT_SMALL_C, x, y, GFUI_ALIGN_HL_VB);
	snprintf(buf, BUFSIZE, "%d", (int)(car->_topSpeed*3.6));
	GfuiPrintString(buf, clr, GFUI_FONT_SMALL_C, x2, y, GFUI_ALIGN_HR_VB);
}

void cGrBoard::grDispCarBoard2(tCarElt* car, tSituation* s)
{
	float x, x2, x3, y;
	const int BUFSIZE = 256;
	char buf[BUFSIZE];
	float* clr;
	float dy, dy2, dx;
	int i;

	x = 10;
	x2 = 110;
	x3 = 186;
	dy = GfuiFontHeight(GFUI_FONT_MEDIUM_C);
	dy2 = GfuiFontHeight(GFUI_FONT_SMALL_C);

	y = Winy+Winh-dy-5;

	snprintf(buf, BUFSIZE, "%d/%d - %s", car->_pos, s->_ncars, car->_name);
	dx = GfuiFontWidth(GFUI_FONT_MEDIUM_C, buf);
	dx = MAX(dx, (x3-x));

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glColor4f(0.1, 0.1, 0.1, 0.8);
	float y2 = y-5-dy2*7;
	GfDrawRect({x-5, y+dy, x-5, y2, x+dx+5, y+dy, x+dx+5, y2});

	if(car->info.skillLevel == 3) {
		float z2 = y2-2-dy2*6;
		GfDrawRect({x-5, y2-2, x-5, z2, x+dx+5, y2-2, x+dx+5, z2});
		y2 = z2;
	}

	float z2 = y2-2-dy2*4;
	GfDrawRect({x-5, y2-2, x-5, z2, x+dx+5, y2-2, x+dx+5, z2});
	glDisable(GL_BLEND);

	GfuiPrintString(buf, grCarInfo[car->index].iconColor, GFUI_FONT_MEDIUM_C, x, y, GFUI_ALIGN_HL_VB);
	y -= dy;

	dy = GfuiFontHeight(GFUI_FONT_SMALL_C);

	GfuiPrintString("Fuel:", grWhite, GFUI_FONT_SMALL_C, x, y, GFUI_ALIGN_HL_VB);
	if(car->_fuel < 5.0) {
		clr = grRed;
	} else {
		clr = grWhite;
	}
	snprintf(buf, BUFSIZE, "%.1f l", car->_fuel);
	GfuiPrintString(buf, clr, GFUI_FONT_SMALL_C, x2, y, GFUI_ALIGN_HR_VB);
	y -= dy;

	clr = grWhite;

	GfuiPrintString("Laps:", clr, GFUI_FONT_SMALL_C, x, y, GFUI_ALIGN_HL_VB);
	snprintf(buf, BUFSIZE, "%d / %d", car->_laps, s->_totLaps);
	GfuiPrintString(buf, clr, GFUI_FONT_SMALL_C, x2, y, GFUI_ALIGN_HR_VB);
	y -= dy;

	GfuiPrintString("Best:", clr, GFUI_FONT_SMALL_C, x, y, GFUI_ALIGN_HL_VB);
	grWriteTime(clr, GFUI_FONT_SMALL_C, x2, y, car->_bestLapTime, 0);
	grWriteTime(clr, GFUI_FONT_SMALL_C, x3, y, car->_deltaBestLapTime, 1);
	y -= dy;

	GfuiPrintString("Time:", clr, GFUI_FONT_SMALL_C, x, y, GFUI_ALIGN_HL_VB);
	if(!car->_commitBestLapTime) {
		clr = grRed;
	}
	grWriteTime(clr, GFUI_FONT_SMALL_C, x2, y, car->_curLapTime, 0);
	y -= dy;
	clr = grWhite;

	GfuiPrintString("Penalty:", clr, GFUI_FONT_SMALL_C, x, y, GFUI_ALIGN_HL_VB);
	grWriteTime(clr, GFUI_FONT_SMALL_C, x2, y, car->_penaltyTime, 0);
	y -= dy;

	if(car->_pos != 1) {
		snprintf(buf, BUFSIZE, "<- %s", s->cars[car->_pos-2]->_name);
		GfuiPrintString(buf, clr, GFUI_FONT_SMALL_C, x, y, GFUI_ALIGN_HL_VB);
		if(s->cars[car->_pos-2]->_laps == car->_laps) {
			grWriteTime(clr, GFUI_FONT_SMALL_C, x3, y, s->cars[car->_pos-2]->_curTime-car->_curTime, 1);
		} else {
			GfuiPrintString("       --:--", clr, GFUI_FONT_SMALL_C, x3, y, GFUI_ALIGN_HR_VB);
		}
	} else {
		GfuiPrintString("<- ", clr, GFUI_FONT_SMALL_C, x, y, GFUI_ALIGN_HL_VB);
		GfuiPrintString("       --:--", clr, GFUI_FONT_SMALL_C, x3, y, GFUI_ALIGN_HR_VB);
	}
	y -= dy;

	if(car->_pos != s->_ncars) {
		snprintf(buf, BUFSIZE, "-> %s", s->cars[car->_pos]->_name);
		GfuiPrintString(buf, clr, GFUI_FONT_SMALL_C, x, y, GFUI_ALIGN_HL_VB);
		if(s->cars[car->_pos]->_laps == car->_laps) {
			grWriteTime(clr, GFUI_FONT_SMALL_C, x3, y, s->cars[car->_pos]->_curTime-car->_curTime, 1);
		} else {
			GfuiPrintString("       --:--", clr, GFUI_FONT_SMALL_C, x3, y, GFUI_ALIGN_HR_VB);
		}
	} else {
		GfuiPrintString("-> ", clr, GFUI_FONT_SMALL_C, x, y, GFUI_ALIGN_HL_VB);
		GfuiPrintString("       --:--", clr, GFUI_FONT_SMALL_C, x3, y, GFUI_ALIGN_HR_VB);
	}
	y -= dy+5;

	if(car->info.skillLevel == 3) {
		static const char* wheellabel[4] = {"FR", "FL", "RR", "RL"};

		GfuiPrintString("T[Celsius], P[Bar], Wear[-], Grain[-]", grWhite, GFUI_FONT_SMALL_C, x, y-5*dy, GFUI_ALIGN_HL_VB);

		static const int tx0 = 45;
		static const int tdx = 47;

		for(i = 0; i < 4; i++) {
			const tWheelState* const wheel = &(car->priv.wheel[i]);

			GfuiPrintString(wheellabel[i], grWhite, GFUI_FONT_SMALL_C, tx0+i*tdx, y, GFUI_ALIGN_HR_VB);

			snprintf(buf, BUFSIZE, "%4.1f", wheel->currentTemperature-273.15f);
			GfuiPrintString(buf, grWhite, GFUI_FONT_SMALL_C, tx0+i*tdx, y-dy, GFUI_ALIGN_HR_VB);
			snprintf(buf, BUFSIZE, "%4.3f", (wheel->currentPressure-car->priv.localPressure)/100000.0f);
			GfuiPrintString(buf, grWhite, GFUI_FONT_SMALL_C, tx0+i*tdx, y-2*dy, GFUI_ALIGN_HR_VB);
			snprintf(buf, BUFSIZE, "%5.4f", wheel->currentWear);
			GfuiPrintString(buf, grWhite, GFUI_FONT_SMALL_C, tx0+i*tdx, y-3*dy, GFUI_ALIGN_HR_VB);
			snprintf(buf, BUFSIZE, "%5.4f", wheel->currentGraining);
			GfuiPrintString(buf, grWhite, GFUI_FONT_SMALL_C, tx0+i*tdx, y-4*dy, GFUI_ALIGN_HR_VB);
		}

		y -= dy*6+2;
	}

	for(i = 0; i < 4; i++) {
		if(car->ctrl.msg[i]) {
			GfuiPrintString(car->ctrl.msg[i], car->ctrl.msgColor, GFUI_FONT_SMALL_C, x, y, GFUI_ALIGN_HL_VB);
			y -= dy;
		}
	}
}

void cGrBoard::grDispCarBoard(tCarElt* car, tSituation* s)
{
	switch(boardFlag) {
		case 0:
			break;
		case 1:
			grDispCarBoard1(car, s);
			break;
		case 2:
			grDispCarBoard2(car, s);
			break;
		default:
			break;
	}
}

static const char* gearStr[MAX_GEARS] = {"R", "N", "1", "2", "3", "4", "5", "6", "7", "8"};

#define ALIGN_CENTER 0
#define ALIGN_LEFT   1
#define ALIGN_RIGHT  2

static void grDispEngineLeds(tCarElt* car, int X, int Y, int align, int bg)
{
	float x, y;
	float xref;
	GLfloat ledcolg[2][3] = {{0.0, 0.2, 0.0},
							 {0.0, 1.0, 0.0}};

	GLfloat ledcolr[2][3] = {{0.2, 0.0, 0.0},
							 {1.0, 0.0, 0.0}};

	int i;
	int ledNb = 20;
	int ledHeight = 10;
	int ledWidth = 5;
	int ledSpace = 2;
	int ledRed = (int)((car->_enginerpmRedLine*.9/car->_enginerpmMax)*(tdble)ledNb);
	int ledLit = (int)((car->_enginerpm/car->_enginerpmMax)*(tdble)ledNb);

	switch(align) {
		case ALIGN_CENTER:
			x = X-((ledNb*ledWidth)+(ledNb-1)*ledSpace)/2;
			break;
		case ALIGN_LEFT:
			x = X;
			break;
		case ALIGN_RIGHT:
			x = X-((ledNb*ledWidth)+(ledNb-1)*ledSpace);
			break;
		default:
			x = X-((ledNb*ledWidth)+(ledNb-1)*ledSpace)/2;
			break;
	}

	y = Y;

	if(bg) {
		glColor4f(0.1, 0.1, 0.1, 1.0);
		GfDrawRect({
			x-ledSpace, y+ledHeight+ledSpace, x-ledSpace, Winy, x+ledNb*(ledWidth+ledSpace), y+ledHeight+ledSpace, x+ledNb*(ledWidth+ledSpace),
			Winy});
	}

	xref = x;
	glColor3fv(ledcolg[0]);
	for(i = 0; i < ledRed; i++) {
		GfDrawRect({x, y, x+ledWidth, y, x, y+ledHeight, x+ledWidth, y+ledHeight});
		x += ledWidth+ledSpace;
	}

	glColor3fv(ledcolr[0]);
	for(i = ledRed; i < ledNb; i++) {
		GfDrawRect({x, y, x+ledWidth, y, x, y+ledHeight, x+ledWidth, y+ledHeight});
		x += ledWidth+ledSpace;
	}
	x = xref;
#define DD    1
	glColor3fv(ledcolg[1]);
	for(i = 0; i < ledNb; i++) {
		if(i == ledRed) {
			glColor3fv(ledcolr[1]);
		}
		if(i <= ledLit) {
			GfDrawRect({x+DD, y+DD, x+ledWidth-DD, y+DD, x+DD, y+ledHeight-DD, x+ledWidth-DD, y+ledHeight-DD});
			x += ledWidth+ledSpace;
		} else {
			break;
		}
	}
}

void cGrBoard::grDispCounterBoard(tCarElt* car)
{
	int x, y;
	const int BUFSIZE = 256;
	char buf[BUFSIZE];

	grDispEngineLeds(car, Winx+Winw/2, Winy+MAX(GfuiFontHeight(GFUI_FONT_BIG_C), GfuiFontHeight(GFUI_FONT_DIGIT)), ALIGN_CENTER, 1);

	x = Winx+Winw/2;
	y = Winy;
	snprintf(buf, BUFSIZE, " kph %s", gearStr[car->_gear+car->_gearOffset]);
	GfuiPrintString(buf, grBlue, GFUI_FONT_BIG_C, x, y, GFUI_ALIGN_HL_VB);

	x = Winx+Winw/2;
	snprintf(buf, BUFSIZE, "%3d", abs((int)(car->_speed_x*3.6)));
	GfuiPrintString(buf, grBlue, GFUI_FONT_DIGIT, x, y, GFUI_ALIGN_HR_VB);
}

void cGrBoard::grDispLeaderBoard(tCarElt* car, tSituation* s)
{
	int i, j;
	float x, x2, y;
	const int BUFSIZE = 256;
	char buf[BUFSIZE];
	int maxi = MIN(leaderNb, s->_ncars);
	float* clr;
	float dy;
	float drawCurrent;
	float drawLaps = leaderFlag-1;
	float current = 0;

	for(i = 0; i < s->_ncars; i++) {
		if(car == s->cars[i]) {
			current = i;
			break;
		}
	}

	x = Winx+5;
	x2 = Winx+170;
	y = Winy+10;
	dy = GfuiFontHeight(GFUI_FONT_SMALL_C);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glColor4f(0.1, 0.1, 0.1, 0.8);
	GfDrawRect({x, Winy+5, Winx+180, Winy+5, x, y+dy*(maxi+drawLaps), Winx+180, y+dy*(maxi+drawLaps)});
	glDisable(GL_BLEND);

	if(current+1 > maxi) {
		drawCurrent = 1;
	} else {
		drawCurrent = 0;
	}

	for(j = maxi; j > 0; j--) {
		if(drawCurrent) {
			i = current+1;
			drawCurrent = 0;
		} else {
			i = j;
		}

		if(i == current+1) {
			clr = grCarInfo[car->index].iconColor;
			drawCurrent = 0;
		} else {
			clr = grWhite;
		}

		snprintf(buf, BUFSIZE, "%3d: %s", i, s->cars[i-1]->_name);
		GfuiPrintString(buf, clr, GFUI_FONT_SMALL_C, x, y, GFUI_ALIGN_HL_VB);

		if(s->cars[i-1]->_state&RM_CAR_STATE_DNF) {
			GfuiPrintString("       out", grRed, GFUI_FONT_SMALL_C, x2, y, GFUI_ALIGN_HR_VB);
		} else if(s->cars[i-1]->_timeBehindLeader == 0) {
			if(i != 1) {
				GfuiPrintString("       --:--", clr, GFUI_FONT_SMALL_C, x2, y, GFUI_ALIGN_HR_VB);
			} else {
				grWriteTime(clr, GFUI_FONT_SMALL_C, x2, y, s->cars[i-1]->_curTime, 0);
			}
		} else {
			if(i == 1) {
				grWriteTime(clr, GFUI_FONT_SMALL_C, x2, y, s->cars[i-1]->_curTime, 0);
			} else {
				if(s->cars[i-1]->_lapsBehindLeader == 0) {
					grWriteTime(clr, GFUI_FONT_SMALL_C, x2, y, s->cars[i-1]->_timeBehindLeader, 1);
				} else {
					if(s->cars[i-1]->_lapsBehindLeader > 1) {
						snprintf(buf, BUFSIZE, "+%3d Laps", s->cars[i-1]->_lapsBehindLeader);
					} else {
						snprintf(buf, BUFSIZE, "+%3d Lap", s->cars[i-1]->_lapsBehindLeader);
					}
					GfuiPrintString(buf, clr, GFUI_FONT_SMALL_C, x2, y, GFUI_ALIGN_HR_VB);
				}
			}
		}
		y += dy;
	}

	if(drawLaps) {
		GfuiPrintString(" Lap:", grWhite, GFUI_FONT_SMALL_C, x, y, GFUI_ALIGN_HL_VB);
		snprintf(buf, BUFSIZE, "%d / %d", s->cars[0]->_laps, s->_totLaps);
		GfuiPrintString(buf, grWhite, GFUI_FONT_SMALL_C, x2, y, GFUI_ALIGN_HR_VB);
	}
}

inline void grDrawInstrument(tgrCarInstrument* curInst, int test)
{
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
//	glEnable(GL_TEXTURE_2D);
//	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
	glColor4f(1.0, 1.0, 1.0, 1.0);
//	auto uTexture = curInst->texture->getTextureHandle();
	ax_DrawImage(curInst->uTexture, curInst->vPosition, curInst->vSize);
//	GLint whichID;
//	glGetIntegerv(GL_TEXTURE_BINDING_2D, &whichID); // TODO: delete later
//	LogError("grDrawInstrument: whichID = %d", whichID); // TODO: delete later
//	auto texture = curInst->texture->getTextureHandle();
//	if(glIsTexture(texture) == GL_TRUE) {
//		GfDrawQuad(curInst->fTachometerQuad, texture);
//	}
	glBindTexture(GL_TEXTURE_2D, 0);

	tdble val = (*(curInst->monitored)-curInst->minValue)/curInst->maxValue;
	if(val > 1.0) {
		val = 1.0;
	} else if(val < 0.0) {
		val = 0.0;
	}
	val = curInst->minAngle+val*curInst->maxAngle;

	RELAXATION(val, curInst->prevVal, 30);

//	glPushMatrix();
//	glTranslatef(curInst->needleXCenter, curInst->needleYCenter, 0);
//	glRotatef(val, 0, 0, 1);
	glColor4f(1.0, 0.0, 0.0, 1.0);
	GfDrawTriangleStrip(&curInst->vHand[0].x, 4, curInst->needleXCenter, curInst->needleYCenter, (float)DEG2RAD(val));
//	GfDrawQuad(curInst->fTachometerHand);
//	glPopMatrix();
}

void cGrBoard::grDispCounterBoard2(tCarElt* car)
{
	int index;
	tgrCarInstrument* curInst;
	const int BUFSIZE = 32;
	char buf[BUFSIZE];

	index = car->index;    /* current car's index */

	curInst = &(grCarInfo[index].instrument[0]);
	grDrawInstrument(curInst, 0);
	GfuiPrintString((char*)(gearStr[car->_gear+car->_gearOffset]), grRed, GFUI_FONT_LARGE_C, (int)curInst->digitXCenter,
		(int)(curInst->digitYCenter), GFUI_ALIGN_HC_VB);

	curInst = &(grCarInfo[index].instrument[1]);
	grDrawInstrument(curInst, 1);
	if(curInst->digital) {
		// Do not add "%3d" or something, because the digital font DOES NOT SUPPORT BLANKS!!!!
		snprintf(buf, BUFSIZE, "%d", abs((int)(car->_speed_x*3.6)));
		GfuiPrintString(buf, grBlue, GFUI_FONT_DIGIT, (int)curInst->digitXCenter, (int)(curInst->digitYCenter), GFUI_ALIGN_HC_VB);
	}

	if(counterFlag == 1) {
		grDispMisc(car);
	}
}

void cGrBoard::initBoard(void)
{
	if(trackMap == NULL) {
		trackMap = new cGrTrackMap();
	}
}

void cGrBoard::shutdown(void)
{
	if(trackMap != NULL) {
		delete trackMap;
		trackMap = NULL;
	}
}

void cGrBoard::grDispArcade(tCarElt* car, tSituation* s)
{
	int x, y;
	int dy;
	const int BUFSIZE = 256;
	char buf[BUFSIZE];
	float* clr;

#define XM    15
#define YM    10

	x = XM;
	dy = GfuiFontHeight(GFUI_FONT_BIG_C);
	y = Winy+Winh-YM-dy;
	snprintf(buf, BUFSIZE, "%d/%d", car->_pos, s->_ncars);
	GfuiPrintString(buf, grDefaultClr, GFUI_FONT_BIG_C, x, y, GFUI_ALIGN_HL_VB);

	dy = GfuiFontHeight(GFUI_FONT_LARGE_C);
	y -= dy;
	GfuiPrintString("Time:", grDefaultClr, GFUI_FONT_LARGE_C, x, y, GFUI_ALIGN_HL_VB);
	if(!car->_commitBestLapTime) {
		clr = grRed;
	} else {
		clr = grDefaultClr;
	}
	grWriteTime(clr, GFUI_FONT_LARGE_C, x+150, y, car->_curLapTime, 0);

	y -= dy;
	GfuiPrintString("Best:", grDefaultClr, GFUI_FONT_LARGE_C, x, y, GFUI_ALIGN_HL_VB);
	grWriteTime(grDefaultClr, GFUI_FONT_LARGE_C, x+150, y, car->_bestLapTime, 0);

	x = Winx+Winw-XM;
	y = Winy+Winh-YM-dy;
	snprintf(buf, BUFSIZE, "Lap: %d/%d", car->_laps, s->_totLaps);
	GfuiPrintString(buf, grDefaultClr, GFUI_FONT_LARGE_C, x, y, GFUI_ALIGN_HR_VB);


	x = Winx+Winw/2;
	snprintf(buf, BUFSIZE, "%s", car->_name);
	GfuiPrintString(buf, grDefaultClr, GFUI_FONT_LARGE_C, x, y, GFUI_ALIGN_HC_VB);


	if(car->_fuel < 5.0) {
		clr = grRed;
	} else {
		clr = grWhite;
	}
	grDrawGauge(XM, 20.0, 80.0, clr, grBlack, car->_fuel/car->_tank, "F");
	grDrawGauge(XM+15, 20.0, 80.0, grRed, grGreen, (tdble)(car->_dammage)/grMaxDammage, "D");

	x = Winx+Winw-XM;
	dy = GfuiFontHeight(GFUI_FONT_LARGE_C);
	y = YM+dy;
	snprintf(buf, BUFSIZE, "%3d km/h", abs((int)(car->_speed_x*3.6)));
	GfuiPrintString(buf, grDefaultClr, GFUI_FONT_BIG_C, x, y, GFUI_ALIGN_HR_VB);
	y = YM;
	snprintf(buf, BUFSIZE, "%s", gearStr[car->_gear+car->_gearOffset]);
	GfuiPrintString(buf, grDefaultClr, GFUI_FONT_LARGE_C, x, y, GFUI_ALIGN_HR_VB);

	grDispEngineLeds(car, Winx+Winw-XM, YM+dy+GfuiFontHeight(GFUI_FONT_BIG_C), ALIGN_RIGHT, 0);
}


void cGrBoard::refreshBoard(tSituation* s, float Fps, int forceArcade, tCarElt* curr)
{
//	LogInfo("inside cGrBoard::refreshBoard: Fps = %.1f", Fps); // TODO: delete later
	if(arcadeFlag || forceArcade) {
		grDispArcade(curr, s);
	} else {
		if(debugFlag) grDispDebug(Fps, curr, s);
		if(GFlag) grDispGGraph(curr);
		if(boardFlag) grDispCarBoard(curr, s);
		if(leaderFlag) grDispLeaderBoard(curr, s);
		if(counterFlag) grDispCounterBoard2(curr);
	}

//	LogInfo("inside cGrBoard::refreshBoard before trackMap->display: trackMap = %p", trackMap); // TODO: delete later
	trackMap->display(curr, s, Winx, Winy, Winw, Winh);
//	LogError("inside cGrBoard::refreshBoard after trackMap->display"); // TODO: delete later
}

inline void setHandVertices(vec2* pVertices, float needlexSz, float needleySz)
{
	pVertices[0] = {0, needleySz};
	pVertices[1] = {0, -needleySz};
	pVertices[2] = {needlexSz, needleySz/2.0f};
	pVertices[3] = {needlexSz, -needleySz/2.0f};
}

void grInitBoardCar(tCarElt* car)
{
	const int BUFSIZE = 1024;
	char buf[BUFSIZE];
	int index;
	void* handle;
	const char* param;
	myLoaderOptions options;
	tgrCarInfo* carInfo;
	tgrCarInstrument* curInst;
	tdble xSz, ySz, xpos, ypos;
	tdble needlexSz, needleySz;

	ssgSetCurrentOptions(&options);

	index = car->index;    /* current car's index */
	carInfo = &grCarInfo[index];
	handle = car->_carHandle;

	/* Tachometer */
	curInst = &(carInfo->instrument[0]);

	/* Load the Tachometer texture */
	param = GfParmGetStr(handle, SECT_GROBJECTS, PRM_TACHO_TEX, "rpm8000.rgb");
	snprintf(buf, BUFSIZE, "drivers/%s/%d;drivers/%s;cars/%s;data/textures;data/img;.", car->_modName, car->_driverIndex, car->_modName,
		car->_carName);
//	grFilePath = strdup(buf);
//	curInst->texture = (ssgSimpleState*)grSsgLoadTexState(param); // Need this to get correct shadow for the last car (fix me later)
//	curInst->texture->ref();
//	free(grFilePath);
//	LogInfo("inside grInitBoardCar: curInst->texture = %p buf = %s param = %s", curInst->texture, buf, param); // TODO: delete later
	if(auto qFile = getSubFile(buf, param); qFile) curInst->uTexture = ax_LoadTexture(nullptr, nullptr, qFile, false, nullptr); // Load image

	/* Load the instrument placement */
	xSz = GfParmGetNum(handle, SECT_GROBJECTS, PRM_TACHO_XSZ, (char*)NULL, 128);
	ySz = GfParmGetNum(handle, SECT_GROBJECTS, PRM_TACHO_YSZ, (char*)NULL, 128);
	xpos = GfParmGetNum(handle, SECT_GROBJECTS, PRM_TACHO_XPOS, (char*)NULL, Winw/2.0-xSz);
	ypos = GfParmGetNum(handle, SECT_GROBJECTS, PRM_TACHO_YPOS, (char*)NULL, 0);
	needlexSz = GfParmGetNum(handle, SECT_GROBJECTS, PRM_TACHO_NDLXSZ, (char*)NULL, 50);
	needleySz = GfParmGetNum(handle, SECT_GROBJECTS, PRM_TACHO_NDLYSZ, (char*)NULL, 2);
	curInst->needleXCenter = GfParmGetNum(handle, SECT_GROBJECTS, PRM_TACHO_XCENTER, (char*)NULL, xSz/2.0)+xpos;
	curInst->needleYCenter = GfParmGetNum(handle, SECT_GROBJECTS, PRM_TACHO_YCENTER, (char*)NULL, ySz/2.0)+ypos;
	curInst->digitXCenter = GfParmGetNum(handle, SECT_GROBJECTS, PRM_TACHO_XDIGITCENTER, (char*)NULL, xSz/2.0)+xpos;
	curInst->digitYCenter = GfParmGetNum(handle, SECT_GROBJECTS, PRM_TACHO_YDIGITCENTER, (char*)NULL, 16)+ypos;
	curInst->minValue = GfParmGetNum(handle, SECT_GROBJECTS, PRM_TACHO_MINVAL, (char*)NULL, 0);
	curInst->maxValue = GfParmGetNum(handle, SECT_GROBJECTS, PRM_TACHO_MAXVAL, (char*)NULL, RPM2RADS(10000))-curInst->minValue;
	curInst->minAngle = GfParmGetNum(handle, SECT_GROBJECTS, PRM_TACHO_MINANG, "deg", 225);
	curInst->maxAngle = GfParmGetNum(handle, SECT_GROBJECTS, PRM_TACHO_MAXANG, "deg", -45)-curInst->minAngle;
	curInst->monitored = &(car->_enginerpm);
	curInst->prevVal = curInst->minAngle;

	setHandVertices(curInst->vHand, needlexSz, needleySz);
	curInst->vPosition = {xpos, ypos};
	curInst->vSize = {xSz, ySz};


	/* Speedometer */
	curInst = &(carInfo->instrument[1]);

	/* Load the Speedometer texture */
	param = GfParmGetStr(handle, SECT_GROBJECTS, PRM_SPEEDO_TEX, "speed360.rgb");
	snprintf(buf, BUFSIZE, "drivers/%s/%d;drivers/%s;cars/%s;data/textures;data/img;.", car->_modName, car->_driverIndex, car->_modName,
		car->_carName);
//	grFilePath = strdup(buf);
//	curInst->texture = (ssgSimpleState*)grSsgLoadTexState(param); // Need this to get correct shadow for the last car (fix me later)
//	curInst->texture->ref();
//	free(grFilePath);
	if(auto qFile = getSubFile(buf, param); qFile) curInst->uTexture = ax_LoadTexture(nullptr, nullptr, qFile, false, nullptr); // Load image

	/* Load the instrument placement */
	xSz = GfParmGetNum(handle, SECT_GROBJECTS, PRM_SPEEDO_XSZ, (char*)NULL, 128);
	ySz = GfParmGetNum(handle, SECT_GROBJECTS, PRM_SPEEDO_YSZ, (char*)NULL, 128);
	xpos = GfParmGetNum(handle, SECT_GROBJECTS, PRM_SPEEDO_XPOS, (char*)NULL, Winw/2.0);
	ypos = GfParmGetNum(handle, SECT_GROBJECTS, PRM_SPEEDO_YPOS, (char*)NULL, 0);
	needlexSz = GfParmGetNum(handle, SECT_GROBJECTS, PRM_SPEEDO_NDLXSZ, (char*)NULL, 50);
	needleySz = GfParmGetNum(handle, SECT_GROBJECTS, PRM_SPEEDO_NDLYSZ, (char*)NULL, 2);
	curInst->needleXCenter = GfParmGetNum(handle, SECT_GROBJECTS, PRM_SPEEDO_XCENTER, (char*)NULL, xSz/2.0)+xpos;
	curInst->needleYCenter = GfParmGetNum(handle, SECT_GROBJECTS, PRM_SPEEDO_YCENTER, (char*)NULL, ySz/2.0)+ypos;
	curInst->digitXCenter = GfParmGetNum(handle, SECT_GROBJECTS, PRM_SPEEDO_XDIGITCENTER, (char*)NULL, xSz/2.0)+xpos;
	curInst->digitYCenter = GfParmGetNum(handle, SECT_GROBJECTS, PRM_SPEEDO_YDIGITCENTER, (char*)NULL, 10)+ypos;
	curInst->minValue = GfParmGetNum(handle, SECT_GROBJECTS, PRM_SPEEDO_MINVAL, (char*)NULL, 0);
	curInst->maxValue = GfParmGetNum(handle, SECT_GROBJECTS, PRM_SPEEDO_MAXVAL, (char*)NULL, 100)-curInst->minValue;
	curInst->minAngle = GfParmGetNum(handle, SECT_GROBJECTS, PRM_SPEEDO_MINANG, "deg", 225);
	curInst->maxAngle = GfParmGetNum(handle, SECT_GROBJECTS, PRM_SPEEDO_MAXANG, "deg", -45)-curInst->minAngle;
	curInst->monitored = &(car->_speed_x);
	curInst->prevVal = curInst->minAngle;
	if(strcmp(GfParmGetStr(handle, SECT_GROBJECTS, PRM_SPEEDO_DIGITAL, "yes"), "yes") == 0) {
		curInst->digital = 1;
	}

	setHandVertices(curInst->vHand, needlexSz, needleySz);
	curInst->vPosition = {xpos, ypos};
	curInst->vSize = {xSz, ySz};
}

void grShutdownBoardCar(void)
{
	for(int i = 0; i < grNbCars; i++) {
		ax_ReleaseTexture(grCarInfo[i].instrument[0].uTexture);
//		ssgDeRefDelete(grCarInfo[i].instrument[0].texture);
//		ssgDeRefDelete(grCarInfo[i].instrument[1].texture);
	}
}
