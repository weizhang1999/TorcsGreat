// -*- Mode: c++ -*-
/***************************************************************************
    file                 : TorcsSound.cpp
    created              : Tue Apr 5 19:57:35 CEST 2005
    copyright            : (C) 2005 Christos Dimitrakakis, Bernhard Wymann
    email                : dimitrak@idiap.ch
    version              : $Id: TorcsSound.cpp,v 1.8 2005/11/18 00:20:32 olethros Exp $

 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "TorcsSound.h"
#include "SoundInterface.h"
#include "android_jni.h"
#include "android_snd.h"


/// Set the volume \note effect not consistent across backends
void TorcsSound::setVolume(float vol)
{
	this->volume = vol;
}
/// Set the pitch \note Effect not consistent across backends
void TorcsSound::setPitch(float pitch)
{
	this->pitch = pitch;
}
/// Set the filter \note Effect not consistent across backends
void TorcsSound::setLPFilter(float lp)
{
	this->lowpass = lp;
}

/// Create a new PLib sound. It requires a scheduler to be set up and a filename to read data from.
PlibTorcsSound::PlibTorcsSound(slScheduler* sched, const char* filename, int flags, bool loop) : TorcsSound(flags)
{
	this->sched = sched;
	this->loop = loop;
	MAX_VOL = 1.0f;
	sample = new slSample(filename, sched);
	if(flags&ACTIVE_VOLUME) {
		volume_env = new slEnvelope(1, SL_SAMPLE_ONE_SHOT);
	}
	if(flags&ACTIVE_PITCH) {
		pitch_env = new slEnvelope(1, SL_SAMPLE_ONE_SHOT);
	}
	if(flags&ACTIVE_LP_FILTER) {
		lowpass_env = new slEnvelope(1, SL_SAMPLE_ONE_SHOT);
	}
	if(loop) {
		sched->loopSample(sample);
	}
	if(flags&ACTIVE_VOLUME) {
		sched->addSampleEnvelope(sample, 0, VOLUME_SLOT, volume_env, SL_VOLUME_ENVELOPE);
	}
	if(flags&ACTIVE_PITCH) {
		sched->addSampleEnvelope(sample, 0, PITCH_SLOT, pitch_env, SL_PITCH_ENVELOPE);
	}
	if(flags&ACTIVE_LP_FILTER) {
		sched->addSampleEnvelope(sample, 0, FILTER_SLOT, lowpass_env, SL_FILTER_ENVELOPE);
	}
	if(flags&ACTIVE_VOLUME) {
		volume_env->setStep(0, 0.0f, 0.0f);
	}
	if(flags&ACTIVE_PITCH) {
		pitch_env->setStep(0, 0.0f, 1.0f);
	}
	if(flags&ACTIVE_LP_FILTER) {
		lowpass_env->setStep(0, 0.0, 1.0f);
	}
	volume = 0.0f;
	pitch = 1.0f;
	lowpass = 1.0f;
	playing = false;
	paused = false;
}


/// Destructor.
PlibTorcsSound::~PlibTorcsSound()
{
//	LogError("inside PlibTorcsSound::~PlibTorcsSound: flags = 0x%04x volume = %g pitch = %g", flags, volume, pitch); // TODO: delete later
	sched->stopSample(sample);
	if(flags&ACTIVE_VOLUME) {
		sched->addSampleEnvelope(sample, 0, VOLUME_SLOT, NULL, SL_NULL_ENVELOPE);
		delete volume_env;
	}
	if(flags&ACTIVE_PITCH) {
		sched->addSampleEnvelope(sample, 0, PITCH_SLOT, NULL, SL_NULL_ENVELOPE);
		delete pitch_env;
	}
	if(flags&ACTIVE_LP_FILTER) {
		sched->addSampleEnvelope(sample, 0, FILTER_SLOT, NULL, SL_NULL_ENVELOPE);
		delete lowpass_env;
	}
	delete sample;
}

/** Set the volume.  Since plib does not support envelopes for
 * one-shot samples, we pre-adjust their volume
 */
void PlibTorcsSound::setVolume(float vol)
{
	if(vol > MAX_VOL) {
		vol = MAX_VOL;
	}
	this->volume = vol;

//	if(!loop) {
//		sample->adjustVolume(vol);
//	}
//	LogInfo("inside PlibTorcsSound::setVolume: vol = %g", vol); // TODO: delete later
	SND_SetVolume(sample, vol);
}
/// Start the sample
void PlibTorcsSound::play()
{
	start();
}
/// Start the sample
void PlibTorcsSound::start()
{
//	LogInfo("inside PlibTorcsSound::start: loop = %d", loop); // TODO: delete later
	// TODO: consistency check?
//	if(loop) {
//		if(!playing) {
//			playing = true;
//			sched->loopSample(sample);
//		}
//	} else {
//		playing = true;
//		sched->playSample(sample);
//	}
	SND_PlaySound(sample, loop);
}
/// Stop the sample
void PlibTorcsSound::stop()
{
//	LogError("inside PlibTorcsSound::stop: playing = %d", playing); // TODO: delete later
	if(playing) {
		playing = false;
		sched->stopSample(sample);
	}
	SND_PauseSound(sample, true);
}
/// Resume a paused sample.
void PlibTorcsSound::resume()
{
//	LogInfo("inside PlibTorcsSound::resume: playing = %d", playing); // TODO: delete later
	sched->resumeSample(sample);
	paused = false;
	SND_ResumeSound(sample);
}
/// Pause a sample
void PlibTorcsSound::pause()
{
//	LogError("inside PlibTorcsSound::resume: pause = %d", playing); // TODO: delete later
	sched->pauseSample(sample);
	paused = true;
	SND_PauseSound(sample, false);
}


/** Update the plib sounds.
 * This should be called as often as possible from the main sound code,
 * probably by looping through all the sounds used.
 */
void PlibTorcsSound::update()
{
//	LogInfo("inside PlibTorcsSound::update: flags = 0x%04x volume = %g pitch = %g", flags, volume, pitch); // TODO: delete later
	if(flags&ACTIVE_VOLUME) {
		volume_env->setStep(0, 0.0f, volume);
	}
	if(flags&ACTIVE_PITCH) {
		pitch_env->setStep(0, 0.0f, pitch);

	}
	if(flags&ACTIVE_LP_FILTER) {
		lowpass_env->setStep(0, 0.0f, lowpass);
	}
}

/// Create a sound source
SoundSource::SoundSource()
{
	a = 0.0;
	f = 1.0;
	lp = 1.0;
}

/** Calculate environmental parameters for current situation.
 *
 * At the moment this
 */
void SoundSource::update()
{
	// Get relative speed/position vector
	sgVec3 u;
	sgVec3 p;
	float u_rel = 0.0f;
	float u_rel_src = 0.0f;
	float u_rel_lis = 0.0f;
	float p_rel = 0.0f;
	for(int i = 0; i < 3; i++) {
		u[i] = u_src[i]-u_lis[i];
		p[i] = p_src[i]-p_lis[i];
		p_rel += p[i]*p[i];
	}

	a = 1.0;
	f = 1.0f;
	lp = 1.0f;

	// Only the vector component on the LOV is significant
	//    u_rel = sqrt(u_rel);
	p_rel = 0.01f+sqrt(p_rel);
	float p_cosx = p[0]/p_rel;
	float p_cosy = p[1]/p_rel;
	float p_cosz = p[2]/p_rel;
	float p_x_comp = u[0]*p_cosx;
	float p_y_comp = u[1]*p_cosy;
	float p_z_comp = u[2]*p_cosz;
	float p_x_src = u_src[0]*p_cosx;
	float p_y_src = u_src[1]*p_cosy;
	float p_z_src = u_src[2]*p_cosz;
	float p_x_lis = u_lis[0]*p_cosx;
	float p_y_lis = u_lis[1]*p_cosy;
	float p_z_lis = u_lis[2]*p_cosz;
	u_rel = (p_y_comp+p_x_comp+p_z_comp);
	u_rel_src = (p_y_src+p_x_src+p_z_src);
	u_rel_lis = (p_y_lis+p_x_lis+p_z_lis);
	if(fabs(u_rel) >= 0.9f*SPEED_OF_SOUND) {
		// Cut-off sound when relative speed approaches speed of sound.
		a = 0.0f;
		f = 1.0f;
		lp = 1.0f;
	} else {
		// attenuate and filter sound with distance and shift pitch with speed
		float ref = 5.0f;
		float rolloff = 0.5f;
		float atten = ref/(ref+rolloff*(p_rel-ref));
		//f = SPEED_OF_SOUND/(SPEED_OF_SOUND+u_rel);
		f = (SPEED_OF_SOUND-u_rel_src)/(SPEED_OF_SOUND-u_rel_lis);
		a = atten;
		float atten_filter = std::min(atten, 1.0f);
		lp = exp(atten_filter-1.0f);
	}
}


/** Set source position and velocity.
 */
void SoundSource::setSource(sgVec3 p, sgVec3 u)
{
	for(int i = 0; i < 3; i++) {
		p_src[i] = p[i];
		u_src[i] = u[i];
	}
}

/** Set listener position and velocity.
 */
void SoundSource::setListener(sgVec3 p, sgVec3 u)
{
	for(int i = 0; i < 3; i++) {
		p_lis[i] = p[i];
		u_lis[i] = u[i];
	}
}
