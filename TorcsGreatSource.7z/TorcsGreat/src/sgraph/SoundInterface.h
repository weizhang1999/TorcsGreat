// -*- Mode: c++ -*-
/***************************************************************************
    file                 : SoundInterface.h
    created              : Tue Apr 5 19:57:35 CEST 2005
    copyright            : (C) 2005 Christos Dimitrakakis, Bernhard Wymann
    email                : dimitrak@idiap.ch
    version              : $Id: SoundInterface.h,v 1.7.2.2 2013/09/01 10:24:23 berniw Exp $

***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef SOUND_INTERFACE_H
#define SOUND_INTERFACE_H

#undef SOUND_LOG

#ifdef SOUND_LOG
#define logmsg printf ("# "); printf
#else
#define logmsg empty_log
static void empty_log(const char* s, ...)
{
}
#endif


#include <sl.h>
#include <sg.h>
#include <raceman.h>
#include <vector>

#include "TorcsSound.h"
//#include "grsound.h"
#include "QSoundChar.h"


#define VOLUME_CUTOFF 0.001f


class CarSoundData;

/** A queue containing mappings between sounds and sound sources.
 *
 * Provides a mapping various sound sources and actual sounds. This is
 * used for the case where we have many sound sources emitting exactly
 * the same sound and where we don't allow more than 1 source to play
 * simultaneously. This structure can be used to sort competing
 * sources in order to decide which one is going to take priority.
 *
 * \sa SortSingleQueue(), SetMaxSoundChar()
 */
typedef struct QueueSoundMap_
{
	QSoundChar CarSoundData::*schar; ///< The calculated sound characteristic
	TorcsSound* snd; ///< The raw sound.
	float max_vol; ///< Max.
	int id; ///< The id of the car producing the sound, used for retrieving doppler effects etc
} QueueSoundMap;

/** Current state of sound*/
enum SoundPriState
{
	None = 0x0, Loaded, Playing, Paused, Stopped, Cleared
};

/** Sound priority, used to sort cars according to amplitude attenuation */
typedef struct SoundPri_
{
	float a; ///< amplitude
	int id; ///< car ID.
} SoundPri;

/// Sound interface
class SoundInterface
{
protected:
	float sampling_rate; ///< sampling rate
	int n_channels; ///< number of channels
	int n_engine_sounds; ///< number of simultaneous engines
	int curCrashSnd; ///< holds current crash sound used - the sound cycles
	TorcsSound* skid_sound[4]; ///< set of skid sounds, one per tyre
	TorcsSound* road_ride_sound; ///< rolling on normal road
	TorcsSound* grass_ride_sound; ///< rolling on dirt/grass
	TorcsSound* grass_skid_sound; ///< skidding on dirt/grass
	TorcsSound* metal_skid_sound; ///< metal skidding on metal
	TorcsSound* axle_sound; ///< axle/gear spinning sound
	TorcsSound* turbo_sound; ///< turbo spinning sound
	TorcsSound* backfire_loop_sound; ///< exhaust backfire sound
	TorcsSound* crash_sound[NB_CRASH_SOUND]; ///< list of crash sounds
	TorcsSound* bang_sound; ///< sounds when suspension fully compressed
	TorcsSound* bottom_crash_sound; ///< bang when crashing from a great height
	TorcsSound* backfire_sound; ///< one-off backfire sound
	TorcsSound* gear_change_sound; ///< sound when changing gears

	std::vector<TorcsSound*> sound_list; ///< keeps track of sounds used
	SoundPri* engpri; ///< the engine priority, used for sorting

	/// The following are mappings for sound prioritisation
	QueueSoundMap road;
	QueueSoundMap grass;
	QueueSoundMap grass_skid;
	QueueSoundMap metal_skid;
	QueueSoundMap backfire_loop;
	QueueSoundMap turbo;
	QueueSoundMap axle;

	/** Find the max amplitude sound in car_sound_data and put it in smap  */
	void SortSingleQueue(CarSoundData** car_sound_data, QueueSoundMap* smap, int n_cars);

	/** Using the smap->id, get the appropriate entry in
	car_sound_data and call apprioriate methods for smap->snd in order
	to play the sound.*/
	void SetMaxSoundCar(CarSoundData** car_sound_data, QueueSoundMap* smap);

public:
	/// Make a new sound interface
	SoundInterface(float sampling_rate, int n_channels);

	/// Destructor - does nothing
	virtual ~SoundInterface() {}

	/// Set the number of cars - must be defined in children classes
	virtual void setNCars(int n_cars) = 0;

	/// Add a new sample - must be defined in children classes
	virtual TorcsSound*
	addSample(const char* filename, int flags = (ACTIVE_VOLUME|ACTIVE_PITCH), bool loop = false, bool static_pool = true) = 0;

	void setSkidSound(const char* sound_name)
	{
		for(int i = 0; i < 4; i++) {
			TorcsSound* sound = addSample(sound_name, ACTIVE_VOLUME|ACTIVE_PITCH, true);
			skid_sound[i] = sound;
		}

	}
	void setRoadRideSound(const char* sound_name)
	{
		TorcsSound* sound = addSample(sound_name, ACTIVE_VOLUME|ACTIVE_PITCH, true);
		road_ride_sound = sound;
	}
	void setGrassRideSound(const char* sound_name)
	{
		TorcsSound* sound = addSample(sound_name, ACTIVE_VOLUME|ACTIVE_PITCH, true);
		grass_ride_sound = sound;
	}
	void setGrassSkidSound(const char* sound_name)
	{
		TorcsSound* sound = addSample(sound_name, ACTIVE_VOLUME|ACTIVE_PITCH, true);
		grass_skid_sound = sound;
	}
	void setMetalSkidSound(const char* sound_name)
	{
		TorcsSound* sound = addSample(sound_name, ACTIVE_VOLUME|ACTIVE_PITCH, true);
		metal_skid_sound = sound;
	}
	void setAxleSound(const char* sound_name)
	{
		TorcsSound* sound = addSample(sound_name, ACTIVE_VOLUME|ACTIVE_PITCH, true);
		axle_sound = sound;
	}
	void setTurboSound(const char* sound_name)
	{
		TorcsSound* sound = addSample(sound_name, ACTIVE_VOLUME|ACTIVE_PITCH, true);
		turbo_sound = sound;
	}
	void setBackfireLoopSound(const char* sound_name)
	{
		TorcsSound* sound = addSample(sound_name, ACTIVE_VOLUME|ACTIVE_PITCH, true);
		backfire_loop_sound = sound;
	}
	void setCrashSound(const char* sound_name, int index)
	{
		TorcsSound* sound = addSample(sound_name, 0, false);
		assert(index >= 0 && index < NB_CRASH_SOUND);
		crash_sound[index] = sound;
	}

	void setBangSound(const char* sound_name)
	{
		TorcsSound* sound = addSample(sound_name, 0, false);
		bang_sound = sound;
	}

	void setBottomCrashSound(const char* sound_name)
	{
		TorcsSound* sound = addSample(sound_name, 0, false);
		bottom_crash_sound = sound;
	}

	void setBackfireSound(const char* sound_name)
	{
		TorcsSound* sound = addSample(sound_name, 0, false);
		backfire_sound = sound;
	}

	void setGearChangeSound(const char* sound_name)
	{
		TorcsSound* sound = addSample(sound_name, 0, false);
		gear_change_sound = sound;
		gear_change_sound->setVolume(0.25f);
	}
	/// Update sound for a given observer.
	virtual void update(CarSoundData** car_sound_data, int n_cars, sgVec3 p_obs, sgVec3 u_obs, sgVec3 c_obs = NULL, sgVec3 a_obs = NULL)
	{
		// do nothing
	}

	virtual void muteForMenu() {}
	virtual float getGlobalGain() { return 1.0f; }
	virtual void setGlobalGain(float g)
	{
		fprintf(stderr, "Warning, gain setting not supported\n");
	}

};


/// PLIB interface
class PlibSoundInterface : public SoundInterface
{
	typedef struct SoundChar_
	{
		float f; //frequency modulation
		float a; //amplitude modulation
	} SoundChar;
protected:
	slScheduler* sched;
	std::vector<TorcsSound*> sound_list;
	SoundPri* engpri;
	SoundSource* car_src;
	SoundSource tyre_src[4];
	void DopplerShift(SoundChar* sound, float* p_src, float* u_src, float* p, float* u);
	void SetMaxSoundCar(CarSoundData** car_sound_data, QueueSoundMap* smap);
	float global_gain;
public:
	PlibSoundInterface(float sampling_rate, int n_channels);
	virtual ~PlibSoundInterface();
	virtual void setNCars(int n_cars);
	virtual slScheduler* getScheduler();
	virtual TorcsSound* addSample(const char* filename, int flags = (ACTIVE_VOLUME|ACTIVE_PITCH), bool loop = false, bool static_pool = true);
	virtual void update(CarSoundData** car_sound_data, int n_cars, sgVec3 p_obs, sgVec3 u_obs, sgVec3 c_obs = NULL, sgVec3 a_obs = NULL);
	virtual float getGlobalGain() { return global_gain; }
	virtual void setGlobalGain(float g)
	{
		global_gain = 0.5f*g;
		logmsg("Setting gain to %f\n", global_gain);
	}

};

#endif /* SOUND_INTERFACE_H */
