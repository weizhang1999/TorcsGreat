#ifndef QSOUND_CHAR_H
#define QSOUND_CHAR_H

typedef struct QSoundChar_
{
	float a;
	float f;
	float lp;
} QSoundChar;

#endif
