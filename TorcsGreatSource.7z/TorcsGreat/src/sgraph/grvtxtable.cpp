/***************************************************************************

    file                 : grvtxtable.cpp
    created              : Fri Mar 22 23:16:44 CET 2002
    copyright            : (C) 2001 by Christophe Guionneau
    version              : $Id: grvtxtable.cpp,v 1.15 2005/09/19 19:00:57 berniw Exp $

 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include <ssg.h>
#include "grvtxtable.h"
#include "grmain.h"
#include "grcam.h"
#include "grshadow.h"
#include "grskidmarks.h"
#include "grscene.h"
#include "grcar.h"
#include "grutil.h"

/* from grloadac.cpp (beuark!) */
extern double shad_xmax;
extern double shad_ymax;
extern double shad_xmin;
extern double shad_ymin;


void grVtxTable::copy_from(grVtxTable* src, int clone_flags)
{
	ssgVtxTable::copy_from(src, clone_flags);
	if(src->texcoords1 != NULL && (clone_flags&SSG_CLONE_GEOMETRY)) {
		texcoords1 = (ssgTexCoordArray*)(src->texcoords1->clone(clone_flags));
	} else {
		texcoords1 = src->texcoords1;
	}

	if(src->texcoords2 != NULL && (clone_flags&SSG_CLONE_GEOMETRY)) {
		texcoords2 = (ssgTexCoordArray*)(src->texcoords2->clone(clone_flags));
	} else {
		texcoords2 = src->texcoords2;
	}

	if(src->texcoords3 != NULL && (clone_flags&SSG_CLONE_GEOMETRY)) {
		texcoords3 = (ssgTexCoordArray*)(src->texcoords3->clone(clone_flags));
	} else {
		texcoords3 = src->texcoords3;
	}

	numMapLevel = src->numMapLevel;
	mapLevelBitmap = src->mapLevelBitmap;
	internalType = src->internalType;

	if(src->internalType == ARRAY) {
		numStripes = src->numStripes;
		ssgDeRefDelete(indices);
		if(src->indices != NULL && (clone_flags&SSG_CLONE_GEOMETRY)) {
			indices = (ssgIndexArray*)(src->indices->clone(clone_flags));
		} else {
			indices = src->indices;
		}

		if(indices != NULL) {
			indices->ref();
		}

		ssgDeRefDelete(stripes);
		if(src->stripes != NULL && (clone_flags&SSG_CLONE_GEOMETRY)) {
			stripes = (ssgIndexArray*)(src->stripes->clone(clone_flags));
		} else {
			stripes = src->stripes;
		}

		if(stripes != NULL) {
			stripes->ref();
		}
	}
}


ssgBase* grVtxTable::clone(int clone_flags)
{
	grVtxTable* b = new grVtxTable(1, LEVEL0);
	b->copy_from(this, clone_flags);
	return b;
}


grVtxTable::grVtxTable(int _numMapLevel, int _mapLevel)
{
	numMapLevel = _numMapLevel;
	mapLevelBitmap = _mapLevel;
	indexCar = -1;
	texcoords1 = NULL;
	texcoords2 = NULL;
	texcoords3 = NULL;
	state1 = state2 = state3 = NULL;
	internalType = TABLE;
	numStripes = 0;
	ssgVtxTable();
}


grVtxTable::grVtxTable(GLenum ty, ssgVertexArray* vl, ssgIndexArray* stripeIndex, int _numstripes, ssgIndexArray* il, ssgNormalArray* nl,
	ssgTexCoordArray* tl, ssgTexCoordArray* tl1, ssgTexCoordArray* tl2, ssgTexCoordArray* tl3, int _numMapLevel, int _mapLevel,
	ssgColourArray* cl, int _indexCar) : ssgVtxTable(ty, vl, nl, tl, cl)
{
	type = ssgTypeVtxTable();
	numMapLevel = _numMapLevel;
	mapLevelBitmap = _mapLevel;
	indexCar = _indexCar;
	texcoords1 = (tl1 != NULL) ? tl1 : new ssgTexCoordArray();
	texcoords2 = (tl2 != NULL) ? tl2 : new ssgTexCoordArray();
	texcoords3 = (tl3 != NULL) ? tl3 : new ssgTexCoordArray();
	texcoords1->ref();
	texcoords2->ref();
	texcoords3->ref();
	state1 = state2 = state3 = NULL;
	internalType = ARRAY;
	indices = (il != NULL) ? il : new ssgIndexArray();
	indices->ref();
	stripes = (stripeIndex != NULL) ? stripeIndex : new ssgIndexArray();
	stripes->ref();
	numStripes = _numstripes;
}


grVtxTable::grVtxTable(GLenum ty, ssgVertexArray* vl, ssgNormalArray* nl, ssgTexCoordArray* tl, ssgTexCoordArray* tl1, ssgTexCoordArray* tl2,
	ssgTexCoordArray* tl3, int _numMapLevel, int _mapLevel, ssgColourArray* cl, int _indexCar) : ssgVtxTable(ty, vl, nl, tl, cl)
{
	type = ssgTypeVtxTable();
	numMapLevel = _numMapLevel;
	mapLevelBitmap = _mapLevel;
	indexCar = _indexCar;
	texcoords1 = (tl1 != NULL) ? tl1 : new ssgTexCoordArray();
	texcoords2 = (tl2 != NULL) ? tl2 : new ssgTexCoordArray();
	texcoords3 = (tl3 != NULL) ? tl3 : new ssgTexCoordArray();
	texcoords1->ref();
	texcoords2->ref();
	texcoords3->ref();
	state1 = state2 = state3 = NULL;
	internalType = TABLE;
	numStripes = 0;
}


grVtxTable::~grVtxTable()
{
	ssgDeRefDelete(texcoords1);
	ssgDeRefDelete(texcoords2);
	ssgDeRefDelete(texcoords3);

	if(internalType == ARRAY) {
		ssgDeRefDelete(indices);
		ssgDeRefDelete(stripes);
	}

	ssgDeRefDelete(state1);
	ssgDeRefDelete(state2);
	ssgDeRefDelete(state3);
}


void grVtxTable::setState1(ssgState* st)
{
	ssgDeRefDelete(state1);

	state1 = (grMultiTexState*)st;

	if(state1 != NULL) {
		state1->ref();
	}
}


void grVtxTable::setState2(ssgState* st)
{
	ssgDeRefDelete(state2);

	state2 = (grMultiTexState*)st;

	if(state2 != NULL) {
		state2->ref();
	}
}


void grVtxTable::setState3(ssgState* st)
{
	ssgDeRefDelete(state3);

	state3 = (grMultiTexState*)st;

	if(state3 != NULL) {
		state3->ref();
	}
}


void grVtxTable::draw()
{
	if(!preDraw()) {
		return;
	}

//	LogError("inside grVtxTable::draw: hasState() = %d", hasState()); // TODO: delete later
	if(hasState()) {
		getState()->apply();
	}

	if(internalType == TABLE) {
		draw_geometry(); // ssgVtxTable::draw_geometry();
	} else {
//		LogError("inside grVtxTable::draw: mapLevelBitmap = %d maxTextureUnits = %d", mapLevelBitmap, maxTextureUnits); // TODO: delete later
		draw_geometry_array();
	}

	if(postDrawCB != NULL) {
		(*postDrawCB)(this);
	}
}


void grVtxTable::draw_geometry_array()
{
	const auto& aProg = setArrayBuffers();
//	LogError("grVtxTable::draw_geometry_array ModelViewMatrix:"); // TODO: delete later
//	const auto& cameraMatrix = *(mat4*)&g_mAffineTrans[0].x; // TODO: delete later
//	LogInfo("%16g%16g%16g%16g", cameraMatrix[0].x, cameraMatrix[0].y, cameraMatrix[0].z, cameraMatrix[0].w); // TODO: delete later
//	LogInfo("%16g%16g%16g%16g", cameraMatrix[1].x, cameraMatrix[1].y, cameraMatrix[1].z, cameraMatrix[1].w); // TODO: delete later
//	LogInfo("%16g%16g%16g%16g", cameraMatrix[2].x, cameraMatrix[2].y, cameraMatrix[2].z, cameraMatrix[2].w); // TODO: delete later
//	LogInfo("%16g%16g%16g%16g", cameraMatrix[3].x, cameraMatrix[3].y, cameraMatrix[3].z, cameraMatrix[3].w); // TODO: delete later
//	LogError("grVtxTable::draw_geometry_array ProjectionMatrix:"); // TODO: delete later
//	const auto& projectMatrix = *(mat4*)&g_pCamera->vAxis0.x; // TODO: delete later
//	LogInfo("%16g%16g%16g%16g", projectMatrix[0].x, projectMatrix[0].y, projectMatrix[0].z, projectMatrix[0].w); // TODO: delete later
//	LogInfo("%16g%16g%16g%16g", projectMatrix[1].x, projectMatrix[1].y, projectMatrix[1].z, projectMatrix[1].w); // TODO: delete later
//	LogInfo("%16g%16g%16g%16g", projectMatrix[2].x, projectMatrix[2].y, projectMatrix[2].z, projectMatrix[2].w); // TODO: delete later
//	LogInfo("%16g%16g%16g%16g", projectMatrix[3].x, projectMatrix[3].y, projectMatrix[3].z, projectMatrix[3].w); // TODO: delete later

	if(numMapLevel > 1) {
		state1->apply(1);
	}

//	if(numMapLevel > 2) {
//		state2->apply(2);
//	}

	glEnable(GL_TEXTURE_2D);

//	glPushClientAttrib(GL_CLIENT_VERTEX_ARRAY_BIT);

	if(num_texcoords > 1) {
		if(numMapLevel > 1) {
//			glClientActiveTextureARB(GL_TEXTURE1_ARB);
//			glClientActiveTexture(GL_TEXTURE1);
//			glEnableClientState(GL_TEXTURE_COORD_ARRAY);
//			glTexCoordPointer(2, GL_FLOAT, 0, texcoords1->get(0));
		}

		if(numMapLevel > 2) {
//			glClientActiveTextureARB(GL_TEXTURE2_ARB);
//			glClientActiveTexture(GL_TEXTURE2);
//			glEnableClientState(GL_TEXTURE_COORD_ARRAY);
//			glTexCoordPointer(2, GL_FLOAT, 0, texcoords2->get(0));
		}

	}

//	LogInfo("inside grVtxTable::draw_geometry_array: gltype = 0x%04x maxTextureUnits = %d", gltype, maxTextureUnits); // TODO: delete later

	num_indices = 0;
	for(int j = 0; j < numStripes; j++) {
		int i = *(stripes->get(j));
		auto ii = offset_indices < 0 ? indices->get(num_indices) : (GLshort*)offset_indices+num_indices;
		if(g_iDrawScene > 0) glDrawElements(gltype, i, GL_UNSIGNED_SHORT, ii);
		num_indices += i;
	}
	disableVertexAttributes(aProg);

//	glPopClientAttrib ();
	if(numMapLevel > 1) {
//		glActiveTextureARB(GL_TEXTURE1_ARB);
		glActiveTexture(GL_TEXTURE1);
		glDisable(GL_TEXTURE_2D);
	}

	if(numMapLevel > 2) {
//		glActiveTextureARB(GL_TEXTURE2_ARB);
		glActiveTexture(GL_TEXTURE2);
		glDisable(GL_TEXTURE_2D);
	}
}
