/***************************************************************************

    file                 : grmain.h
    created              : Fri Aug 18 00:00:41 CEST 2000
    copyright            : (C) 2000-2013 by Eric Espie, Bernhard Wymann
    email                : torcs@free.fr
    version              : $Id: grmain.h,v 1.18.2.2 2013/09/01 10:24:22 berniw Exp $

 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/


#ifndef _GRMAIN_H_
#define _GRMAIN_H_

#include <ssg.h>
#include <raceman.h>

extern int grWinx, grWiny, grWinw, grWinh;

extern void* grHandle;
extern void* grTrackHandle;

extern ssgContext grContext;
extern int grNbCars;

extern int initView(int x, int y, int width, int height, int flag, void* screen);
extern int initCars(tSituation* s);
extern int refresh(tSituation* s);
extern void shutdownCars();
extern int initTrack(tTrack* track);
extern void shutdownTrack();
extern void muteForMenu();
const int maxTextureUnits = 1; // Single texture only
extern tdble grMaxDammage;

extern class cGrScreen* grScreens[];

#define GR_SPLIT_ADD 0
#define GR_SPLIT_REM 1
#define GR_NB_MAX_SCREEN 4

extern tdble grLodFactorValue;

enum EWheelDetail
{
	DETAILED, SIMPLE
};
extern EWheelDetail grUseDetailedWheels;

inline float urandom()
{
	return (((float)rand()/(1.0f+(float)RAND_MAX)));
}


#endif /* _GRMAIN_H_ */
