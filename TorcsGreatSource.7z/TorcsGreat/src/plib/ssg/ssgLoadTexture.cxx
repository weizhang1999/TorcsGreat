/*
     PLIB - A Suite of Portable Game Libraries
     Copyright (C) 1998,2002  Steve Baker

     This library is free software; you can redistribute it and/or
     modify it under the terms of the GNU Library General Public
     License as published by the Free Software Foundation; either
     version 2 of the License, or (at your option) any later version.

     This library is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
     Library General Public License for more details.

     You should have received a copy of the GNU Library General Public
     License along with this library; if not, write to the Free Software
     Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA

     For further information visit http://plib.sourceforge.net

     $Id: ssgLoadTexture.cxx 2128 2007-10-03 02:42:32Z fayjf $
*/


#include "ssgLocal.h"
#include <sys/stat.h>
#include "android_jni.h"


struct _ssgTextureFormat
{
	const char* extension;
	bool (* loadfunc)(const char*, ssgTextureInfo* info);
};


enum
{
	MAX_FORMATS = 100
};

static _ssgTextureFormat formats[MAX_FORMATS];
static int num_formats = 0;

//bool ssgMakeMipMaps(GLubyte* image, int xsize, int ysize, int zsize, bool freeData)
//{
//	bool non_power_of_two_tex_supported = ssgIsExtensionSupported(const_cast<char*>("GL_ARB_texture_non_power_of_two"));
//	if(!non_power_of_two_tex_supported && ((xsize&(xsize-1)) != 0 || (ysize&(ysize-1)) != 0)) {
//		ulSetError(UL_WARNING, "Map is not a power-of-two in size!");
//		return false;
//	}
//
//	auto eFormat = (zsize == 1) ? GL_LUMINANCE : (zsize == 2) ? GL_LUMINANCE_ALPHA : (zsize == 3) ? GL_RGB : GL_RGBA;
//	if(eFormat == GL_LUMINANCE) LogInfo("inside ssgMakeMipMaps eFormat == GL_LUMINANCE"); // TODO: delete later
//	if(eFormat == GL_RGB) LogInfo("inside ssgMakeMipMaps eFormat == GL_RGB"); // TODO: delete later
//	ax_Build2DMipmaps(eFormat, (GLenum)eFormat, xsize, ysize, image);
//	if(freeData) {
//		delete[] image;
//	}
////	LogInfo("inside ssgMakeMipMaps: xsize = %d ysize = %d eFormat = %04x", xsize, ysize, eFormat); // TODO: delete later
//	return true;
//}


//static void ssgLoadDummyTexture(ssgTextureInfo* info)
//{
//	GLubyte* image = new GLubyte[2*2*3];
//
//	/* Red and white chequerboard */
//
//	image[0] = 255;
//	image[1] = 0;
//	image[2] = 0;
//	image[3] = 255;
//	image[4] = 255;
//	image[5] = 255;
//	image[6] = 255;
//	image[7] = 255;
//	image[8] = 255;
//	image[9] = 255;
//	image[10] = 0;
//	image[11] = 0;
//
//	if(info != NULL) {
//		info->width = 2;
//		info->height = 2;
//		info->depth = 3;
//		info->alpha = 0;
//	}
//
//	ssgMakeMipMaps(image, 2, 2, 3);
//}


void ssgAddTextureFormat(const char* extension, bool (* loadfunc)(const char*, ssgTextureInfo* info))
{
	for(int i = 0; i < num_formats; i++) {
		if(ulStrEqual(formats[i].extension, extension)) {
			formats[i].extension = extension;
			formats[i].loadfunc = loadfunc;
			return;
		}
	}

	if(num_formats < MAX_FORMATS) {
		formats[num_formats].extension = extension;
		formats[num_formats].loadfunc = loadfunc;
		num_formats++;
	} else {
		ulSetError(UL_WARNING, "ssgAddTextureFormat: too many formats");
	}
}


bool ssgLoadTexture(const char* filename, ssgTextureInfo* info)
{
	if(info != NULL) {
		info->width = 0;
		info->height = 0;
		info->depth = 0;
		info->alpha = 0;
	}

	if(filename == NULL || *filename == '\0') {
		return false;
	}

	//find extension
	const char* extn = &(filename[strlen(filename)]);
	while(extn != filename && *extn != '/' && *extn != '.') {
		extn--;
	}

	if(*extn != '.') {
		ulSetError(UL_WARNING, "ssgLoadTexture: Cannot determine file type for '%s'", filename);
//		ssgLoadDummyTexture(info);
		return false;
	}

//	LogInfo("inside ssgLoadTexture: filename = %s num_formats = %d extn = %s", filename, num_formats, extn); // TODO: delete later
	_ssgTextureFormat* f = formats;
	for(int i = 0; i < num_formats; i++, f++) {
		if(f->loadfunc != NULL && ulStrNEqual(extn, f->extension, strlen(f->extension))) {
			const int BUFSIZE = 1024;
			char file[BUFSIZE];
			snprintf(file, BUFSIZE, "%s%s", *filename == '/' ? "" : GetAppPath(), filename); // Absolute or relative path
			if(f->loadfunc(file, info)) {
//				LogInfo("inside ssgLoadTexture: i = %d f->extension = %s (success)", i, f->extension); // TODO: delete later
				return true;
			}
			LogError("inside ssgLoadTexture: f->loadfunc = %p i = %d filename = %s (failure)", f->loadfunc, i, filename); // TODO: delete later
//			ssgLoadDummyTexture(info); /* fail */
			return false;
		}
	}
	return false;
}
