/*
     PLIB - A Suite of Portable Game Libraries
     Copyright (C) 1998,2002  Steve Baker

     This library is free software; you can redistribute it and/or
     modify it under the terms of the GNU Library General Public
     License as published by the Free Software Foundation; either
     version 2 of the License, or (at your option) any later version.

     This library is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
     Library General Public License for more details.

     You should have received a copy of the GNU Library General Public
     License along with this library; if not, write to the Free Software
     Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA

     For further information visit http://plib.sourceforge.net

     $Id: ssgContext.cxx 1736 2002-12-02 15:04:06Z sjbaker $
*/


#include "ssgLocal.h"
#include "android_jni.h"
#include "grmain.h"

ssgContext* _ssgCurrentContext = NULL;

ssgContext::~ssgContext()
{
	if(isCurrent()) {
		_ssgCurrentContext = NULL;
	}

	//~~ T.G. was ordinary delete before - must be derefed
	ssgDeRefDelete(currentState);
	ssgDeRefDelete(basicState);

	delete frustum;
}


ssgContext::ssgContext()
{
	makeCurrent();
	currentState = NULL;
	basicState = NULL;
	cullFace = TRUE;
	ovTexture = FALSE;
	ovCullface = FALSE;
	ovState = NULL;
	sgCopyMat4(cameraMatrix, _ssgOpenGLAxisSwapMatrix);

	frustum = new sgFrustum;
	frustum->setNearFar(1.0, 10000.0);
	frustum->setFOV(60.0, 45.0);

	currentState = new ssgSimpleState(1);
	currentState->ref(); //~~ T.G.

	basicState = new ssgSimpleState(0);
	basicState->ref(); //~~ T.G.

	currentState->force();

	/* The order of the two following lines is essential.
	   setTexture(NULL) currently sets the TEXTURE bit in
	   dont_care... not the desired effect here. /PL */

	basicState->setTexture((ssgTexture*)NULL);
	basicState->dont_care = 0;
	basicState->colour_material_mode = GL_AMBIENT_AND_DIFFUSE;
	sgSetVec4(basicState->specular_colour, 1.0f, 1.0f, 1.0f, 1.0f);
	sgSetVec4(basicState->emission_colour, 0.0f, 0.0f, 0.0f, 1.0f);
	sgSetVec4(basicState->ambient_colour, 1.0f, 1.0f, 1.0f, 1.0f);
	sgSetVec4(basicState->diffuse_colour, 1.0f, 1.0f, 1.0f, 1.0f);
//	basicState->shade_model = GL_SMOOTH;
	basicState->shininess = 0.0f;
	basicState->alpha_clamp = 0.01f;

	for(int i = 0; i < 6; i++) {
		sgSetVec4(clipPlane[i], 0, 0, 1, 0);
	}

	enabledClipPlanes = 0;
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
}

int ssgContext::isCurrent()
{
	return _ssgCurrentContext == this;
}

void ssgContext::forceBasicState()
{
	if(!ovCullface) {
		glEnable(GL_CULL_FACE);
	}

	cullFace = TRUE;

	if(ovState != NULL) {
		ovState->force();
	} else {
		basicState->force();
	}
}

void ssgContext::makeCurrent()
{
	_ssgCurrentContext = this;
	grContext = this;
}

void ssgContext::getCameraPosition(sgVec3 pos)
{
	sgCopyVec3(pos, cameraMatrix[3]);
}

void ssgContext::overrideState(ssgState* s)
{
	ovState = s;
}

void ssgContext::overrideTexture(int on_off)
{
	ovTexture = on_off;
}

void ssgContext::overrideCullface(int on_off)
{
	ovCullface = on_off;
}

void ssgContext::setFrustum(float l, float r, float b, float t, float n, float f)
{
	frustum->setFrustum(l, r, b, t, n, f);
}

void ssgContext::setOrtho(float l, float r, float b, float t, float n, float f)
{
	frustum->setOrtho(l, r, b, t, n, f);
}

void ssgContext::getNearFar(float* n, float* f)
{
	frustum->getNearFar(n, f);
}

void ssgContext::getFOV(float* w, float* h)
{
	frustum->getFOV(w, h);
}

void ssgContext::setNearFar(float n, float f)
{
	frustum->setNearFar(n, f);
}

void ssgContext::getOrtho(float* w, float* h)
{
	frustum->getOrtho(w, h);
}

void ssgContext::setOrtho(float w, float h)
{
	frustum->setOrtho(w, h);
}

void ssgContext::setFOV(float w, float h)
{
	frustum->setFOV(w, h);
}


void ssgContext::setCamera(sgMat4 mat)
{
	sgMat4 viewmat;

	sgTransposeNegateMat4(viewmat, mat);

	sgCopyMat4(cameraMatrix, _ssgOpenGLAxisSwapMatrix);
	sgPreMultMat4(cameraMatrix, viewmat);
}

void ssgContext::setCamera(const sgCoord* coord)
{
	sgMat4 viewmat, mat;

	sgMakeCoordMat4(mat, coord);
	sgTransposeNegateMat4(viewmat, mat);

	sgCopyMat4(cameraMatrix, _ssgOpenGLAxisSwapMatrix);
	sgPreMultMat4(cameraMatrix, viewmat);
}

void ssgContext::setCameraLookAt(const sgVec3 eye, const sgVec3 center, const sgVec3 up)
{
	sgMat4 mat;
	sgMakeLookAtMat4(mat, eye, center, up);
	setCamera(mat);
}

void ssgContext::setCameraLookAt(const sgVec3 eye, const sgVec3 center)
{
	sgVec3 up;
	sgSetVec3(up, 0.0f, 0.0f, 1.0f);

	sgMat4 mat;
	sgMakeLookAtMat4(mat, eye, center, up);

	setCamera(mat);
}

void ssgContext::loadProjectionMatrix()
{
//	glLoadIdentity();
	pushProjectionMatrix();
}

void ssgContext::pushProjectionMatrix()
{
	pushProjectionMatrix(frustum);
}

void ssgContext::pushProjectionMatrix(sgFrustum* f)
{
	const auto left = f->getLeft();
	const auto right = f->getRight();
	const auto bottom = f->getBot();
	const auto top = f->getTop();
	const auto near = f->getNear();
	const auto far = f->getFar();
	auto matrix = &g_pCamera->vAxis0.x;
	if(f->isOrtho()) {
//		glOrthof(f->getLeft(), f->getRight(), f->getBot(), f->getTop(), f->getNear(), f->getFar());
		matrix[0] = 2.0f/(right-left);
		matrix[4] = 0.0f;
		matrix[8] = 0.0f;
		matrix[12] = -(right+left)/(right-left);
		matrix[1] = 0.0f;
		matrix[5] = 2.0f/(top-bottom);
		matrix[9] = 0.0f;
		matrix[13] = -(top+bottom)/(top-bottom);
		matrix[2] = 0.0f;
		matrix[6] = 0.0f;
		matrix[10] = -2.0f/(far-near);
		matrix[14] = -(far+near)/(far-near);
		matrix[3] = 0.0f;
		matrix[7] = 0.0f;
		matrix[11] = 0.0f;
		matrix[15] = 1.0f;
//		g_vDisplayScale = {2.0f/(f->getRight()-f->getLeft()-1), 2.0f/(f->getTop()-f->getBot()-1)};
	} else {
//		glFrustumf(f->getLeft(), f->getRight(), f->getBot(), f->getTop(), f->getNear(), f->getFar());
		matrix[0] = 2*near/(right-left);
		matrix[4] = 0;
		matrix[8] = (right+left)/(right-left);
		matrix[12] = 0;
		matrix[1] = 0;
		matrix[5] = 2*near/(top-bottom);
		matrix[9] = (top+bottom)/(top-bottom);
		matrix[13] = 0;
		matrix[2] = 0;
		matrix[6] = 0;
		matrix[10] = -(far+near)/(far-near);
		matrix[14] = -2*far*near/(far-near);
		matrix[3] = 0;
		matrix[7] = 0;
		matrix[11] = -1;
		matrix[15] = 0;
	}
}

void ssgContext::getProjectionMatrix(sgMat4 dst)
{
	frustum->getMat4(dst);
}

void ssgContext::getModelviewMatrix(sgMat4 dst)
{
	sgCopyMat4(dst, cameraMatrix);
}

void ssgContext::loadModelviewMatrix()
{
//	glLoadMatrixf((float*)cameraMatrix);
//	LogError("ssgContext::loadModelviewMatrix:"); // TODO: delete later
//	LogInfo("%16g%16g%16g%16g", cameraMatrix[0][0], cameraMatrix[0][1], cameraMatrix[0][2], cameraMatrix[0][3]); // TODO: delete later
//	LogInfo("%16g%16g%16g%16g", cameraMatrix[1][0], cameraMatrix[1][1], cameraMatrix[1][2], cameraMatrix[1][3]); // TODO: delete later
//	LogInfo("%16g%16g%16g%16g", cameraMatrix[2][0], cameraMatrix[2][1], cameraMatrix[2][2], cameraMatrix[2][3]); // TODO: delete later
//	LogInfo("%16g%16g%16g%16g", cameraMatrix[3][0], cameraMatrix[3][1], cameraMatrix[3][2], cameraMatrix[3][3]); // TODO: delete later
	memcpy(&g_mAffineTrans[0].x, cameraMatrix, sizeof(g_mAffineTrans));
}

void ssgContext::loadModelviewMatrix(sgMat4 mat)
{
//	glLoadMatrixf((float*)mat);
}

void ssgContext::cull(ssgBranch* r)
{
//	LogInfo("inside ssgContext::cull: frustum = %p", frustum); // TODO: delete later
//	LogInfo("%16g%16g%16g%16g", cameraMatrix[0][0], cameraMatrix[0][1], cameraMatrix[0][2], cameraMatrix[0][3]); // TODO: delete later
//	LogInfo("%16g%16g%16g%16g", cameraMatrix[1][0], cameraMatrix[1][1], cameraMatrix[1][2], cameraMatrix[1][3]); // TODO: delete later
//	LogInfo("%16g%16g%16g%16g", cameraMatrix[2][0], cameraMatrix[2][1], cameraMatrix[2][2], cameraMatrix[2][3]); // TODO: delete later
//	LogInfo("%16g%16g%16g%16g", cameraMatrix[3][0], cameraMatrix[3][1], cameraMatrix[3][2], cameraMatrix[3][3]); // TODO: delete later
//	sgVec3 eye = {0, 0, 0};
//	sgVec3 center = {0, 0, 0};
//	sgVec3 up = {0, 0, 0};
//	getCameraPosition(eye);
//	getCameraPosition(center);
//	getCameraPosition(up);
//	LogInfo("eye = %16g%16g%16g", eye[0], eye[1], eye[2]); // TODO: delete later
	r->cull(frustum, cameraMatrix, TRUE);
}


void ssgContext::removeClipPlanes()
{
//	for(int i = 0; i < 6; i++) {
//		glDisable((GLenum)(GL_CLIP_PLANE0+i));
//	}
}

void ssgContext::applyClipPlanes()
{
	if(enabledClipPlanes == 0) {
		return;
	}

//	LogError("ssgContext::applyClipPlanes: need implementation!"); // TODO: delete later
//	for(int i = 0; i < 6; i++) {
//		if(enabledClipPlanes&(1<<i)) {
//			glClipPlanef((GLenum)(GL_CLIP_PLANE0+i), clipPlane[i]);
//			glEnable((GLenum)(GL_CLIP_PLANE0+i));
//		} else {
//			glDisable((GLenum)(GL_CLIP_PLANE0+i));
//		}
//	}
}
