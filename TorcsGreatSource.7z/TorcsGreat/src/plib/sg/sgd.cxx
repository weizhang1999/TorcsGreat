/*
     PLIB - A Suite of Portable Game Libraries
     Copyright (C) 1998,2002  Steve Baker

     This library is free software; you can redistribute it and/or
     modify it under the terms of the GNU Library General Public
     License as published by the Free Software Foundation; either
     version 2 of the License, or (at your option) any later version.

     This library is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
     Library General Public License for more details.

     You should have received a copy of the GNU Library General Public
     License along with this library; if not, write to the Free Software
     Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA

     For further information visit http://plib.sourceforge.net

     $Id: sgd.cxx 1944 2004-08-05 01:07:09Z puggles $
*/


#include "sg.h"

int sgdCompare3DSqdDist(const sgdVec3 v1, const sgdVec3 v2, const SGDfloat sqd_dist)
{
	sgdVec3 tmp;

	sgdSubVec3(tmp, v2, v1);

	SGDfloat sqdist = tmp[0]*tmp[0]+tmp[1]*tmp[1]+tmp[2]*tmp[2];

	if(sqdist > sqd_dist) return 1;
	if(sqdist < sqd_dist) return -1;
	return 0;
}


/*********************\
*    sgdBox routines   *
\*********************/


void sgdBox::extend(const sgdVec3 v)
{
	if(isEmpty()) {
		sgdCopyVec3(min, v);
		sgdCopyVec3(max, v);
	} else {
		if(v[0] < min[0]) min[0] = v[0];
		if(v[1] < min[1]) min[1] = v[1];
		if(v[2] < min[2]) min[2] = v[2];
		if(v[0] > max[0]) max[0] = v[0];
		if(v[1] > max[1]) max[1] = v[1];
		if(v[2] > max[2]) max[2] = v[2];
	}
}


/**********************\
*  sgdSphere routines   *
\**********************/

void sgdSphere::extend(const sgdVec3 v)
{
	if(isEmpty()) {
		sgdCopyVec3(center, v);
		radius = SGD_ZERO;
		return;
	}

	SGDfloat d = sgdDistanceVec3(center, v);

	if(d <= radius) {  /* Point is already inside sphere */
		return;
	}

	SGDfloat new_radius = (radius+d)/SGD_TWO;  /* Grow radius */

	SGDfloat ratio = (new_radius-radius)/d;

	center[0] += (v[0]-center[0])*ratio;    /* Move center */
	center[1] += (v[1]-center[1])*ratio;
	center[2] += (v[2]-center[2])*ratio;

	radius = new_radius;
}


int sgdSphere::intersects(const sgdBox* b) const
{
	sgdVec3 closest;

	if(b->getMin()[0] > center[0]) { closest[0] = b->getMin()[0]; }
	else if(b->getMax()[0] < center[0]) { closest[0] = b->getMax()[0]; }
	else {
		closest[0] = center[0];
	}

	if(b->getMin()[1] > center[1]) { closest[1] = b->getMin()[1]; }
	else if(b->getMax()[1] < center[1]) { closest[1] = b->getMax()[1]; }
	else {
		closest[1] = center[1];
	}

	if(b->getMin()[2] > center[2]) { closest[2] = b->getMin()[2]; }
	else if(b->getMax()[2] < center[2]) { closest[2] = b->getMax()[2]; }
	else {
		closest[2] = center[2];
	}

	return sgdCompare3DSqdDist(closest, center, sgdSquare(radius)) <= 0;
}


/************************\
*   sgdFrustum routines   *
\************************/

void sgdFrustum::update()
{
	if(fabs(ffar-nnear) < 0.1) {
		ulSetError(UL_WARNING, "sgdFrustum: Can't support depth of view <0.1 units.");
		return;
	}

	if(hfov != SGD_ZERO && vfov != SGD_ZERO) {
		if(fabs(hfov) < 0.1 || fabs(vfov) < 0.1) {
			ulSetError(UL_WARNING,
				ortho ? "sgFrustum: Can't support width or height <0.1 units." : "sgFrustum: Can't support fields of view narrower than 0.1 degrees.");
			return;
		}

		if(ortho) {
			right = SGD_HALF*hfov;
			top = SGD_HALF*vfov;
		} else {
			right = nnear*tan(hfov*SGD_DEGREES_TO_RADIANS/SGD_TWO);
			top = nnear*tan(vfov*SGD_DEGREES_TO_RADIANS/SGD_TWO);
		}

		left = -right;
		bot = -top;
	}


	/* Compute the projection matrix */

	SGDfloat width = right-left;
	SGDfloat height = top-bot;
	SGDfloat depth = ffar-nnear;

	if(ortho) {
		/* orthographic */

		mat[0][0] = SGD_TWO/width;
		mat[0][1] = SGD_ZERO;
		mat[0][2] = SGD_ZERO;
		mat[0][3] = SGD_ZERO;

		mat[1][0] = SGD_ZERO;
		mat[1][1] = SGD_TWO/height;
		mat[1][2] = SGD_ZERO;
		mat[1][3] = SGD_ZERO;

		mat[2][0] = SGD_ZERO;
		mat[2][1] = SGD_ZERO;
		mat[2][2] = -SGD_TWO/depth;
		mat[2][3] = SGD_ZERO;

		mat[3][0] = -(left+right)/width;
		mat[3][1] = -(bot+top)/height;
		mat[3][2] = -(nnear+ffar)/depth;
		mat[3][3] = SGD_ONE;
	} else {
		/* perspective */

		mat[0][0] = SGD_TWO*nnear/width;
		mat[0][1] = SGD_ZERO;
		mat[0][2] = SGD_ZERO;
		mat[0][3] = SGD_ZERO;

		mat[1][0] = SGD_ZERO;
		mat[1][1] = SGD_TWO*nnear/height;
		mat[1][2] = SGD_ZERO;
		mat[1][3] = SGD_ZERO;

		mat[2][0] = (right+left)/width;
		mat[2][1] = (top+bot)/height;
		mat[2][2] = -(ffar+nnear)/depth;
		mat[2][3] = -SGD_ONE;

		mat[3][0] = SGD_ZERO;
		mat[3][1] = SGD_ZERO;
		mat[3][2] = -SGD_TWO*nnear*ffar/depth;
		mat[3][3] = SGD_ZERO;
	}


	/*
	 * The clip planes are derived from the projection matrix.
	 *
	 * After projection (in clip coordinates), the clip planes are simply:
	 *
	 *  left:    (  1,  0,  0,  1 )
	 *  right:   ( -1,  0,  0,  1 )
	 *  bottom:  (  0,  1,  0,  1 )
	 *  top:     (  0, -1,  0,  1 )
	 *  near:    (  0,  0,  1,  1 )
	 *  far:     (  0,  0, -1,  1 )
	 *
	 * These can easily be transformed *backwards* by
	 * multiplying by the transposed projection matrix, i.e:
	 *
	 *  ( A )            ( A')
	 *  ( B )  =  mat^T  ( B')
	 *  ( C )            ( C')
	 *  ( D )            ( D')
	 *
	 * where (A',B',C',D') represents a plane in clip coordinates,
	 * and (A,B,C,D) is the same plane expressed in eye coordinates.
	 */

	sgdSetVec4(plane[SG_LEFT_PLANE], SGD_ONE, SGD_ZERO, SGD_ZERO, SGD_ONE);
	sgdSetVec4(plane[SG_RIGHT_PLANE], -SGD_ONE, SGD_ZERO, SGD_ZERO, SGD_ONE);
	sgdSetVec4(plane[SG_BOT_PLANE], SGD_ZERO, SGD_ONE, SGD_ZERO, SGD_ONE);
	sgdSetVec4(plane[SG_TOP_PLANE], SGD_ZERO, -SGD_ONE, SGD_ZERO, SGD_ONE);
	sgdSetVec4(plane[SG_NEAR_PLANE], SGD_ZERO, SGD_ZERO, SGD_ONE, SGD_ONE);
	sgdSetVec4(plane[SG_FAR_PLANE], SGD_ZERO, SGD_ZERO, -SGD_ONE, SGD_ONE);

	for(int i = 0; i < 6; i++) {
		sgdVec4 tmp;

		for(int j = 0; j < 4; j++) {
			tmp[j] = sgdScalarProductVec4(plane[i], mat[j]);
		}

		sgdScaleVec4(plane[i], tmp, SGD_ONE/sgdLengthVec3(tmp));
	}
}


#define OC_LEFT_SHIFT   0
#define OC_RIGHT_SHIFT  1
#define OC_TOP_SHIFT    2
#define OC_BOT_SHIFT    3
#define OC_NEAR_SHIFT   4
#define OC_FAR_SHIFT    5

#define OC_ALL_ON_SCREEN 0x3F
//#define OC_OFF_TRF      ((1<<OC_TOP_SHIFT)|(1<<OC_RIGHT_SHIFT)|(1<<OC_FAR_SHIFT))
//#define OC_OFF_BLN      ((1<<OC_BOT_SHIFT)|(1<<OC_LEFT_SHIFT)|(1<<OC_NEAR_SHIFT))

int sgdFrustum::getOutcode(const sgdVec3 pt) const
{
	/* Transform the point by the Frustum's transform. */

	sgdVec4 tmp;

	tmp[0] = pt[0];
	tmp[1] = pt[1];
	tmp[2] = pt[2];
	tmp[3] = SGD_ONE;

	sgdXformPnt4(tmp, tmp, mat);

	/*
	  No need to divide by the 'w' component since we are only checking for
	  results in the range 0..1
	*/

	return ((tmp[0] <= tmp[3])<<OC_RIGHT_SHIFT)|((tmp[0] >= -tmp[3])<<OC_LEFT_SHIFT)|((tmp[1] <= tmp[3])<<OC_TOP_SHIFT)|
		((tmp[1] >= -tmp[3])<<OC_BOT_SHIFT)|((tmp[2] <= tmp[3])<<OC_FAR_SHIFT)|((tmp[2] >= -tmp[3])<<OC_NEAR_SHIFT);
}

int sgdFrustum::contains(const sgdVec3 pt) const
{
	return getOutcode(pt) == OC_ALL_ON_SCREEN;
}


int sgdFrustum::contains(const sgdSphere* s) const
{

	const SGDfloat* center = s->getCenter();
	const SGDfloat radius = s->getRadius();

	/*
	  Lop off half the database (roughly) with a quick near-plane test - and
	  lop off a lot more with a quick far-plane test
	*/

	if(-center[2]+radius < nnear || -center[2]-radius > ffar) {
		return SG_OUTSIDE;
	}

	/*
	  OK, so the sphere lies between near and far.

	  Measure the distance of the center point from the four sides of the frustum,
	  if it's outside by more than the radius then it's history.

	  It's tempting to do a quick test to see if the center point is
	  onscreen using sgdFrustumContainsPt - but that takes a matrix transform
	  which is 16 multiplies and 12 adds - versus this test which does the
	  whole task using only 12 multiplies and 8 adds.
	*/

	/*
	  A few operations are saved by observing that certain values in the plane
	  equations are zero or one. These are specific to orthographic and perspective
	  projections respectively.
	*/

	SGDfloat sp1, sp2, sp3, sp4;

	if(ortho) {
		/*
		  left:    (  1,  0,  0,  x  )
		  right:   ( -1,  0,  0,  x  )
		  bottom:  (  0,  1,  0,  x  )
		  top:     (  0, -1,  0,  x  )
		*/
		sp1 = plane[SG_LEFT_PLANE][3]+center[0];
		sp2 = plane[SG_RIGHT_PLANE][3]-center[0];
		sp3 = plane[SG_BOT_PLANE][3]+center[1];
		sp4 = plane[SG_TOP_PLANE][3]-center[1];
	} else {
		/*
		  left:    (  x,  0,  x,  0  )
		  right:   (  x,  0,  x,  0  )
		  bottom:  (  0,  x,  x,  0  )
		  top:     (  0,  x,  x,  0  )
		*/
		sp1 = plane[SG_LEFT_PLANE][0]*center[0]+plane[SG_LEFT_PLANE][2]*center[2];
		sp2 = plane[SG_RIGHT_PLANE][0]*center[0]+plane[SG_RIGHT_PLANE][2]*center[2];
		sp3 = plane[SG_BOT_PLANE][1]*center[1]+plane[SG_BOT_PLANE][2]*center[2];
		sp4 = plane[SG_TOP_PLANE][1]*center[1]+plane[SG_TOP_PLANE][2]*center[2];
	}

	/*
	   Note: in the general case, we would have to do:

	   sp1 = sgdScalarProductVec3 (  left_plane, center ) +  left_plane[3] ;
	   sp2 = sgdScalarProductVec3 ( right_plane, center ) + right_plane[3] ;
	   ...
	   sp6 = sgdScalarProductVec3 (   far_plane, center ) +   far_plane[3] ;
	*/


	if(-sp1 > radius || -sp2 > radius || -sp3 > radius || -sp4 > radius) {
		return SG_OUTSIDE;
	}

	/*
	  If it's inside by more than the radius then it's *completely* inside
	  and we can save time elsewhere if we know that for sure.
	*/

	if(sp1 >= radius && sp2 >= radius && sp3 >= radius && sp4 >= radius && -center[2]-radius >= nnear && -center[2]+radius <= ffar) {
		return SG_INSIDE;
	}

	return SG_STRADDLE;
}


int sgdFrustum::contains(const sgdBox* b) const
{
	sgdVec3 p[8] = {{b->getMin()[0], b->getMin()[1], b->getMin()[2]},
					{b->getMax()[0], b->getMin()[1], b->getMin()[2]},
					{b->getMin()[0], b->getMax()[1], b->getMin()[2]},
					{b->getMax()[0], b->getMax()[1], b->getMin()[2]},
					{b->getMin()[0], b->getMin()[1], b->getMax()[2]},
					{b->getMax()[0], b->getMin()[1], b->getMax()[2]},
					{b->getMin()[0], b->getMax()[1], b->getMax()[2]},
					{b->getMax()[0], b->getMax()[1], b->getMax()[2]},};

	int all = -1;
	int one = 0;

	for(int i = 0; i < 8; i++) {
		int tmp = ~getOutcode(p[i]);
		all &= tmp;
		one |= tmp;
	}

	return (all ? SG_OUTSIDE : one ? SG_STRADDLE : SG_INSIDE);
}


void sgdMakeCoordMat4(sgdMat4 m, const SGDfloat x, const SGDfloat y, const SGDfloat z, const SGDfloat h, const SGDfloat p, const SGDfloat r)
{
	SGDfloat ch, sh, cp, sp, cr, sr, srsp, crsp, srcp;

	if(h == SGD_ZERO) {
		ch = SGD_ONE;
		sh = SGD_ZERO;
	} else {
		sh = sgdSin(h);
		ch = sgdCos(h);
	}

	if(p == SGD_ZERO) {
		cp = SGD_ONE;
		sp = SGD_ZERO;
	} else {
		sp = sgdSin(p);
		cp = sgdCos(p);
	}

	if(r == SGD_ZERO) {
		cr = SGD_ONE;
		sr = SGD_ZERO;
		srsp = SGD_ZERO;
		srcp = SGD_ZERO;
		crsp = sp;
	} else {
		sr = sgdSin(r);
		cr = sgdCos(r);
		srsp = sr*sp;
		crsp = cr*sp;
		srcp = sr*cp;
	}

	m[0][0] = ch*cr-sh*srsp;
	m[1][0] = -sh*cp;
	m[2][0] = sr*ch+sh*crsp;
	m[3][0] = x;

	m[0][1] = cr*sh+srsp*ch;
	m[1][1] = ch*cp;
	m[2][1] = sr*sh-crsp*ch;
	m[3][1] = y;

	m[0][2] = -srcp;
	m[1][2] = sp;
	m[2][2] = cr*cp;
	m[3][2] = z;

	m[0][3] = SGD_ZERO;
	m[1][3] = SGD_ZERO;
	m[2][3] = SGD_ZERO;
	m[3][3] = SGD_ONE;
}


void sgdXformPnt3(sgdVec3 dst, const sgdVec3 src, const sgdMat4 mat)
{
	SGDfloat t0 = src[0];
	SGDfloat t1 = src[1];
	SGDfloat t2 = src[2];

	dst[0] = (t0*mat[0][0]+t1*mat[1][0]+t2*mat[2][0]+mat[3][0]);

	dst[1] = (t0*mat[0][1]+t1*mat[1][1]+t2*mat[2][1]+mat[3][1]);

	dst[2] = (t0*mat[0][2]+t1*mat[1][2]+t2*mat[2][2]+mat[3][2]);
}


void sgdXformPnt4(sgdVec4 dst, const sgdVec4 src, const sgdMat4 mat)
{
	SGDfloat t0 = src[0];
	SGDfloat t1 = src[1];
	SGDfloat t2 = src[2];
	SGDfloat t3 = src[3];

	dst[0] = (t0*mat[0][0]+t1*mat[1][0]+t2*mat[2][0]+t3*mat[3][0]);

	dst[1] = (t0*mat[0][1]+t1*mat[1][1]+t2*mat[2][1]+t3*mat[3][1]);

	dst[2] = (t0*mat[0][2]+t1*mat[1][2]+t2*mat[2][2]+t3*mat[3][2]);

	dst[3] = (t0*mat[0][3]+t1*mat[1][3]+t2*mat[2][3]+t3*mat[3][3]);
}
