/*
     PLIB - A Suite of Portable Game Libraries
     Copyright (C) 1998,2002  Steve Baker

     This library is free software; you can redistribute it and/or
     modify it under the terms of the GNU Library General Public
     License as published by the Free Software Foundation; either
     version 2 of the License, or (at your option) any later version.

     This library is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
     Library General Public License for more details.

     You should have received a copy of the GNU Library General Public
     License along with this library; if not, write to the Free Software
     Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA

     For further information visit http://plib.sourceforge.net

     $Id: sg.cxx 1944 2004-08-05 01:07:09Z puggles $
*/


#include "sg.h"

//sgVec3 _sgGravity = { 0.0f, 0.0f, -9.8f } ;

void sgVectorProductVec3(sgVec3 dst, const sgVec3 a, const sgVec3 b)
{
	dst[0] = a[1]*b[2]-a[2]*b[1];
	dst[1] = a[2]*b[0]-a[0]*b[2];
	dst[2] = a[0]*b[1]-a[1]*b[0];
}

inline SGfloat _sgClampToUnity(const SGfloat x)
{
	if(x > SG_ONE) return SG_ONE;
	if(x < -SG_ONE) return -SG_ONE;
	return x;
}

int sgCompare3DSqdDist(const sgVec3 v1, const sgVec3 v2, const SGfloat sqd_dist)
{
	sgVec3 tmp;

	sgSubVec3(tmp, v2, v1);

	SGfloat sqdist = tmp[0]*tmp[0]+tmp[1]*tmp[1]+tmp[2]*tmp[2];

	if(sqdist > sqd_dist) return 1;
	if(sqdist < sqd_dist) return -1;
	return 0;
}

void sgMakeRotMat4(sgMat4 mat, const SGfloat angle, const sgVec3 axis)
{
	sgVec3 ax;
	sgNormalizeVec3(ax, axis);

	SGfloat temp_angle = angle*SG_DEGREES_TO_RADIANS;
	SGfloat s = (SGfloat)sin(temp_angle);
	SGfloat c = (SGfloat)cos(temp_angle);
	SGfloat t = SG_ONE-c;

	mat[0][0] = t*ax[0]*ax[0]+c;
	mat[0][1] = t*ax[0]*ax[1]+s*ax[2];
	mat[0][2] = t*ax[0]*ax[2]-s*ax[1];
	mat[0][3] = SG_ZERO;

	mat[1][0] = t*ax[1]*ax[0]-s*ax[2];
	mat[1][1] = t*ax[1]*ax[1]+c;
	mat[1][2] = t*ax[1]*ax[2]+s*ax[0];
	mat[1][3] = SG_ZERO;

	mat[2][0] = t*ax[2]*ax[0]+s*ax[1];
	mat[2][1] = t*ax[2]*ax[1]-s*ax[0];
	mat[2][2] = t*ax[2]*ax[2]+c;
	mat[2][3] = SG_ZERO;

	mat[3][0] = SG_ZERO;
	mat[3][1] = SG_ZERO;
	mat[3][2] = SG_ZERO;
	mat[3][3] = SG_ONE;
}


void sgMakeLookAtMat4(sgMat4 dst, const sgVec3 eye, const sgVec3 center, const sgVec3 up)
{
	// Caveats:
	// 1) In order to compute the line of sight, the eye point must not be equal
	//    to the center point.
	// 2) The up vector must not be parallel to the line of sight from the eye
	//    to the center point.

	/* Compute the direction vectors */
	sgVec3 x, y, z;

	/* Y vector = center - eye */
	sgSubVec3(y, center, eye);

	/* Z vector = up */
	sgCopyVec3(z, up);

	/* X vector = Y cross Z */
	sgVectorProductVec3(x, y, z);

	/* Recompute Z = X cross Y */
	sgVectorProductVec3(z, x, y);

	/* Normalize everything */
	sgNormaliseVec3(x);
	sgNormaliseVec3(y);
	sgNormaliseVec3(z);

	/* Build the matrix */
	sgSetVec4(dst[0], x[0], x[1], x[2], SG_ZERO);
	sgSetVec4(dst[1], y[0], y[1], y[2], SG_ZERO);
	sgSetVec4(dst[2], z[0], z[1], z[2], SG_ZERO);
	sgSetVec4(dst[3], eye[0], eye[1], eye[2], SG_ONE);
}


/*********************\
*    sgBox routines   *
\*********************/


void sgBox::extend(const sgVec3 v)
{
	if(isEmpty()) {
		sgCopyVec3(min, v);
		sgCopyVec3(max, v);
	} else {
		if(v[0] < min[0]) min[0] = v[0];
		if(v[1] < min[1]) min[1] = v[1];
		if(v[2] < min[2]) min[2] = v[2];
		if(v[0] > max[0]) max[0] = v[0];
		if(v[1] > max[1]) max[1] = v[1];
		if(v[2] > max[2]) max[2] = v[2];
	}
}


/**********************\
*  sgSphere routines   *
\**********************/

void sgSphere::extend(const sgVec3 v)
{
	if(isEmpty()) {
		sgCopyVec3(center, v);
		radius = SG_ZERO;
		return;
	}

	SGfloat d = sgDistanceVec3(center, v);

	if(d <= radius) {  /* Point is already inside sphere */
		return;
	}

	SGfloat new_radius = (radius+d)/SG_TWO;  /* Grow radius */

	SGfloat ratio = (new_radius-radius)/d;

	center[0] += (v[0]-center[0])*ratio;    /* Move center */
	center[1] += (v[1]-center[1])*ratio;
	center[2] += (v[2]-center[2])*ratio;

	radius = new_radius;
}


void sgSphere::extend(const sgBox* b)
{
	if(b->isEmpty()) {
		return;
	}

	if(isEmpty()) {
		sgAddVec3(center, b->getMin(), b->getMax());
		sgScaleVec3(center, SG_HALF);
		radius = sgDistanceVec3(center, b->getMax());
		return;
	}

	/*
	  I can't think of a faster way to get an
	  utterly minimal sphere.

	  The tighter algorithm:- enclose each
	  of eight vertices of the box in turn - it
	  looks like being pretty costly.
	  [8 sqrt()'s]

	  The looser algorithm:- enclose the box
	  with an empty sphere and then do a
	  sphere-extend-sphere. This algorithm
	  does well for close-to-cube boxes, but
	  makes very poor spheres for long, thin
	  boxes.
	  [2 sqrt()'s]
	*/

#ifdef DONT_REALLY_NEED_A_TIGHT_SPHERE_EXTEND_BOX

	/* LOOSER/FASTER sphere-around-sphere-around-box */
	sgSphere s ;
	s.empty   ()    ;
	s.enclose ( b ) ;  /* Fast because s is empty */
	  enclose ( s ) ;

#else

	/* TIGHTER/EXPENSIVE sphere-around-eight-points */
	sgVec3 x;
	extend(b->getMin());
	sgSetVec3(x, b->getMin()[0], b->getMin()[1], b->getMax()[2]);
	extend(x);
	sgSetVec3(x, b->getMin()[0], b->getMax()[1], b->getMin()[2]);
	extend(x);
	sgSetVec3(x, b->getMin()[0], b->getMax()[1], b->getMax()[2]);
	extend(x);
	sgSetVec3(x, b->getMax()[0], b->getMin()[1], b->getMin()[2]);
	extend(x);
	sgSetVec3(x, b->getMax()[0], b->getMin()[1], b->getMax()[2]);
	extend(x);
	sgSetVec3(x, b->getMax()[0], b->getMax()[1], b->getMin()[2]);
	extend(x);
	extend(b->getMax());
#endif
}


void sgSphere::extend(const sgSphere* s)
{
	if(s->isEmpty()) {
		return;
	}

	if(isEmpty()) {
		sgCopyVec3(center, s->getCenter());
		radius = s->getRadius();
		return;
	}

	/*
	  d == The distance between the sphere centers
	*/

	SGfloat d = sgDistanceVec3(center, s->getCenter());

	if(d+s->getRadius() <= radius) {  /* New sphere is already inside this one */
		return;
	}

	if(d+radius <= s->getRadius())  /* New sphere completely contains this one */
	{
		sgCopyVec3(center, s->getCenter());
		radius = s->getRadius();
		return;
	}

	/*
	  Build a new sphere that completely contains the other two:

	  The center point lies halfway along the line between
	  the furthest points on the edges of the two spheres.
	  Computing those two points is ugly - so we'll use similar
	  triangles
	*/

	SGfloat new_radius = (radius+d+s->getRadius())/SG_TWO;

	SGfloat ratio = (new_radius-radius)/d;

	center[0] += (s->getCenter()[0]-center[0])*ratio;
	center[1] += (s->getCenter()[1]-center[1])*ratio;
	center[2] += (s->getCenter()[2]-center[2])*ratio;
	radius = new_radius;
}


int sgSphere::intersects(const sgBox* b) const
{
	sgVec3 closest;

	if(b->getMin()[0] > center[0]) { closest[0] = b->getMin()[0]; }
	else if(b->getMax()[0] < center[0]) { closest[0] = b->getMax()[0]; }
	else {
		closest[0] = center[0];
	}

	if(b->getMin()[1] > center[1]) { closest[1] = b->getMin()[1]; }
	else if(b->getMax()[1] < center[1]) { closest[1] = b->getMax()[1]; }
	else {
		closest[1] = center[1];
	}

	if(b->getMin()[2] > center[2]) { closest[2] = b->getMin()[2]; }
	else if(b->getMax()[2] < center[2]) { closest[2] = b->getMax()[2]; }
	else {
		closest[2] = center[2];
	}

	return sgCompare3DSqdDist(closest, center, sgSquare(radius)) <= 0;
}


/************************\
*   sgFrustum routines   *
\************************/

void sgFrustum::update()
{
	if(fabs(ffar-nnear) < 0.1) {
		ulSetError(UL_WARNING, "sgFrustum: Can't support depth of view <0.1 units.");
		return;
	}

	if(hfov != SG_ZERO && vfov != SG_ZERO) {
		if(fabs(hfov) < 0.1 || fabs(vfov) < 0.1) {
			ulSetError(UL_WARNING,
				ortho ? "sgFrustum: Can't support width or height <0.1 units." : "sgFrustum: Can't support fields of view narrower than 0.1 degrees.");
			return;
		}

		if(ortho) {
			right = SG_HALF*hfov;
			top = SG_HALF*vfov;
		} else {
			right = nnear*(SGfloat)tan(hfov*SG_DEGREES_TO_RADIANS/SG_TWO);
			top = nnear*(SGfloat)tan(vfov*SG_DEGREES_TO_RADIANS/SG_TWO);
		}

		left = -right;
		bot = -top;
	}


	/* Compute the projection matrix */

	SGfloat width = right-left;
	SGfloat height = top-bot;
	SGfloat depth = ffar-nnear;

	if(ortho) {
		/* orthographic */

		mat[0][0] = SG_TWO/width;
		mat[0][1] = SG_ZERO;
		mat[0][2] = SG_ZERO;
		mat[0][3] = SG_ZERO;

		mat[1][0] = SG_ZERO;
		mat[1][1] = SG_TWO/height;
		mat[1][2] = SG_ZERO;
		mat[1][3] = SG_ZERO;

		mat[2][0] = SG_ZERO;
		mat[2][1] = SG_ZERO;
		mat[2][2] = -SG_TWO/depth;
		mat[2][3] = SG_ZERO;

		mat[3][0] = -(left+right)/width;
		mat[3][1] = -(bot+top)/height;
		mat[3][2] = -(nnear+ffar)/depth;
		mat[3][3] = SG_ONE;
	} else {
		/* perspective */

		mat[0][0] = SG_TWO*nnear/width;
		mat[0][1] = SG_ZERO;
		mat[0][2] = SG_ZERO;
		mat[0][3] = SG_ZERO;

		mat[1][0] = SG_ZERO;
		mat[1][1] = SG_TWO*nnear/height;
		mat[1][2] = SG_ZERO;
		mat[1][3] = SG_ZERO;

		mat[2][0] = (right+left)/width;
		mat[2][1] = (top+bot)/height;
		mat[2][2] = -(ffar+nnear)/depth;
		mat[2][3] = -SG_ONE;

		mat[3][0] = SG_ZERO;
		mat[3][1] = SG_ZERO;
		mat[3][2] = -SG_TWO*nnear*ffar/depth;
		mat[3][3] = SG_ZERO;
	}


	/*
	 * The clip planes are derived from the projection matrix.
	 *
	 * After projection (in clip coordinates), the clip planes are simply:
	 *
	 *  left:    (  1,  0,  0,  1 )
	 *  right:   ( -1,  0,  0,  1 )
	 *  bottom:  (  0,  1,  0,  1 )
	 *  top:     (  0, -1,  0,  1 )
	 *  near:    (  0,  0,  1,  1 )
	 *  far:     (  0,  0, -1,  1 )
	 *
	 * These can easily be transformed *backwards* by
	 * multiplying by the transposed projection matrix, i.e:
	 *
	 *  ( A )            ( A')
	 *  ( B )  =  mat^T  ( B')
	 *  ( C )            ( C')
	 *  ( D )            ( D')
	 *
	 * where (A',B',C',D') represents a plane in clip coordinates,
	 * and (A,B,C,D) is the same plane expressed in eye coordinates.
	 */

	sgSetVec4(plane[SG_LEFT_PLANE], SG_ONE, SG_ZERO, SG_ZERO, SG_ONE);
	sgSetVec4(plane[SG_RIGHT_PLANE], -SG_ONE, SG_ZERO, SG_ZERO, SG_ONE);
	sgSetVec4(plane[SG_BOT_PLANE], SG_ZERO, SG_ONE, SG_ZERO, SG_ONE);
	sgSetVec4(plane[SG_TOP_PLANE], SG_ZERO, -SG_ONE, SG_ZERO, SG_ONE);
	sgSetVec4(plane[SG_NEAR_PLANE], SG_ZERO, SG_ZERO, SG_ONE, SG_ONE);
	sgSetVec4(plane[SG_FAR_PLANE], SG_ZERO, SG_ZERO, -SG_ONE, SG_ONE);

	for(int i = 0; i < 6; i++) {
		sgVec4 tmp;

		for(int j = 0; j < 4; j++) {
			tmp[j] = sgScalarProductVec4(plane[i], mat[j]);
		}

		sgScaleVec4(plane[i], tmp, SG_ONE/sgLengthVec3(tmp));
	}
}


#define OC_LEFT_SHIFT   0
#define OC_RIGHT_SHIFT  1
#define OC_TOP_SHIFT    2
#define OC_BOT_SHIFT    3
#define OC_NEAR_SHIFT   4
#define OC_FAR_SHIFT    5

#define OC_ALL_ON_SCREEN 0x3F
//#define OC_OFF_TRF      ((1<<OC_TOP_SHIFT)|(1<<OC_RIGHT_SHIFT)|(1<<OC_FAR_SHIFT))
//#define OC_OFF_BLN      ((1<<OC_BOT_SHIFT)|(1<<OC_LEFT_SHIFT)|(1<<OC_NEAR_SHIFT))

int sgFrustum::getOutcode(const sgVec3 pt) const
{
	/* Transform the point by the Frustum's transform. */

	sgVec4 tmp;

	tmp[0] = pt[0];
	tmp[1] = pt[1];
	tmp[2] = pt[2];
	tmp[3] = SG_ONE;

	sgXformPnt4(tmp, tmp, mat);

	/*
	  No need to divide by the 'w' component since we are only checking for
	  results in the range 0..1
	*/

	return ((tmp[0] <= tmp[3])<<OC_RIGHT_SHIFT)|((tmp[0] >= -tmp[3])<<OC_LEFT_SHIFT)|((tmp[1] <= tmp[3])<<OC_TOP_SHIFT)|
		((tmp[1] >= -tmp[3])<<OC_BOT_SHIFT)|((tmp[2] <= tmp[3])<<OC_FAR_SHIFT)|((tmp[2] >= -tmp[3])<<OC_NEAR_SHIFT);
}

int sgFrustum::contains(const sgVec3 pt) const
{
	return getOutcode(pt) == OC_ALL_ON_SCREEN;
}


int sgFrustum::contains(const sgSphere* s) const
{

	const SGfloat* center = s->getCenter();
	const SGfloat radius = s->getRadius();

	/*
	  Lop off half the database (roughly) with a quick near-plane test - and
	  lop off a lot more with a quick far-plane test
	*/

	if(-center[2]+radius < nnear || -center[2]-radius > ffar) {
		return SG_OUTSIDE;
	}
//  return SG_INSIDE ; // TODO: delete later

	/*
	  OK, so the sphere lies between near and far.

	  Measure the distance of the center point from the four sides of the frustum,
	  if it's outside by more than the radius then it's history.

	  It's tempting to do a quick test to see if the center point is
	  onscreen using sgFrustumContainsPt - but that takes a matrix transform
	  which is 16 multiplies and 12 adds - versus this test which does the
	  whole task using only 12 multiplies and 8 adds.
	*/

	/*
	  A few operations are saved by observing that certain values in the plane
	  equations are zero or one. These are specific to orthographic and perspective
	  projections respectively.
	*/

	SGfloat sp1, sp2, sp3, sp4;

	if(ortho) {
		/*
		  left:    (  1,  0,  0,  x  )
		  right:   ( -1,  0,  0,  x  )
		  bottom:  (  0,  1,  0,  x  )
		  top:     (  0, -1,  0,  x  )
		*/
		sp1 = plane[SG_LEFT_PLANE][3]+center[0];
		sp2 = plane[SG_RIGHT_PLANE][3]-center[0];
		sp3 = plane[SG_BOT_PLANE][3]+center[1];
		sp4 = plane[SG_TOP_PLANE][3]-center[1];
	} else {
		/*
		  left:    (  x,  0,  x,  0  )
		  right:   (  x,  0,  x,  0  )
		  bottom:  (  0,  x,  x,  0  )
		  top:     (  0,  x,  x,  0  )
		*/
		sp1 = plane[SG_LEFT_PLANE][0]*center[0]+plane[SG_LEFT_PLANE][2]*center[2];
		sp2 = plane[SG_RIGHT_PLANE][0]*center[0]+plane[SG_RIGHT_PLANE][2]*center[2];
		sp3 = plane[SG_BOT_PLANE][1]*center[1]+plane[SG_BOT_PLANE][2]*center[2];
		sp4 = plane[SG_TOP_PLANE][1]*center[1]+plane[SG_TOP_PLANE][2]*center[2];
	}

	/*
	   Note: in the general case, we would have to do:

	   sp1 = sgScalarProductVec3 (  left_plane, center ) +  left_plane[3] ;
	   sp2 = sgScalarProductVec3 ( right_plane, center ) + right_plane[3] ;
	   ...
	   sp6 = sgScalarProductVec3 (   far_plane, center ) +   far_plane[3] ;
	*/


	if(-sp1 > radius || -sp2 > radius || -sp3 > radius || -sp4 > radius) {
		return SG_OUTSIDE;
	}

	/*
	  If it's inside by more than the radius then it's *completely* inside
	  and we can save time elsewhere if we know that for sure.
	*/

	if(sp1 >= radius && sp2 >= radius && sp3 >= radius && sp4 >= radius && -center[2]-radius >= nnear && -center[2]+radius <= ffar) {
		return SG_INSIDE;
	}

	return SG_STRADDLE;
}


int sgFrustum::contains(const sgBox* b) const
{
	sgVec3 p[8] = {{b->getMin()[0], b->getMin()[1], b->getMin()[2]},
				   {b->getMax()[0], b->getMin()[1], b->getMin()[2]},
				   {b->getMin()[0], b->getMax()[1], b->getMin()[2]},
				   {b->getMax()[0], b->getMax()[1], b->getMin()[2]},
				   {b->getMin()[0], b->getMin()[1], b->getMax()[2]},
				   {b->getMax()[0], b->getMin()[1], b->getMax()[2]},
				   {b->getMin()[0], b->getMax()[1], b->getMax()[2]},
				   {b->getMax()[0], b->getMax()[1], b->getMax()[2]},};

	int all = -1;
	int one = 0;

	for(int i = 0; i < 8; i++) {
		int tmp = ~getOutcode(p[i]);
		all &= tmp;
		one |= tmp;
	}

	return (all ? SG_OUTSIDE : one ? SG_STRADDLE : SG_INSIDE);
}


void sgMakeCoordMat4(sgMat4 m, const SGfloat x, const SGfloat y, const SGfloat z, const SGfloat h, const SGfloat p, const SGfloat r)
{
	SGfloat ch, sh, cp, sp, cr, sr, srsp, crsp, srcp;

	if(h == SG_ZERO) {
		ch = SGD_ONE;
		sh = SGD_ZERO;
	} else {
		sh = sgSin(h);
		ch = sgCos(h);
	}

	if(p == SG_ZERO) {
		cp = SGD_ONE;
		sp = SGD_ZERO;
	} else {
		sp = sgSin(p);
		cp = sgCos(p);
	}

	if(r == SG_ZERO) {
		cr = SGD_ONE;
		sr = SGD_ZERO;
		srsp = SGD_ZERO;
		srcp = SGD_ZERO;
		crsp = sp;
	} else {
		sr = sgSin(r);
		cr = sgCos(r);
		srsp = sr*sp;
		crsp = cr*sp;
		srcp = sr*cp;
	}

	m[0][0] = (SGfloat)(ch*cr-sh*srsp);
	m[1][0] = (SGfloat)(-sh*cp);
	m[2][0] = (SGfloat)(sr*ch+sh*crsp);
	m[3][0] = x;

	m[0][1] = (SGfloat)(cr*sh+srsp*ch);
	m[1][1] = (SGfloat)(ch*cp);
	m[2][1] = (SGfloat)(sr*sh-crsp*ch);
	m[3][1] = y;

	m[0][2] = (SGfloat)(-srcp);
	m[1][2] = (SGfloat)(sp);
	m[2][2] = (SGfloat)(cr*cp);
	m[3][2] = z;

	m[0][3] = SG_ZERO;
	m[1][3] = SG_ZERO;
	m[2][3] = SG_ZERO;
	m[3][3] = SG_ONE;
}


void sgMakeTransMat4(sgMat4 m, const sgVec3 xyz)
{
	m[0][1] = m[0][2] = m[0][3] = m[1][0] = m[1][2] = m[1][3] = m[2][0] = m[2][1] = m[2][3] = SG_ZERO;
	m[0][0] = m[1][1] = m[2][2] = m[3][3] = SG_ONE;
	sgCopyVec3(m[3], xyz);
}


void sgMakeTransMat4(sgMat4 m, const SGfloat x, const SGfloat y, const SGfloat z)
{
	m[0][1] = m[0][2] = m[0][3] = m[1][0] = m[1][2] = m[1][3] = m[2][0] = m[2][1] = m[2][3] = SG_ZERO;
	m[0][0] = m[1][1] = m[2][2] = m[3][3] = SG_ONE;
	sgSetVec3(m[3], x, y, z);
}


void sgSetCoord(sgCoord* dst, const sgMat4 src)
{
	sgCopyVec3(dst->xyz, src[3]);

	sgMat4 mat;

	SGfloat s = sgLengthVec3(src[0]);

	if(s <= 0.00001) {
		ulSetError(UL_WARNING, "sgMat4ToCoord: ERROR - Bad Matrix.");
		sgSetVec3(dst->hpr, SG_ZERO, SG_ZERO, SG_ZERO);
		return;
	}

	sgScaleMat4(mat, src, SG_ONE/s);

	dst->hpr[1] = sgASin(_sgClampToUnity(mat[1][2]));

	SGfloat cp = sgCos(dst->hpr[1]);

	/* If pointing nearly vertically up - then heading is ill-defined */

	if(cp > -0.00001 && cp < 0.00001) {
		SGfloat cr = _sgClampToUnity(mat[0][1]);
		SGfloat sr = _sgClampToUnity(-mat[2][1]);

		dst->hpr[0] = SG_ZERO;
		dst->hpr[2] = sgATan2(sr, cr);
	} else {
		cp = SG_ONE/cp;
		SGfloat sr = _sgClampToUnity(-mat[0][2]*cp);
		SGfloat cr = _sgClampToUnity(mat[2][2]*cp);
		SGfloat sh = _sgClampToUnity(-mat[1][0]*cp);
		SGfloat ch = _sgClampToUnity(mat[1][1]*cp);

		if((sh == SG_ZERO && ch == SG_ZERO) || (sr == SG_ZERO && cr == SG_ZERO)) {
			cr = _sgClampToUnity(mat[0][1]);
			sr = _sgClampToUnity(-mat[2][1]);

			dst->hpr[0] = SG_ZERO;
		} else {
			dst->hpr[0] = sgATan2(sh, ch);
		}

		dst->hpr[2] = sgATan2(sr, cr);
	}
}


void sgMakeNormal(sgVec3 dst, const sgVec3 a, const sgVec3 b, const sgVec3 c)
{
	sgVec3 ab;
	sgSubVec3(ab, b, a);
	sgVec3 ac;
	sgSubVec3(ac, c, a);
	sgVectorProductVec3(dst, ab, ac);
	sgNormaliseVec3(dst);
}


void sgPreMultMat4(sgMat4 dst, const sgMat4 src)
{
	sgMat4 mat;
	sgMultMat4(mat, dst, src);
	sgCopyMat4(dst, mat);
}

void sgPostMultMat4(sgMat4 dst, const sgMat4 src)
{
	sgMat4 mat;
	sgMultMat4(mat, src, dst);
	sgCopyMat4(dst, mat);
}

void sgMultMat4(sgMat4 dst, const sgMat4 m1, const sgMat4 m2)
{
	for(int j = 0; j < 4; j++) {
		dst[0][j] = m2[0][0]*m1[0][j]+m2[0][1]*m1[1][j]+m2[0][2]*m1[2][j]+m2[0][3]*m1[3][j];

		dst[1][j] = m2[1][0]*m1[0][j]+m2[1][1]*m1[1][j]+m2[1][2]*m1[2][j]+m2[1][3]*m1[3][j];

		dst[2][j] = m2[2][0]*m1[0][j]+m2[2][1]*m1[1][j]+m2[2][2]*m1[2][j]+m2[2][3]*m1[3][j];

		dst[3][j] = m2[3][0]*m1[0][j]+m2[3][1]*m1[1][j]+m2[3][2]*m1[2][j]+m2[3][3]*m1[3][j];
	}
}


void sgTransposeNegateMat4(sgMat4 dst, const sgMat4 src)
{
	/* Poor man's invert - can be used when matrix is a simple rotate-translate */

	dst[0][0] = src[0][0];
	dst[1][0] = src[0][1];
	dst[2][0] = src[0][2];
	dst[3][0] = -sgScalarProductVec3(src[3], src[0]);

	dst[0][1] = src[1][0];
	dst[1][1] = src[1][1];
	dst[2][1] = src[1][2];
	dst[3][1] = -sgScalarProductVec3(src[3], src[1]);

	dst[0][2] = src[2][0];
	dst[1][2] = src[2][1];
	dst[2][2] = src[2][2];
	dst[3][2] = -sgScalarProductVec3(src[3], src[2]);

	dst[0][3] = SG_ZERO;
	dst[1][3] = SG_ZERO;
	dst[2][3] = SG_ZERO;
	dst[3][3] = SG_ONE;
}


void sgTransposeNegateMat4(sgMat4 dst)
{
	sgMat4 src;
	sgCopyMat4(src, dst);
	sgTransposeNegateMat4(dst, src);
}


void sgXformVec3(sgVec3 dst, const sgVec3 src, const sgMat4 mat)
{
	SGfloat t0 = src[0];
	SGfloat t1 = src[1];
	SGfloat t2 = src[2];

	dst[0] = t0*mat[0][0]+t1*mat[1][0]+t2*mat[2][0];

	dst[1] = t0*mat[0][1]+t1*mat[1][1]+t2*mat[2][1];

	dst[2] = t0*mat[0][2]+t1*mat[1][2]+t2*mat[2][2];
}


void sgXformPnt3(sgVec3 dst, const sgVec3 src, const sgMat4 mat)
{
	SGfloat t0 = src[0];
	SGfloat t1 = src[1];
	SGfloat t2 = src[2];

	dst[0] = t0*mat[0][0]+t1*mat[1][0]+t2*mat[2][0]+mat[3][0];

	dst[1] = t0*mat[0][1]+t1*mat[1][1]+t2*mat[2][1]+mat[3][1];

	dst[2] = t0*mat[0][2]+t1*mat[1][2]+t2*mat[2][2]+mat[3][2];
}


void sgXformPnt4(sgVec4 dst, const sgVec4 src, const sgMat4 mat)
{
	SGfloat t0 = src[0];
	SGfloat t1 = src[1];
	SGfloat t2 = src[2];
	SGfloat t3 = src[3];

	dst[0] = t0*mat[0][0]+t1*mat[1][0]+t2*mat[2][0]+t3*mat[3][0];

	dst[1] = t0*mat[0][1]+t1*mat[1][1]+t2*mat[2][1]+t3*mat[3][1];

	dst[2] = t0*mat[0][2]+t1*mat[1][2]+t2*mat[2][2]+t3*mat[3][2];

	dst[3] = t0*mat[0][3]+t1*mat[1][3]+t2*mat[2][3]+t3*mat[3][3];
}


void sgFullXformPnt3(sgVec3 dst, const sgVec3 src, const sgMat4 mat)
{
	sgVec4 tmp;

	tmp[0] = src[0];
	tmp[1] = src[1];
	tmp[2] = src[2];
	tmp[3] = SG_ONE;

	sgXformPnt4(tmp, tmp, mat);
	sgScaleVec3(dst, tmp, SG_ONE/tmp[3]);
}


void sgAngleAxisToQuat(sgQuat dst, const SGfloat angle, const sgVec3 axis)
{
	SGfloat temp_angle = angle*SG_DEGREES_TO_RADIANS/SG_TWO;

	sgVec3 ax;
	sgNormaliseVec3(ax, axis);

	SGfloat s = -(SGfloat)sin(temp_angle);

	dst[SG_W] = (SGfloat)cos(temp_angle);
	sgScaleVec3(dst, ax, s);
}


void sgMultQuat(sgQuat dst, const sgQuat a, const sgQuat b)
{
	/* [ ww' - v.v', vxv' + wv' + v'w ] */

	SGfloat t[8];

	t[0] = (a[SG_W]+a[SG_X])*(b[SG_W]+b[SG_X]);
	t[1] = (a[SG_Z]-a[SG_Y])*(b[SG_Y]-b[SG_Z]);
	t[2] = (a[SG_X]-a[SG_W])*(b[SG_Y]+b[SG_Z]);
	t[3] = (a[SG_Y]+a[SG_Z])*(b[SG_X]-b[SG_W]);
	t[4] = (a[SG_X]+a[SG_Z])*(b[SG_X]+b[SG_Y]);
	t[5] = (a[SG_X]-a[SG_Z])*(b[SG_X]-b[SG_Y]);
	t[6] = (a[SG_W]+a[SG_Y])*(b[SG_W]-b[SG_Z]);
	t[7] = (a[SG_W]-a[SG_Y])*(b[SG_W]+b[SG_Z]);

	dst[SG_W] = t[1]+((-t[4]-t[5]+t[6]+t[7])*SG_HALF);
	dst[SG_X] = t[0]-((t[4]+t[5]+t[6]+t[7])*SG_HALF);
	dst[SG_Y] = -t[2]+((t[4]-t[5]+t[6]-t[7])*SG_HALF);
	dst[SG_Z] = -t[3]+((t[4]-t[5]-t[6]+t[7])*SG_HALF);
}


int sgClassifyMat4(const sgMat4 m)
{
	const SGfloat epsilon = 1e-6f;

	int flags = 0;


	SGfloat sx, sy, sz;

	if(m[0][1] == SG_ZERO && m[0][2] == SG_ZERO && m[1][0] == SG_ZERO && m[1][2] == SG_ZERO && m[2][0] == SG_ZERO && m[2][1] == SG_ZERO) {

		int n = (m[0][0] < 0)+(m[1][1] < 0)+(m[2][2] < 0);

		if(n > 1) {
			flags |= SG_ROTATION;
		}

		if(n%2 != 0) {
			flags |= SG_MIRROR;
		}

		sx = m[0][0]*m[0][0];
		sy = m[1][1]*m[1][1];
		sz = m[2][2]*m[2][2];

	} else {

		flags |= SG_ROTATION;

		if(sgAbs(sgScalarProductVec3(m[1], m[2])) > epsilon || sgAbs(sgScalarProductVec3(m[2], m[0])) > epsilon ||
			sgAbs(sgScalarProductVec3(m[0], m[1])) > epsilon) {
			flags |= SG_NONORTHO;
		}

		sgVec3 temp;
		sgVectorProductVec3(temp, m[0], m[1]);
		SGfloat det = sgScalarProductVec3(temp, m[2]);

		if(det < 0) {
			flags |= SG_MIRROR;
		}

		sx = sgScalarProductVec3(m[0], m[0]);
		sy = sgScalarProductVec3(m[1], m[1]);
		sz = sgScalarProductVec3(m[2], m[2]);

	}


	if(sgAbs(sx-sy) > epsilon || sgAbs(sx-sz) > epsilon) {
		flags |= SG_NONORTHO;
		flags |= SG_GENERAL_SCALE; // also set general scale bit, though it may be deleted in the future
	} else {
		if(sgAbs(sx-SG_ONE) > epsilon) {
			flags |= SG_SCALE;
		}
	}


	if(m[3][0] != SG_ZERO || m[3][1] != SG_ZERO || m[3][2] != SG_ZERO) {
		flags |= SG_TRANSLATION;
	}


	if(m[0][3] != SG_ZERO || m[1][3] != SG_ZERO || m[2][3] != SG_ZERO || m[3][3] != SG_ONE) {
		flags |= SG_PROJECTION;
	}


	return flags;
}
