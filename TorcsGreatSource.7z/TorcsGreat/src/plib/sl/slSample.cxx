/*
     PLIB - A Suite of Portable Game Libraries
     Copyright (C) 1998,2002  Steve Baker

     This library is free software; you can redistribute it and/or
     modify it under the terms of the GNU Library General Public
     License as published by the Free Software Foundation; either
     version 2 of the License, or (at your option) any later version.

     This library is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
     Library General Public License for more details.

     You should have received a copy of the GNU Library General Public
     License along with this library; if not, write to the Free Software
     Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA

     For further information visit http://plib.sourceforge.net

     $Id: slSample.cxx 1853 2004-02-08 18:41:15Z stromberg $
*/


#include "sl.h"
#include "android_jni.h"
#include <math.h>
#include "android_snd.h"

void slSample::autoMatch(const slDSP* dsp)
{
	if(dsp == NULL || dsp->notWorking()) return;

	changeRate(dsp->getRate());
	changeBps(dsp->getBps());
	changeStereo(dsp->getStereo());
}

void slSample::adjustVolume(float vol)
{
	for(int i = 0; i < length; i++) {
		int s = (int)(((float)buffer[i]-(float)0x80)*vol)+0x80;
		buffer[i] = (s > 255) ? 255 : (s < 0) ? 0 : s;
	}
}


void slSample::changeRate(int r)
{
	if(r == rate) return;

	int length2 = (int)((float)length*((float)r/(float)rate));
	Uchar* buffer2 = new Uchar[length2];

	int samps = length/(getBps()/8);
	int samps2 = length2/(getBps()/8);

	float step = (float)length/(float)length2;

	for(int i = 0; i < samps2; i++) {
		float pos = (float)i*step;

		int p1 = (int)floor(pos);
		int p2 = (int)ceil(pos);

		if(stereo) {
			if((p1&1) != (i&1)) {
				pos++;
				p1++;
				p2++;
			}
			p2++;
		}

		float ratio = pos-(float)p1;

		float b1 = (getBps() == 8) ? (float)buffer[(p1 < 0) ? 0 : (p1 >= samps) ? samps-1 : p1] : (float)((Ushort*)buffer)[(p1 < 0) ? 0 : (p1 >=
			samps) ? samps-1 : p1];
		float b2 = (getBps() == 8) ? (float)buffer[(p2 < 0) ? 0 : (p2 >= samps) ? samps-1 : p2] : (float)((Ushort*)buffer)[(p2 < 0) ? 0 : (p2 >=
			samps) ? samps-1 : p2];

		float res = b1*(1.0f-ratio)+b2*ratio;

		if(getBps() == 8) {
			buffer2[i] = (Uchar)((res < 0) ? 0 : (res > 255) ? 255 : res);
		} else {
			((Ushort*)buffer2)[i] = (Ushort)((res < 0) ? 0 : (res > 65535) ? 65535 : res);
		}
	}

	rate = r;
	length = length2;
	delete[] buffer;
	buffer = buffer2;
}


void slSample::changeToUnsigned()
{
	if(getBps() == 16) {
		int length2 = length/2;
		Ushort* buffer2 = (Ushort*)buffer;

		for(int i = 0; i < length2; i++) {
			buffer2[i] = buffer2[i]+32768;
		}
	} else {
		for(int i = 0; i < length; i++) {
			buffer[i] = (buffer[i] > 0x80) ? (buffer[i]-0x80) : (0xFF-buffer[i]);
		}
	}
}


void slSample::changeBps(int b)
{
	if(b == getBps()) return;

	if(b == 8 && getBps() == 16) {
		length /= 2;
		Uchar* buffer2 = new Uchar[length];

		for(int i = 0; i < length; i++) {
			buffer2[i] = ((Ushort*)buffer)[i]>>8;
		}

		delete[] buffer;
		buffer = buffer2;
		setBps(b);
	} else if(b == 16 && getBps() == 8) {
		Ushort* buffer2 = new Ushort[length];

		for(int i = 0; i < length; i++) {
			buffer2[i] = buffer[i]<<8;
		}

		delete[] buffer;
		buffer = (Uchar*)buffer2;
		length *= 2;
		setBps(b);
	}
}

void slSample::changeStereo(int s)
{
	if(s == getStereo()) {
		return;
	}

	if(s && !getStereo()) {
		if(getBps() == 8) {
			Uchar* buffer2 = new Uchar[length*2];

			for(int i = 0; i < length; i++) {
				buffer2[i*2] = buffer2[i*2+1] = buffer[i];
			}

			delete[] buffer;
			buffer = buffer2;
			length *= 2;
			setStereo(SL_TRUE);
		} else {
			Ushort* buffer2 = new Ushort[length];

			for(int i = 0; i < length/2; i++) {
				buffer2[i*2] = buffer2[i*2+1] = ((Ushort*)buffer)[i];
			}

			delete[] buffer;
			buffer = (Uchar*)buffer2;
			length *= 2;
			setStereo(SL_TRUE);
		}
	} else {
		if(getBps() == 8) {
			Uchar* buffer2 = new Uchar[length/2];

			for(int i = 0; i < (length-1)/2; i++) {
				buffer2[i] = ((int)buffer[i*2]+(int)buffer[i*2+1])/2;
			}

			delete[] buffer;
			buffer = buffer2;
			length /= 2;
			setStereo(SL_FALSE);
		} else {
			Ushort* buffer2 = new Ushort[length/4];

			for(int i = 0; i < (length-3)/4; i++) {
				buffer2[i] = ((int)((Ushort*)buffer)[i*2]+(int)((Ushort*)buffer)[i*2+1])/2;
			}

			delete[] buffer;
			buffer = (Uchar*)buffer2;
			length /= 4;
			setStereo(SL_FALSE);
		}
	}
}


static void swap_Ushort(Ushort* i)
{
	*i = Ushort(((*i<<8)&0xFF00)+((*i>>8)&0x00FF));
}

static void swap_int(int* i)
{
	*i = ((*i<<24)&0xFF000000)+((*i<<8)&0x00FF0000)+((*i>>8)&0x0000FF00)+((*i>>24)&0x000000FF);
}


int slSample::loadFile(const char* fname)
{
	if(ulStrEqual(&fname[strlen(fname)-4], ".wav")) {
		return loadWavFile(fname);
	}

	ulSetError(UL_WARNING, "slSample:loadFile: Unknown file type for '%s'.", fname);
	return SL_FALSE;
}


int slSample::loadWavFile(const char* fname)
{
	int found_header = SL_FALSE;
	int needs_swabbing = SL_FALSE;

	delete[] buffer;
	buffer = NULL;
	length = 0;

//	LogInfo("inside slSample::loadWavFile: fname = %s", fname); // TODO: delete later
	FILE* fd = fopen(getAbsPath(fname), "rb");

	if(fd == NULL) {
		ulSetError(UL_WARNING, "slSample: loadWavFile: Cannot open '%s' for reading.", fname);
		return SL_FALSE;
	}

	char magic[8];

	if(fread(magic, 4, 1, fd) == 0 || magic[0] != 'R' || magic[1] != 'I' || magic[2] != 'F' || magic[3] != 'F') {
		ulSetError(UL_WARNING, "slWavSample: File '%s' has wrong magic number", fname);
		ulSetError(UL_WARNING, "            - it probably isn't in '.wav' format.");
		fclose(fd);
		return SL_FALSE;
	}

	int leng1;

	if(fread(&leng1, sizeof(int), 1, fd) == 0) {
		ulSetError(UL_WARNING, "slSample: File '%s' has premature EOF in header", fname);
		fclose(fd);
		return SL_FALSE;
	}

	fread(magic, 4, 1, fd);

	if(magic[0] != 'W' || magic[1] != 'A' || magic[2] != 'V' || magic[3] != 'E') {
		ulSetError(UL_WARNING, "slSample: File '%s' has no WAVE tag.", fname);
		fclose(fd);
		return SL_FALSE;
	}

	while(!feof(fd)) {
		fread(magic, 4, 1, fd);

		if(magic[0] == 'f' && magic[1] == 'm' && magic[2] == 't' && magic[3] == ' ') {
			found_header = SL_TRUE;

			if(fread(&leng1, sizeof(int), 1, fd) == 0) {
				ulSetError(UL_WARNING, "slSample: File '%s' has premature EOF in header", fname);
				fclose(fd);
				return SL_FALSE;
			}

			if(leng1 > 65536) {
				needs_swabbing = SL_TRUE;
				swap_int(&leng1);
			}

			Ushort header[8];

			if(leng1 != sizeof(header)) {
				ulSetError(UL_WARNING, "slSample: File '%s' has unexpectedly long (%d byte) header", fname, leng1);
			}

			fread(&header, sizeof(header), 1, fd);

			for(int junk = sizeof(header); junk < leng1; junk++) {
				getc(fd);
			}

			if(needs_swabbing) {
				swap_Ushort(&header[0]);
				swap_Ushort(&header[1]);
				swap_int((int*)&header[2]);
				swap_int((int*)&header[4]);
				swap_Ushort(&header[6]);
				swap_Ushort(&header[7]);
			}

			if(header[0] != 0x0001) {
				ulSetError(UL_WARNING, "slSample: File '%s' is not WAVE_FORMAT_PCM!", fname);
				fclose(fd);
				return SL_FALSE;
			}

			setStereo(header[1] > 1);
			setRate(*((int*)(&header[2])));
			setBps(header[7]);
		} else if(magic[0] == 'd' && magic[1] == 'a' && magic[2] == 't' && magic[3] == 'a') {
			if(!found_header) {
				ulSetError(UL_WARNING, "slSample: File '%s' has no data section", fname);
				fclose(fd);
				return SL_FALSE;
			}

			if(fread(&length, sizeof(int), 1, fd) == 0) {
				ulSetError(UL_WARNING, "slSample: File '%s' has premature EOF in data", fname);
				fclose(fd);
				return SL_FALSE;
			}

			if(needs_swabbing) {
				swap_int(&length);
			}

			buffer = new Uchar[length];
			fread(buffer, 1, length, fd);
			fclose(fd);

//			if(getBps() == 16) {
//				changeToUnsigned();
//			}

//			const int Stereo = getStereo(); // TODO: delete later
//			const int Rate = getRate(); // TODO: delete later
//			const int Bps = getBps(); // TODO: delete later
//			LogInfo("loadWavFile: Stereo = %d Rate = %5d Bps = %2d  length = %6d fname = %s", Stereo, Rate, Bps, length, fname); // TODO: delete
			return SL_TRUE;
		}
	}

	ulSetError(UL_WARNING, "slSample: Premature EOF in '%s'.", fname);

	fclose(fd);
	return SL_FALSE;
}
