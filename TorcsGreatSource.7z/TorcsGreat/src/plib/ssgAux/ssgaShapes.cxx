/*
     PLIB - A Suite of Portable Game Libraries
     Copyright (C) 1998,2002  Steve Baker

     This library is free software; you can redistribute it and/or
     modify it under the terms of the GNU Library General Public
     License as published by the Free Software Foundation; either
     version 2 of the License, or (at your option) any later version.

     This library is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
     Library General Public License for more details.

     You should have received a copy of the GNU Library General Public
     License along with this library; if not, write to the Free Software
     Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA

     For further information visit http://plib.sourceforge.net

     $Id: ssgaShapes.cxx 2015 2005-02-02 15:48:09Z sjbaker $
*/


#include "ssgAux.h"
#include <string.h>


void ssgaShape::copy_from ( ssgaShape *src, int clone_flags )
{
  ssgBranch::copy_from ( src, clone_flags ) ;
  if ( src -> isCorrupt () ) makeCorrupt () ;
  sgCopyVec4 ( colour, src->colour ) ;
  sgCopyVec3 ( center, src->center ) ;
  sgCopyVec3 ( size  , src->size   ) ;
  ntriangles    = src -> ntriangles ;
  kidState      = src -> getKidState      () ;
  kidPreDrawCB  = src -> getKidPreDrawCB  () ;
  kidPostDrawCB = src -> getKidPostDrawCB () ;
}



ssgBase *ssgaShape   ::clone ( int clone_flags )
{
/*
  ssgaShape *b = new ssgaShape ;
  b -> copy_from ( this, clone_flags ) ;
  return b ;
*/
  return NULL ;
}


ssgaShape::ssgaShape (void)
{
  ntriangles = 50 ;
  init () ;
}

ssgaShape::ssgaShape ( int np )
{
  ntriangles = np ;
  init () ;
}

void ssgaShape::init ()
{
  type = ssgaTypeShape () ;
  corrupted = FALSE ;
  sgZeroVec3 ( center ) ;
  sgSetVec4 ( colour, 1.0f, 1.0f, 1.0f, 1.0f ) ;
  sgSetVec3 ( size, 1.0f, 1.0f, 1.0f ) ;
  kidState      = NULL ;
  kidPreDrawCB  = NULL ;
  kidPostDrawCB = NULL ;
}


ssgaShape   ::~ssgaShape    (void) {}

const char *ssgaShape   ::getTypeName(void) { return "ssgaShape"    ; }


// XXX really need these (and ssgLocal.h is not accessible):
extern int _ssgLoadObject ( FILE *, ssgBase **, int ) ;
extern int _ssgSaveObject ( FILE *, ssgBase * ) ;


#define load_field(fp, name) (fread(&(name), 1, sizeof(name), fp) == sizeof(name))
#define save_field(fp, name) (fwrite(&(name), 1, sizeof(name), fp) == sizeof(name))


int ssgaShape::load ( FILE *fp )
{
   return ( load_field ( fp, corrupted ) &&
	    load_field ( fp, colour ) &&
	    load_field ( fp, center ) &&
	    load_field ( fp, size ) &&
	    load_field ( fp, ntriangles ) &&
	    _ssgLoadObject ( fp, (ssgBase **) &kidState, ssgTypeState () ) &&
	    ssgBranch::load ( fp ) ) ;
}

int ssgaShape::save ( FILE *fp )
{
   return ( save_field ( fp, corrupted ) &&
	    save_field ( fp, colour ) &&
	    save_field ( fp, center ) &&
	    save_field ( fp, size ) &&
	    save_field ( fp, ntriangles ) &&
	    _ssgSaveObject ( fp, kidState ) &&
	    ssgBranch::save ( fp ) ) ;
}


