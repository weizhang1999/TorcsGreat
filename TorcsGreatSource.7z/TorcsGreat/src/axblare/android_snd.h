/////////////////////////////////////////////////////////////////////////////
//                                                                         //
//   Torcs Great is an Android port of the famous open source game TORCS   //
//   Copyright (c) 2019-2020, Wei Zhang <mailto:weizhang1999@gmail.com>.   //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
//
// See the original TORCS game at <https://sourceforge.net/projects/torcs/>.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

#pragma once
#include "sl.h"
#include "osspec.h"

extern int g_nBufferSize;
extern uint8_t g_bSoundEnabled;
extern volatile bool g_bStateRace;
extern volatile int soundInitialized;
void SND_InitSound(int iFreq, int iSize);
int SND_GetUnusedSize();
void SND_WriteBuffer(uint8_t* pBuffer, int iLength);
void SND_StopSound();
