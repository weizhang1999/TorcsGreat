/////////////////////////////////////////////////////////////////////////////
//                                                                         //
//   Torcs Great is an Android port of the famous open source game TORCS   //
//   Copyright (c) 2019-2020, Wei Zhang <mailto:weizhang1999@gmail.com>.   //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
//
// See the original TORCS game at <https://sourceforge.net/projects/torcs/>.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

//----------------------------------------------------------------------------------------------------------------------------------------------
// Shader Variables
//----------------------------------------------------------------------------------------------------------------------------------------------

#define oAmbimap 0 // Object ambient texture map index
#define oDiffmap 1 // Object diffuse texture map index
#define oSpecmap 2 // Object specular texture map index
#define oAlphmap 3 // Object alpha texture map index
#define oNormmap 4 // Object normal texture map index
#define oDispmap 5 // Object displacement texture map index
#define NLIGHT 10U // Total number of available lights

struct AXLIGHT
{
	vec3 vAxis0;   // Width axis of light view coordinate system (normalized horizon vector in world space)
	float fOrigin0; // Negative dot product of light view width axis and light position
	vec3 vAxis1;   // Height axis of light view coordinate system (normalized upward vector in world space)
	float fOrigin1; // Negative dot product of light view height axis and light position
	vec3 vAxis2;   // Depth axis of light view coordinate system (normalized direction vector in world space)
	float fOrigin2; // Negative dot product of light view depth axis and light position
	vec3 vColor;   // Ambient and Lambert (directional diffuse and specular) light color
	float fAmbient; // Ambient (isotropic homogeneous environment) light color ratio
	vec3 vAttenu;  // Light attenuation parameters ((used by spot or point light only)
	uint uPower;   // Spotlight power coefficient (input is an integer number)
	vec3 vSource;  // Light position (center of the parallel light window may be adjusted by C++)
	uint uType;    // Light type (off = 0, parallel = 1, spot = 2, point = 3)
	vec2 fSize;    // Width and height of the parallel light or fSize.x/fSize.y the cone angle of the spotlight
	float fNear;    // Distance from the light to the near clipping plane
	float fFar;     // Distance from the light to the far clipping plane
};

struct XMATTER
{
	string cName;     // Material name
	vec3 rgb;
	vec3 amb;
	vec3 emis; // Object emissive color
	vec3 spec;
	int shi;
	float trans;
	vec4 vAmbient;  // Material ambient color and alpha value
	vec4 vDiffuse;  // Material diffuse color and shininess power (0 means no specular calculation)
	vec4 vSpecular; // Material specular color and illumination model (to be considered in the future)
};
