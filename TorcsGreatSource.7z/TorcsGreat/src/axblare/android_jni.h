/////////////////////////////////////////////////////////////////////////////
//                                                                         //
//   Torcs Great is an Android port of the famous open source game TORCS   //
//   Copyright (c) 2019-2020, Wei Zhang <mailto:weizhang1999@gmail.com>.   //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
//
// See the original TORCS game at <https://sourceforge.net/projects/torcs/>.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

#pragma once
#include "ax_global.h"
#include <portability.h>

inline void GfDrawTriangle(const mat3x2& vCorners)
{
	const auto& aProg = SetShader2D(kGraph, &vCorners[0].x);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDisableVertexAttribArray(aProg.s_vPosL);
}

inline void GfDrawRect(const mat4x2& vCorners)
{
	const auto& aProg = SetShader2D(kGraph, &vCorners[0].x);
	glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
	glDisableVertexAttribArray(aProg.s_vPosL);
}

inline void GfDrawTriangleStrip(const float* qVertex, GLuint nCount, float fX = 0, float fY = 0, float fR = 0, float fS = 1)
{
	const auto& aProg = SetShader2D(kGraph, qVertex, {fX, fY, sin(fR), cos(fR)}, fS);
	glDrawArrays(GL_TRIANGLE_STRIP, 0, nCount);
	glDisableVertexAttribArray(aProg.s_vPosL);
}

inline void GfDrawTriangleFan(const float* qVertex, const GLuint nCount, float fX = 0, float fY = 0, float fR = 0, float fS = 1)
{
	const auto& aProg = SetShader2D(kGraph, qVertex, {fX, fY, sin(fR), cos(fR)}, fS);
	glDrawArrays(GL_TRIANGLE_FAN, 0, nCount);
	glDisableVertexAttribArray(aProg.s_vPosL);
}

inline void GfDrawQuad(const tGfuiObject* obj)
{
	GLfloat vertices[] = {
		obj->xmin, obj->ymax, // top left corner
		obj->xmin, obj->ymin, // bottom left corner
		obj->xmax, obj->ymax, // top right corner
		obj->xmax, obj->ymin}; // bottom right corner
	GfDrawTriangleStrip(vertices, 4);
}

inline void GfDrawLine(const GLfloat* qVertex, const GLuint nCount, const bool bStrip = false)
{
	const auto& aProg = SetShader2D(kGraph, qVertex);
	glDrawArrays(bStrip ? GL_LINE_STRIP : GL_LINES, 0, nCount);
	glDisableVertexAttribArray(aProg.s_vPosL);
}

inline void GfDrawEdge(const tGfuiObject* obj)
{
	GLfloat vertices[] = {
		obj->xmin, obj->ymin, // bottom left corner
		obj->xmax, obj->ymin, // bottom right corner
		obj->xmax, obj->ymax, // top right corner
		obj->xmin, obj->ymax, // top left corner
		obj->xmin, obj->ymin}; // bottom left corner
	GfDrawLine(vertices, 5, true);
}

extern volatile int g_iTouchButton;
//extern volatile int g_bRenderPaused;
void JNI_renderScreen(bool bPause);
