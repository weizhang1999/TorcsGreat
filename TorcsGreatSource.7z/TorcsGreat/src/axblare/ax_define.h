/////////////////////////////////////////////////////////////////////////////
//                                                                         //
//   Torcs Great is an Android port of the famous open source game TORCS   //
//   Copyright (c) 2019-2020, Wei Zhang <mailto:weizhang1999@gmail.com>.   //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
//
// See the original TORCS game at <https://sourceforge.net/projects/torcs/>.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

//----------------------------------------------------------------------------------------------------------------------------------------------
// Data Definitions
//----------------------------------------------------------------------------------------------------------------------------------------------

#pragma once
#include <map>
#include <set>
#include <list>
#include <chrono>
#include <string>
#include <vector>
#include <cstring>
#include <numeric>
#include <jni.h>
#include "ssg.h"
#include "gui.h"
#include "grtexture.h"
using namespace std;
using namespace chrono;

#define SAFE_DELETE(p) { if(p) { delete [] (p); (p) = nullptr; } }

//----------------------------------------------------------------------------------------------------------------------------------------------
// Add a new item to list and return its pointer
//----------------------------------------------------------------------------------------------------------------------------------------------
template<typename T>
inline T* const ax_Add(list<T>& tList)
{
	try {
		tList.emplace_back(T());
		return &tList.back();
	}
	catch(bad_alloc&) {
		return nullptr;
	}
}

//----------------------------------------------------------------------------------------------------------------------------------------------
// Poll the specified pointer in list
//----------------------------------------------------------------------------------------------------------------------------------------------
template<typename T>
inline bool ax_Poll(list<T>& tList, T* qItem)
{
	if(!qItem) return false;
	for(const auto& t : tList) {
		if(&t == qItem) return true;
	}
	return false;
}

//----------------------------------------------------------------------------------------------------------------------------------------------
// Erase the specified pointer from list
//----------------------------------------------------------------------------------------------------------------------------------------------
template<typename T>
inline void ax_Erase(list<T>& tList, T* qItem)
{
	if(!qItem) return;
	for(auto i = cbegin(tList); i != cend(tList); ++i) {
		if(&*i == qItem) {
			tList.erase(i);
			return;
		}
	}
}
