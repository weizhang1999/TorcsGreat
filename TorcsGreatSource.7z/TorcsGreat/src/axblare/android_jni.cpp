/////////////////////////////////////////////////////////////////////////////
//                                                                         //
//   Torcs Great is an Android port of the famous open source game TORCS   //
//   Copyright (c) 2019-2020, Wei Zhang <mailto:weizhang1999@gmail.com>.   //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
//
// See the original TORCS game at <https://sourceforge.net/projects/torcs/>.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>
#include "android_jni.h"
#include "android_snd.h"
#include <track.h>
#include "grutil.h"
#include "racegl.h"
#include "raceman.h"
#include "racemain.h"
#include "linuxspec.h"
#include "racestate.h"
#include "raceengine.h"
#include "racemanmenu.h"
#include "singleplayer.h"
#include "driverconfig.h"
#include "client.h"

static struct timeval start;
static bool ticks_started = false;
volatile bool g_bStateRace = false;
volatile int g_iTouchButton = 0;
int currentKey[256];
int currentSKey[256];

static JavaVM* gJVM;
static jclass j_classMainActivity = nullptr; // Java class pointer
static jobject j_thisMainActivity = nullptr; // Java class instance
static jmethodID j_startTextSpeech = nullptr; // Java method identifier
static jmethodID j_showToastString = nullptr; // Java method identifier
static jmethodID j_showAppSettings = nullptr; // Java method identifier
static jmethodID j_onBackPressed = nullptr; // Java method identifier
static jmethodID j_playMusicFile = nullptr; // Java method identifier
static jmethodID j_renderScreen = nullptr; // Java method identifier
static jmethodID j_showPopupAd = nullptr; // Java method identifier
static std::string g_basePath, g_langPath;

static string pAxblare_Frag;
static string pAxblare_Glsl;
static string pAxblare_Vert;

//static int iSampleRate = 44100; // Audio sample rate (default 44100)
//static int iBufferSize = 1024; // Audio buffer size (default 1024)

GLuint createShader(GLenum shaderType, const char* src)
{
	GLuint shader = glCreateShader(shaderType);
	if(!shader) {
		checkGlError("glCreateShader");
		return 0;
	}
	glShaderSource(shader, 1, &src, NULL);

	GLint compiled = GL_FALSE;
	glCompileShader(shader);
	glGetShaderiv(shader, GL_COMPILE_STATUS, &compiled);
	if(!compiled) {
		GLint infoLogLen = 0;
		glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &infoLogLen);
		if(infoLogLen > 0) {
			GLchar* infoLog = (GLchar*)malloc(static_cast<size_t>(infoLogLen));
			if(infoLog) {
				glGetShaderInfoLog(shader, infoLogLen, NULL, infoLog);
				LogError("Could not compile %s shader:\n%s\n", shaderType == GL_VERTEX_SHADER ? "vertex" : "fragment", infoLog);
				free(infoLog);
			}
		}
		glDeleteShader(shader);
		return 0;
	}

	return shader;
}

GLuint createProgram(int iProg, const char* vtxSrc, const char* fragSrc)
{
	auto& aProg = aProgram[iProg];
	auto& uProg = aProg.uProg;
	uProg = glCreateProgram();
	if(!uProg) {
		checkGlError("glCreateProgram");
		return 0;
	}

//	LogInfo("createProgram:\n%s\n", vtxSrc); // TODO: delete later
//	LogError("createProgram:\n%s\n", fragSrc); // TODO: delete later
	const auto vtxShader = createShader(GL_VERTEX_SHADER, vtxSrc);
	if(vtxShader) {
		const auto fragShader = createShader(GL_FRAGMENT_SHADER, fragSrc);
		if(fragShader) {
			glAttachShader(uProg, vtxShader);
			glAttachShader(uProg, fragShader);
			glLinkProgram(uProg);
			GLint linked = GL_FALSE;
			glGetProgramiv(uProg, GL_LINK_STATUS, &linked);
			if(linked) {
				aProg.s_vAmbientColor = glGetUniformLocation(uProg, "s_vAmbientColor");
				aProg.s_vGlobalNormal = glGetUniformLocation(uProg, "s_vGlobalNormal");

				aProg.s_mAffineTrans = glGetUniformLocation(uProg, "s_mAffineTrans");
				aProg.s_mNormalTrans = glGetUniformLocation(uProg, "s_mNormalTrans");
				aProg.s_mCamViewProj = glGetUniformLocation(uProg, "s_mCamViewProj");
				aProg.s_vCamPosition = glGetUniformLocation(uProg, "s_vCamPosition");
				aProg.s_fMirrorRatio = glGetUniformLocation(uProg, "s_fMirrorRatio");
				aProg.s_vQuaterTrans = glGetUniformLocation(uProg, "s_vQuaterTrans");
				aProg.s_vFogColor = glGetUniformLocation(uProg, "s_vFogColor");
				aProg.s_fFogStart = glGetUniformLocation(uProg, "s_fFogStart");
				aProg.s_fFogRange = glGetUniformLocation(uProg, "s_fFogRange");
				aProg.s_bShadowMap = glGetUniformLocation(uProg, "s_bShadowMap");
				aProg.s_uShadowLight = glGetUniformLocation(uProg, "s_uShadowLight");
				aProg.s_vLightAmbient = glGetUniformLocation(uProg, "s_vLightAmbient");
				aProg.s_vLightDiffuse = glGetUniformLocation(uProg, "s_vLightDiffuse");
				aProg.s_vLightSpecular = glGetUniformLocation(uProg, "s_vLightSpecular");
				aProg.s_vLightPosition = glGetUniformLocation(uProg, "s_vLightPosition");
				aProg.s_vLightDirection = glGetUniformLocation(uProg, "s_vLightDirection");
				aProg.s_vMaterAmbient = glGetUniformLocation(uProg, "s_vMaterAmbient");
				aProg.s_vMaterDiffuse = glGetUniformLocation(uProg, "s_vMaterDiffuse");
				aProg.s_vMaterSpecular = glGetUniformLocation(uProg, "s_vMaterSpecular");
				aProg.s_vMaterEmission = glGetUniformLocation(uProg, "s_vMaterEmission");

				aProg.s_pTexSampler = glGetUniformLocation(uProg, "s_pTexSampler");
				aProg.s_fAlphaClip = glGetUniformLocation(uProg, "s_fAlphaClip");
				aProg.s_bAlphaTest = glGetUniformLocation(uProg, "s_bAlphaTest");

				aProg.s_vPosL = (GLuint)glGetAttribLocation(uProg, "s_vPosL");
				aProg.s_vNorL = (GLuint)glGetAttribLocation(uProg, "s_vNorL");
				aProg.s_vTexL = (GLuint)glGetAttribLocation(uProg, "s_vTexL");
				aProg.s_vInkL = (GLuint)glGetAttribLocation(uProg, "s_vInkL");
			} else {
				LogError("Could not link program");
				GLint infoLogLen = 0;
				glGetProgramiv(uProg, GL_INFO_LOG_LENGTH, &infoLogLen);
				if(infoLogLen) {
					auto infoLog = (GLchar*)malloc(static_cast<size_t>(infoLogLen));
					if(infoLog) {
						glGetProgramInfoLog(uProg, infoLogLen, nullptr, infoLog);
						LogError("Could not link program:\n%s\n", infoLog);
						free(infoLog);
					}
				}
				glDeleteProgram(uProg);
				uProg = 0;
			}
			glDeleteShader(fragShader);
		}
		glDeleteShader(vtxShader);
	}

	return uProg;
}

static void printGlString(const char* name, GLenum s)
{
	const char* v = (const char*)glGetString(s);
	LogInfo("GL %s: %s\n", name, v);
}

jint JNI_OnLoad(JavaVM* vm, void*)
{
	JNIEnv* env;
	if(vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) {
		return -1;
	}
	gJVM = vm;
	return JNI_VERSION_1_6;
}

JNIEnv* getJNIEnv()
{
	JNIEnv* env;
	if(gJVM->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) {
		return nullptr;
	}
	return env;
}

void JNI_startTextSpeech(const char* qText, const int iAdd)
{
	getJNIEnv()->CallVoidMethod(j_thisMainActivity, j_startTextSpeech, getJNIEnv()->NewStringUTF(qText), iAdd);
}

void JNI_showToastString(const char* qText, const int iAdd)
{
	getJNIEnv()->CallVoidMethod(j_thisMainActivity, j_showToastString, getJNIEnv()->NewStringUTF(qText), iAdd);
}

void JNI_showAppSettings(void* /* dummy */)
{
	getJNIEnv()->CallVoidMethod(j_thisMainActivity, j_showAppSettings);
}

void JNI_onBackPressed(void* /* dummy */)
{
	getJNIEnv()->CallVoidMethod(j_thisMainActivity, j_onBackPressed);
}

void JNI_playMusicFile(int iMusic)
{
	getJNIEnv()->CallVoidMethod(j_thisMainActivity, j_playMusicFile, iMusic);
}

void JNI_renderScreen(bool bPause)
{
	getJNIEnv()->CallVoidMethod(j_thisMainActivity, j_renderScreen, bPause);
}

void JNI_showPopupAd(int iCount, float fKilos, bool bEnded)
{
	getJNIEnv()->CallVoidMethod(j_thisMainActivity, j_showPopupAd, iCount, fKilos, bEnded);
}

const char* UTIL_BasePath()
{
	return g_basePath.c_str();
}

const char* UTIL_ConfigPath()
{
	return g_langPath.c_str();
}

void UTIL_Platform_Quit()
{
	JNIEnv* env = getJNIEnv();
	if(j_thisMainActivity) {
		env->DeleteGlobalRef(j_thisMainActivity);
		j_thisMainActivity = nullptr;
	}
	if(j_classMainActivity) {
		jmethodID sys = env->GetStaticMethodID(j_classMainActivity, "systemExit", "()V");
		env->CallStaticVoidMethod(j_classMainActivity, sys);
		env->DeleteGlobalRef(j_classMainActivity);
		j_classMainActivity = nullptr;
	}
	for(auto& i : aProgram) {
		glDeleteProgram(i.uProg);
	}
}

const char* getAbsPath(const char* file)
{
	const int SIZE = 1024;
	static char path[SIZE]; // Static array
	if(*file == '/') return file; // Absolute path
	snprintf(path, SIZE, "%s%s", UTIL_BasePath(), file); // Relative path
	return path;
}

const char* getSubPath(const char* path)
{
	return *path == '/' ? path+strlen(UTIL_BasePath()) : path;
}

const char* getSubFile(const char* dirs, const char* file)
{
	const int SIZE = 1024;
	static char buf[SIZE];
	char filepath[SIZE];
	const char* s;

	// remove the directory
	s = strrchr(file, '/');
	if(s == NULL) {
		s = file;
	} else {
		s++;
	}
	strncpy(filepath, dirs, SIZE); // Make a copy just in case
	return grGetFilename(s, filepath, buf, SIZE) ? buf : nullptr;
}

static std::string jstring_to_utf8(JNIEnv* env, jstring j_str)
{
	jsize length = env->GetStringUTFLength(j_str);
	const char* const base = env->GetStringUTFChars(j_str, nullptr);
	if(base == nullptr) return "";
	std::string value(base, (uint32_t)length);
	env->ReleaseStringUTFChars(j_str, base);
	return value;
}

uint32_t SDL_GetTicks()
{
	if(!ticks_started) {
		ticks_started = true;
		gettimeofday(&start, nullptr);
	}
	struct timeval now {};
	gettimeofday(&now, nullptr);
	auto ticks = static_cast<uint32_t>((now.tv_sec-start.tv_sec)*1000+(now.tv_usec-start.tv_usec)/1000);
	return ticks;
}

inline string JNI_GetShaderAsset(AAssetManager* pMan, const char* pFile)
{
	AAsset* pAsset = AAssetManager_open(pMan, pFile, AASSET_MODE_BUFFER);
	auto pBuffer = (const char*)AAsset_getBuffer(pAsset);
	off_t oLength = AAsset_getLength(pAsset);
	auto pString = string(pBuffer, (size_t)oLength);
	AAsset_close(pAsset);
	return pString;
}

inline void JNI_LoadShaderAsset(AAssetManager* pMan, int iProg, const char* pVert, const char* pFrag)
{
	auto vertexShaderSource = pAxblare_Glsl+pAxblare_Vert;
	vertexShaderSource += JNI_GetShaderAsset(pMan, pVert);
	auto fragmentShaderSource = "precision mediump float;\n"+pAxblare_Glsl+pAxblare_Frag;
	fragmentShaderSource += JNI_GetShaderAsset(pMan, pFrag);
	createProgram(iProg, vertexShaderSource.c_str(), fragmentShaderSource.c_str());
}

//----------------------------------------------------------------------------------------------------------------------------------------------
// Clear the current canvas using background color
//----------------------------------------------------------------------------------------------------------------------------------------------
inline void ax_ClearScreen()
{
	glStencilMask(0xff);
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT|GL_STENCIL_BUFFER_BIT);
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClearDepthf(1.0f);
	glClearStencil(0);
}

//----------------------------------------------------------------------------------------------------------------------------------------------
// Initialize global variables
//----------------------------------------------------------------------------------------------------------------------------------------------
extern "C" JNIEXPORT void Java_axblare_torcsgreat_MainActivity_setAppPath(JNIEnv* env, jobject obj, jstring app, jstring lib)
{
	j_classMainActivity = (jclass)env->NewGlobalRef(env->GetObjectClass(obj));
	j_thisMainActivity = env->NewGlobalRef(obj);
	j_startTextSpeech = env->GetMethodID(j_classMainActivity, "startTextSpeech", "(Ljava/lang/String;I)V");
	j_showToastString = env->GetMethodID(j_classMainActivity, "showToastString", "(Ljava/lang/String;I)V");
	j_showAppSettings = env->GetMethodID(j_classMainActivity, "showAppSettings", "()V");
	j_onBackPressed = env->GetMethodID(j_classMainActivity, "onBackPressed", "()V");
	j_playMusicFile = env->GetMethodID(j_classMainActivity, "playMusicFile", "(I)V");
	j_renderScreen = env->GetMethodID(j_classMainActivity, "renderScreen", "(Z)V");
	j_showPopupAd = env->GetMethodID(j_classMainActivity, "showPopupAd", "(IFZ)V");
	g_basePath = jstring_to_utf8(env, app);
	g_langPath = jstring_to_utf8(env, lib);
}

extern "C" JNIEXPORT void Java_axblare_torcsgreat_MainActivity_InitSound(JNIEnv*, jclass, jint iFreq, jint iSize)
{
	SND_InitSound(iFreq, iSize);
//	iSampleRate = iFreq;
//	iBufferSize = iSize;
}

extern "C" JNIEXPORT void Java_axblare_torcsgreat_MainActivity_EnableSound(JNIEnv*, jclass, jboolean bEnabled)
{
	g_bSoundEnabled = bEnabled;
}

extern "C" JNIEXPORT void Java_axblare_torcsgreat_MainActivity_setTouchAction(JNIEnv*, jclass, jint area, jint down)
{
	g_iTouchButton &= ~area;
	if(down) g_iTouchButton |= area;
//	LogError("inside refresh: area = %d", area); // TODO: delete later
	switch(area) {
		case BUTTON_U:
			currentSKey[GLUT_KEY_UP] = down;
//			currentKey[GLUT_KEY_UP] = currentSKey[GLUT_KEY_UP] = down;
			break;
		case BUTTON_D:
			currentSKey[GLUT_KEY_DOWN] = down;
//			currentKey[GLUT_KEY_DOWN] = currentSKey[GLUT_KEY_DOWN] = down;
			break;
		case BUTTON_L:
			currentSKey[GLUT_KEY_LEFT] = down;
//			currentKey[GLUT_KEY_LEFT] = currentSKey[GLUT_KEY_LEFT] = down;
			break;
		case BUTTON_R:
			currentSKey[GLUT_KEY_RIGHT] = down;
//			currentKey[GLUT_KEY_RIGHT] = currentSKey[GLUT_KEY_RIGHT] = down;
			break;
		default:
			break;
	}
}
/*
extern "C" JNIEXPORT void Java_axblare_torcsgreat_MainActivity_setRenderPaused(JNIEnv*, jclass, jboolean paused)
{
	g_bRenderPaused = paused;
}
*/
extern "C" JNIEXPORT void Java_axblare_torcsgreat_MainActivity_startCarRacing(JNIEnv*, jclass)
{
	LinuxSpecInit();
	JNI_playMusicFile(0); // Play background music
//	SND_InitSound(iSampleRate, iBufferSize);
}

extern "C" JNIEXPORT void Java_axblare_torcsgreat_MainActivity_continueRacing(JNIEnv*, jclass)
{
	if(ReInfo && ReInfo->s->_raceState&RM_RACE_PAUSED) ReBoardInfo(nullptr); // Continue racing if paused
}

extern "C" JNIEXPORT void Java_axblare_torcsgreat_MyRenderer_LoadGameAssets(JNIEnv* jEnv, jclass, jobject hMan)
{
	printGlString("Version", GL_VERSION);
	printGlString("Vendor", GL_VENDOR);
	printGlString("Renderer", GL_RENDERER);
	const auto pAssetManager = AAssetManager_fromJava(jEnv, hMan);
	pAxblare_Vert = JNI_GetShaderAsset(pAssetManager, "axblare.vert"); // Common vertex shader data
	pAxblare_Glsl = JNI_GetShaderAsset(pAssetManager, "axblare.glsl"); // Common uniform shader data
	pAxblare_Frag = JNI_GetShaderAsset(pAssetManager, "axblare.frag"); // Common fragment shader data
	JNI_LoadShaderAsset(pAssetManager, kCanvas, "canvas.vert", "canvas.frag");
	JNI_LoadShaderAsset(pAssetManager, kGraph, "graph.vert", "graph.frag");
	JNI_LoadShaderAsset(pAssetManager, kImage, "image.vert", "image.frag");
	JNI_LoadShaderAsset(pAssetManager, kModel, "model.vert", "model.frag");
	JNI_LoadShaderAsset(pAssetManager, kObject, "object.vert", "object.frag");
}

extern "C" JNIEXPORT void Java_axblare_torcsgreat_MyRenderer_ResetViewport(JNIEnv*, jclass, jint iW, jint iH)
{
	LogInfo("Java_axblare_torcsgreat_MyRenderer_ResetViewport: iW = %d iH = %d", iW, iH); // TODO: delete later
	glViewport(0, 0, iW, iH);
	GfScrWidth = iW;
	GfScrHeight = iH;
	GfViewWidth = iW;
	GfViewHeight = iH;
}

extern "C" JNIEXPORT jint Java_axblare_torcsgreat_MyRenderer_RenderFrame(JNIEnv*, jclass, jint iState)
{
	if(iState < 1) {
		static const auto xSplash = system_clock::now()+seconds(3); // Show splash screen for 3 seconds
		static const auto qSplash = LoadImage("data/img/splash.png"); // Use static storage to initialize once
		if(system_clock::now() < xSplash) {
			ax_ClearScreen();
			PasteImage(qSplash);
			return 0;
		}
		RemoveImage(qSplash);
		TorcsEntry();
		return 1;
	} else if(iState < 2) {
		if(pCurrentMenuHandle) {
			JNI_playMusicFile(1); // Play background music
			ax_ClearScreen();
			GfuiScreenActivate(pCurrentMenuHandle);
			drawPlayerCar(); // Pick a new car for the player
		}
		if(!ReInfo || ReInfo->_reState < RE_STATE_EVENT_INIT) return 1;
//		LogInfo("Java_axblare_torcsgreat_MyRenderer_RenderFrame: ReInfo->_reState = %d", ReInfo->_reState); // TODO: delete later
		if(ReInfo->_reState == RE_STATE_RACE) {
			JNI_playMusicFile(-1); // Stop background music
			g_bStateRace = true;
			g_iTouchButton = 0; // Clear button status before racing
			return 2;
//			return 5; // TODO: delete later
		}
		if(ReInfo->_reState >= RE_STATE_EVENT_INIT && iWorkThreadRunning) {
			if(iWorkThreadRunning++ > 1) {
				iWorkThreadRunning = 0;
				ReStateManage();
			}
		}
		return 1;
	} else if(iState < 3) {
		ax_ClearScreen();
		ReStateManage();
		if(ReInfo->_reState == RE_STATE_RACE) {
			GfuiDisplay();
			return 2;
		}
		g_bStateRace = false;
		g_iTouchButton = 0; // Clear button status after racing
		LogInfo("inside Java_axblare_torcsgreat_MainActivity_setTouchAction: ReInfo->_reState = %d", ReInfo->_reState); // TODO: delete later
		pCurrentMenuHandle = ReInfo->_reGameScreen;
		LogError("inside Java_axblare_torcsgreat_MainActivity_setTouchAction: grTrack->length = %g", grTrack->length); // TODO: delete later
		int iRaceCount = 0;
//		int iFinishedLaps = 0;
		float fRaceKilos = 0;
		const auto bRaceEnded = ReInfo->_reState == RE_STATE_RACE_END;
		for(int i = 0; i < ReInfo->s->_ncars; i++) {
			if(auto car = &(ReInfo->carList[i]); car->_driverType == RM_DRV_HUMAN) {
//				iFinishedLaps = std::clamp(car->_laps-1, 0, ReInfo->s->_totLaps);
				iRaceCount = bRaceEnded;
				fRaceKilos = car->_distRaced/1000.0f; // Convert distance to kilometers
//				iFinishedLaps = car->_laps-1;
//				if(iFinishedLaps < 0) iFinishedLaps = 0;
//				if(iFinishedLaps > ReInfo->s->_totLaps) iFinishedLaps = ReInfo->s->_totLaps;
				break;
			}
		}
		LogError("inside Java_axblare_torcsgreat_MainActivity_setTouchAction: fRaceKilos = %g", fRaceKilos); // TODO: delete later
		JNI_showPopupAd(iRaceCount, fRaceKilos, bRaceEnded);
		return 1; // Not in race state anymore
	} else if(iState < 6) {
		glColor4f(1.0, 1.0, 1.0, 1.0);
		static GLuint uTexture = 160;
		static auto xSplash = system_clock::now()+seconds(1);
		if(system_clock::now() < xSplash) {
			ax_PasteImage(uTexture);
		} else {
			if(uTexture++ >= 164) uTexture = 160;
			const auto bTexture = glIsTexture(uTexture);
			LogError("inside setTouchAction: uTexture = %d bTexture = %d", uTexture, bTexture); // TODO: delete later
			xSplash = system_clock::now()+seconds(3);
		}
		return 5;
	}
	return iState;
}
