/////////////////////////////////////////////////////////////////////////////
//                                                                         //
//   Torcs Great is an Android port of the famous open source game TORCS   //
//   Copyright (c) 2019-2020, Wei Zhang <mailto:weizhang1999@gmail.com>.   //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
//
// See the original TORCS game at <https://sourceforge.net/projects/torcs/>.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

//----------------------------------------------------------------------------------------------------------------------------------------------
// Global Definitions
//----------------------------------------------------------------------------------------------------------------------------------------------
#pragma once // Define everything once

#include "ax_define.h" // Data definitions
#include "ax_depict.h" // Shader variables

struct AXTEXTURE
{
	string cFile;   // Filename (with relative path) for the texture
	int iFlags = 0; // Index to the texture map (tiled or mipmaps)
	int iRefer = 0; // The number of references to this texture
	int iWidth = 0; // Width of the bitmap
	int iHeight = 0; // Height of the bitmap
};

inline map<string, map<int, GLuint>> g_cTexMap; // Filenames for the texture and mipmaps
inline map<GLuint, AXTEXTURE> g_uTexRef; // The number of references to this texture

inline void ax_ReleaseTexture(GLuint uTexture)
{
	auto& aTexture = g_uTexRef[uTexture]; // Texture structure reference
	if(!uTexture || --aTexture.iRefer > 0) return; // Texture cannot be deleted
//	LogInfo("ax_ReleaseTexture: glIsTexture(%u) = %d %s", uTexture, glIsTexture(uTexture), aTexture.cFile.c_str()); // TODO: delete later
	if(glIsTexture(uTexture)) glDeleteTextures(1, &uTexture);
//	LogError("ax_ReleaseTexture: glIsTexture(%u) = %d %s", uTexture, glIsTexture(uTexture), aTexture.cFile.c_str()); // TODO: delete later
	g_cTexMap[aTexture.cFile].erase(aTexture.iFlags);
	g_uTexRef.erase(uTexture);
}

struct AXBITMAP
{
	int iWidth = 0; // Width of the bitmap
	int iHeight = 0; // Height of the bitmap
	GLuint uTexture = 0; // Texture identifier
	~AXBITMAP()
	{
		ax_ReleaseTexture(uTexture);
	}
};

struct AXIMAGE : AXBITMAP
{
	uint* pColor {nullptr}; // Pointer to the 32-bit color (ARGB) pixels of the locked image
	uint uPitch = 0; // Uncompressed texture row pitch (in 4 bytes) of the locked image
};

struct AXSOUND
{
//	VocVar<IXAudio2SourceVoice*> pVoice; // Voice data pointer (should be released even the sound is a clone)
//	AXSOUND* pRefer {nullptr}; // Reference sound pointer (nullptr for original)
//	BYTE   * pWave {nullptr}; // WAVEFORMATEX structure pointer
//	BYTE   * pData {nullptr}; // Sound data array pointer
	uint uSize; // Sound data array size
	uint uFlags = 0; // Status of sound (test if it is paused)
	~AXSOUND()
	{
//		if(pRefer) return; // Cloned sound does not need to delete allocated memory
//		SAFE_DELETE(pWave); // WAVEFORMATEX structure memory must be deleted
//		SAFE_DELETE(pData); // Sound data array memory must be deleted
	}
};
inline list<AXIMAGE> g_aImage;   // Aggregate container of AXIMAGE
inline list<AXSOUND> g_aSound;   // Aggregate container of AXSOUND

#include "ax_inline.h" // Inline functions
