#include "android_jni.h"

AXIMAGE* LoadImage(const char* pFile)
{
	return ax_LoadBitmap(g_aImage, pFile);
}

void PasteImage(AXIMAGE* qImage)
{
	if(!ax_Poll(g_aImage, qImage)) return;
	ax_PasteImage(qImage->uTexture);
}

void RemoveImage(AXIMAGE* qImage)
{
	ax_Erase(g_aImage, qImage);
}
