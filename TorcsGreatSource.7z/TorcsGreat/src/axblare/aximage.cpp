/////////////////////////////////////////////////////////////////////////////
//                                                                         //
//   Torcs Great is an Android port of the famous open source game TORCS   //
//   Copyright (c) 2019-2020, Wei Zhang <mailto:weizhang1999@gmail.com>.   //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
//
// See the original TORCS game at <https://sourceforge.net/projects/torcs/>.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

#include "android_jni.h"

AXIMAGE* LoadImage(const char* pFile)
{
	return ax_LoadBitmap(g_aImage, pFile);
}

void PasteImage(AXIMAGE* qImage)
{
	if(!ax_Poll(g_aImage, qImage)) return;
	ax_PasteImage(qImage->uTexture);
}

void RemoveImage(AXIMAGE* qImage)
{
	ax_Erase(g_aImage, qImage);
}
