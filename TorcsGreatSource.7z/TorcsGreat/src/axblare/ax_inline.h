/////////////////////////////////////////////////////////////////////////////
//                                                                         //
//   Torcs Great is an Android port of the famous open source game TORCS   //
//   Copyright (c) 2019-2020, Wei Zhang <mailto:weizhang1999@gmail.com>.   //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
//
// See the original TORCS game at <https://sourceforge.net/projects/torcs/>.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

inline int GfScrWidth = 640;
inline int GfScrHeight = 480;
inline int GfViewWidth = 640;
inline int GfViewHeight = 480;

AXIMAGE* LoadImage(const char* pFile);
void PasteImage(AXIMAGE* qImage);
void RemoveImage(AXIMAGE* qImage);

inline void ax_Build2DMipmaps(GLint iFormat, GLenum eFormat, GLsizei width, GLsizei height, const void* pixels)
{
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); // Only the minification filter can do that
	glTexImage2D(GL_TEXTURE_2D, 0, iFormat, width, height, 0, eFormat, GL_UNSIGNED_BYTE, pixels);
	checkGlError("ax_Build2DMipmaps: glTexImage2D");
	glGenerateMipmap(GL_TEXTURE_2D); // Generate mipmaps (legacy GL_GENERATE_MIPMAP)
	checkGlError("ax_Build2DMipmaps: glGenerateMipmap");
}

inline const AXPROGRAM& SetShader2D(int iProg, const float* qVert, const vec4& vQuat = {0, 0, 0, 1}, float fScale = 1)
{
	const auto& aProg = SetProgramCurrent(iProg); // Set the current program
	glUniform4fv(aProg.s_vAmbientColor, 1, &g_vAmbientColor.x);
	glUniform4fv(aProg.s_vGlobalNormal, 1, &g_vGlobalNormal.x);
	glUniform3f(aProg.s_vCamPosition, g_vDisplayScale.x, g_vDisplayScale.y, 0);
	glUniform1f(aProg.s_fMirrorRatio, fScale);
	glUniform4fv(aProg.s_vQuaterTrans, 1, &vQuat.x);
	glUniform1f(aProg.s_fAlphaClip, g_fCompareRef);
	glUniform1i(aProg.s_bAlphaTest, g_bAlphaTest);
	if(iProg == kGraph) {
		ax_SetVertexPosition(aProg.s_vPosL, qVert, 2);
	} else {
		ax_SetVertexPosition(aProg.s_vPosL, qVert, 2, 4*sizeof(float));
		ax_SetVertexTexcoord(aProg.s_vTexL, qVert+2, 4*sizeof(float));
	}
	return aProg;
}

//----------------------------------------------------------------------------------------------------------------------------------------------
// Draw canvas/image/skybox/sprite, shadow map or mirror image
//----------------------------------------------------------------------------------------------------------------------------------------------
inline void ax_DrawQuad(const GLuint uTexture, const int iProgram, const float* qVertex, const int nCount, const void* qIndex = nullptr)
{
	const auto& aProg = SetShader2D(iProgram, qVertex);
	if(uTexture) {
		ax_BindTexture(aProg, uTexture);
	}
	if(qIndex) {
		glDrawElements(GL_TRIANGLES, nCount, GL_UNSIGNED_SHORT, qIndex);
	} else {
		glDrawArrays(GL_TRIANGLE_STRIP, 0, nCount);
	}
	glDisableVertexAttribArray(aProg.s_vPosL);
	glDisableVertexAttribArray(aProg.s_vTexL);
	if(uTexture) {
		glBindTexture(GL_TEXTURE_2D, 0);
		glDisable(GL_TEXTURE_2D);
	}
}

//----------------------------------------------------------------------------------------------------------------------------------------------
// Draw text to current canvas on top of anything else at given coordinates aligned left
//----------------------------------------------------------------------------------------------------------------------------------------------
inline void ax_DrawText(GfuiFontClass* qFont, float fSize, int iX, int iY, const char* qText)
{
	//Get length of string
	const int Length = strlen(qText);

	//Return if we don't have a valid glFont
	if(!qFont->Char || Length < 1) return;

	const auto nVertices = static_cast<GLuint>(4*Length);
	const auto nIndices = static_cast<GLushort>(6*Length);

	vector<vec4> vertices(nVertices);
	vector<GLushort> indices(nIndices);

	auto qVertex = vertices.data();
	auto qIndices = indices.data();

	auto fX = (float)iX;
	auto fY = (float)iY;

	//Loop through characters
	for(int i = 0, j = 0; i < Length; i++, j += 4) {
		//Get pointer to glFont character
		const auto Char = &qFont->Char[(int)qText[i]-qFont->IntStart];
		const auto fW = Char->dx*fSize;
		const auto fH = Char->dy*fSize;
		const auto fT = (Char->ty2-Char->ty1)/fH; // One unit shift for texture coordinate

		//Specify vertices and texture coordinates
		*qVertex++ = vec4(fX, fY+fH, Char->tx1, Char->ty1+fT);
		*qVertex++ = vec4(fX, fY, Char->tx1, Char->ty2+fT);
		*qVertex++ = vec4(fX+fW, fY, Char->tx2, Char->ty2+fT);
		*qVertex++ = vec4(fX+fW, fY+fH, Char->tx2, Char->ty1+fT);

		*qIndices++ = static_cast<GLushort>(j);
		*qIndices++ = static_cast<GLushort>(j+1);
		*qIndices++ = static_cast<GLushort>(j+2);
		*qIndices++ = static_cast<GLushort>(j);
		*qIndices++ = static_cast<GLushort>(j+3);
		*qIndices++ = static_cast<GLushort>(j+2);

		//Move to next character
		fX += fW;
	}
	ax_DrawQuad(qFont->Tex, kCanvas, &vertices[0].x, nIndices, indices.data());
}

//----------------------------------------------------------------------------------------------------------------------------------------------
// Load the specified image to a resource view (available for desktop only)
//----------------------------------------------------------------------------------------------------------------------------------------------
inline GLuint ax_LoadTexture(AXBITMAP* qBitmap, GLubyte* qImage, const char* qFile, bool bTiled = false, GfuiFontClass* qFont = nullptr)
{
	auto& uTexture = g_cTexMap[qFile][bTiled]; // Texture identifier reference
	if(!uTexture) glGenTextures(1, &uTexture); // Create a new texture id
	auto& aTexture = g_uTexRef[uTexture]; // Texture structure reference
//	LogError("inside ax_LoadTexture: uTexture = %d iRefer = %d %s", uTexture, aTexture.iRefer, qFile); // TODO: delete later
	const auto& qExt = strchr(qFile, '.');
	if(aTexture.iRefer < 1) { // Texture is empty
		if(!qExt) return 0; // No file extension
		GLint iFormat = GL_RGBA;
		GLenum eFormat = GL_RGBA;
		if(qFont) {
			iFormat = GL_LUMINANCE_ALPHA;
			eFormat = GL_LUMINANCE_ALPHA;
			aTexture.iWidth = qFont->TexWidth;
			aTexture.iHeight = qFont->TexHeight;
		} else if(!strcasecmp(qExt, ".png")) {
			auto qParam = GfParmReadFile(GFSCR_CONF_FILE, GFPARM_RMODE_STD|GFPARM_RMODE_CREAT);
			const auto fGamma = (float)GfParmGetNum(qParam, GFSCR_SECT_PROP, GFSCR_ATT_GAMMA, (char*)NULL, 2.0);
			qImage = GfImgReadPng(qFile, &aTexture.iWidth, &aTexture.iHeight, fGamma);
			GfParmReleaseHandle(qParam);
		} else {
			ssgTextureInfo info;
			grLoadSGI(qFile, &info);
			aTexture.iWidth = info.width;
			aTexture.iHeight = info.height;
			qImage = info.pImage;
		}
		if(qImage) { // Texture image data (font has been read)
//			LogInfo("inside ax_LoadTexture after glGenTextures: uTexture = %d %s", uTexture, cFile); // TODO: delete later
			glBindTexture(GL_TEXTURE_2D, uTexture);
			glTexImage2D(GL_TEXTURE_2D, 0, iFormat, aTexture.iWidth, aTexture.iHeight, 0, eFormat, GL_UNSIGNED_BYTE, qImage);
			checkGlError("ax_LoadTexture: glTexImage2D");
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
			if(bTiled) {
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
			} else {
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
			}
			glBindTexture(GL_TEXTURE_2D, 0);
			aTexture.cFile = qFile;
			aTexture.iFlags = bTiled;
		} else {
			LogError("ax_LoadTexture failed: iWidth = %d iHeight = %d %s", aTexture.iWidth, aTexture.iHeight, qFile); // TODO: delete later
			GfTrace("Couldn't read %s\n", qFile);
			glDeleteTextures(1, &uTexture);
			g_uTexRef.erase(uTexture);
			return 0;
		}
	}
	if(qImage) {
		if(qFont || !strcasecmp(qExt, ".png")) { // TODO: use the same memory management later
			free(qImage);
		} else {
			delete[] qImage;
		}
	}
	if(qBitmap) {
		qBitmap->iWidth = aTexture.iWidth;
		qBitmap->iHeight = aTexture.iHeight;
		qBitmap->uTexture = uTexture;
	}
	aTexture.iRefer++; // Number of references to the texture
//	LogInfo("inside ax_LoadTexture: uTexture = %d iRefer = %d %s", uTexture, aTexture.iRefer, qFile); // TODO: delete later
	return uTexture;
}

template<typename T>
inline T* const ax_LoadBitmap(list<T>& tList, const char* pFile)
{
	LogInfo("inside ax_LoadBitmap: tList.size() = %u %s", tList.size(), pFile); // TODO: delete later
	const auto& qBitmap = ax_Add(tList);
	if(!qBitmap || !ax_LoadTexture(qBitmap, nullptr, pFile)) {
		ax_Erase(tList, qBitmap);
		return nullptr;
	}
	LogError("inside ax_LoadBitmap: tList.size() = %u %s", tList.size(), pFile); // TODO: delete later
	return qBitmap;
}

inline void ax_DrawImage(GLuint uTexture, const vec2& fP, const vec2& fS, const mat2x2& fT = vFull4)
{
	const auto fX = g_vDisplayScale.x*fP.x-1;
	const auto fY = g_vDisplayScale.y*fP.y-1;
	const auto fW = g_vDisplayScale.x*fS.x;
	const auto fH = g_vDisplayScale.y*fS.y;
	float fCoords[16] = { // Homogeneous coordinates
		fX, fY+fH, fT[0].x, fT[1].y, // top left corner
		fX, fY, fT[0].x, fT[0].y, // bottom left corner
		fX+fW, fY+fH, fT[1].x, fT[1].y, // top right corner
		fX+fW, fY, fT[1].x, fT[0].y}; // bottom right corner
	ax_DrawQuad(uTexture, kImage, fCoords, 4);
}

inline void ax_PaintImage(GLuint uTexture, const mat4x2& mCorners, const mat2x2& fT = vFull4)
{
	float fCoords[16] = { // Homogeneous coordinates
		g_vDisplayScale.x*mCorners[0].x-1, g_vDisplayScale.y*mCorners[0].y-1, fT[0].x, fT[1].y,  // top left corner
		g_vDisplayScale.x*mCorners[1].x-1, g_vDisplayScale.y*mCorners[1].y-1, fT[0].x, fT[0].y,  // bottom left corner
		g_vDisplayScale.x*mCorners[2].x-1, g_vDisplayScale.y*mCorners[2].y-1, fT[1].x, fT[1].y,  // top right corner
		g_vDisplayScale.x*mCorners[3].x-1, g_vDisplayScale.y*mCorners[3].y-1, fT[1].x, fT[0].y}; // bottom right corner
	ax_DrawQuad(uTexture, kImage, fCoords, 4);
}

inline void ax_PasteImage(GLuint uTexture)
{
	float fCoords[16] = { // Homogeneous coordinates
		-1, +1, 0, 1,  // top left corner
		-1, -1, 0, 0,  // bottom left corner
		+1, +1, 1, 1,  // top right corner
		+1, -1, 1, 0}; // bottom right corner
	ax_DrawQuad(uTexture, kImage, fCoords, 4);
}
