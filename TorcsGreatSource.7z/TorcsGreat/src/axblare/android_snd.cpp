/////////////////////////////////////////////////////////////////////////////
//                                                                         //
//   Torcs Great is an Android port of the famous open source game TORCS   //
//   Copyright (c) 2019-2020, Wei Zhang <mailto:weizhang1999@gmail.com>.   //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
//
// See the original TORCS game at <https://sourceforge.net/projects/torcs/>.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

#include <map>
#include <list>
#include <atomic>
#include <vector>
#include "oboe/Oboe.h"
#include "android_snd.h"
using namespace oboe;
using namespace std;

int g_nBufferSize = 1024;
uint8_t g_bSoundEnabled = 0;

struct SoundOutput : AudioStreamCallback
{
	vector<uint8_t> pSampleBuffer;
	atomic<int> iSampleBegin = 0; // Sample begin position (inclusive)
	atomic<int> iSampleEnd = 0; // Sample end position (exclusive)
	AudioStreamBuilder builder; // Default sharing mode is Shared
	AudioStream* stream = nullptr; // Stream associated with the sound
	DataCallbackResult onAudioReady(AudioStream* oboeStream, void* audioData, int32_t numFrames) override
	{
		const auto nByte = numFrames*oboeStream->getBytesPerFrame(); // Buffer size in bytes
		if(!g_bSoundEnabled || !g_bStateRace || !soundInitialized || getSampleSize() <= 0) {
			memset(audioData, 0, (size_t)nByte); // Silence the audio
		} else {
			const auto nShort = nByte/2; // Buffer size in shorts
			auto qAudio = (short*)audioData; // Cast data pointer to short
			for(int i = 0; i < nShort; i++) {
				*qAudio++ = short(getSampleSize() > 0 ? (pSampleBuffer[iSampleBegin++]-128)*256 : 0);
				iSampleBegin = iSampleBegin.load()%pSampleBuffer.size();
			}
		}
//		LogInfo("inside onAudioReady: numFrames = %d nByte = %d", numFrames, nByte); // TODO: delete
		return DataCallbackResult::Continue;
	}
	void onErrorBeforeClose(AudioStream* oboeStream, Result error) override
	{
		closeStream();
	}
	void onErrorAfterClose(AudioStream* oboeStream, Result error) override
	{
		stream = nullptr;
	}
	SoundOutput()
	{
		builder.setFormat(AudioFormat::I16);
		builder.setDirection(Direction::Output);
		builder.setSharingMode(SharingMode::Shared);
		builder.setPerformanceMode(PerformanceMode::PowerSaving);
		builder.setCallback(this); // Callback associated with the sound
	}
	~SoundOutput()
	{
		closeStream();
	}
	inline void closeStream()
	{
		if(!stream || stream->getState() == StreamState::Closed) return;
		stopStream();
		stream->close(); // Do not call waitForStateChange() after calling close()
	}
	inline void stopStream()
	{
		if(!stream || stream->getState() == StreamState::Closed) return;
		stream->requestStop();
		awaitState(StreamState::Stopping);
	}
	inline void awaitState(StreamState inputState)
	{
		StreamState nextState = StreamState::Uninitialized;
		const int64_t timeoutNanos = 100*kNanosPerMillisecond;
		stream->waitForStateChange(inputState, &nextState, timeoutNanos); // Wait for state change
	}
	inline int getSampleSize()
	{
		if(iSampleEnd >= iSampleBegin) return iSampleEnd-iSampleBegin;
		return (int)pSampleBuffer.size()-(iSampleBegin-iSampleEnd);
	}
	inline int getUnusedSize()
	{
		if(!g_bSoundEnabled) return 0; // Buffer is not available
		if(iSampleEnd < iSampleBegin) return iSampleBegin-iSampleEnd;
		return (int)pSampleBuffer.size()-(iSampleEnd-iSampleBegin);
	}
};

SoundOutput g_SoundOutput; // Sound output map

void SND_InitSound(int iFreq, int iSize)
{
	DefaultStreamValues::SampleRate = iFreq; // Set in renderer thread
	DefaultStreamValues::FramesPerBurst = iSize; // Set in renderer thread
	const auto& qSound = &g_SoundOutput; // Get a pointer reference to the mapped value
	auto& qStream = qSound->stream; // Get a pointer reference to the audio stream
	auto& aBuilder = qSound->builder;
	aBuilder.setSampleRate(SL_DEFAULT_SAMPLING_RATE); // Fixed sample rate
	aBuilder.setChannelCount(1); // There is no stereo sound in this game
	if(Result result = aBuilder.openStream(&qStream); result != Result::OK) return; // Open stream after all settings are done
	g_nBufferSize = max(qStream->getBufferSizeInFrames(), 1024);
	qSound->pSampleBuffer.resize(g_nBufferSize*8U);
	qStream->requestStart();
//	LogInfo("inside SND_InitSound: iFreq = %d iSize = %d g_nBufferSize = %d", iFreq, iSize, g_nBufferSize); // TODO: delete later
}

int SND_GetUnusedSize()
{
	const auto& qSound = &g_SoundOutput; // Get a pointer reference to the mapped value
	return qSound->getUnusedSize();
}

void SND_WriteBuffer(uint8_t* pBuffer, int iLength)
{
//	LogError("inside SND_WriteBuffer: pBuffer = %p iLength = %d", pBuffer, iLength); // TODO: delete later
	const auto& qSound = &g_SoundOutput; // Get a pointer reference to the mapped value
	for(int i = 0; i < iLength; i++) {
		qSound->pSampleBuffer[qSound->iSampleEnd++] = *pBuffer++;
		qSound->iSampleEnd = qSound->iSampleEnd.load()%qSound->pSampleBuffer.size();
	}
}

void SND_StopSound()
{
	const auto& qSound = &g_SoundOutput; // Get a pointer reference to the mapped value
	qSound->iSampleBegin = 0;
	qSound->iSampleEnd = 0;
}
