/***************************************************************************
                         guifont.cpp -- GLTT fonts management
                             -------------------
    created              : Fri Aug 13 22:19:09 CEST 1999
    copyright            : (C) 1999 by Eric Espie
    email                : torcs@free.fr
    version              : $Id: guifont.cpp,v 1.4.2.5 2012/06/10 01:18:03 berniw Exp $
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/* This font manipulation is based on Brad Fish's glFont format and code.  */
/* http://www.netxs.net/bfish/news.html                                    */

#include <stdio.h>
#include <stdlib.h>

#include <tgfclient.h>
#include <portability.h>

#include "guifont.h"
#include "android_jni.h"

#define FONT_NB 9
GfuiFontClass* gfuiFont[FONT_NB];
const char* keySize[4] = {"size big", "size large", "size medium", "size small"};

void gfuiLoadFonts(void)
{
	void* param;
	int size;
	int i;
	const int BUFSIZE = 1024;
	char buf[BUFSIZE];

	snprintf(buf, BUFSIZE, "%s", GFSCR_CONF_FILE);
	param = GfParmReadFile(buf, GFPARM_RMODE_STD|GFPARM_RMODE_CREAT);
//	LogInfo("gfuiLoadFonts: buf = %s, param = %p", buf, param); // TODO: delete later

	const char* fontName = GfParmGetStr(param, "Menu Font", "name", "b5.glf");
	snprintf(buf, BUFSIZE, "data/fonts/%s", fontName);

	for(i = 0; i < 4; i++) {
		size = (int)GfParmGetNum(param, "Menu Font", keySize[i], (char*)NULL, 10.0);
		gfuiFont[i] = new GfuiFontClass(buf);
		gfuiFont[i]->create(size);
	}

	fontName = GfParmGetStr(param, "Console Font", "name", "b7.glf");
	snprintf(buf, BUFSIZE, "data/fonts/%s", fontName);

	for(i = 0; i < 4; i++) {
		size = (int)GfParmGetNum(param, "Console Font", keySize[i], (char*)NULL, 10.0);//+(i < 2 ? 0 : 2); // Increase font size
		gfuiFont[i+4] = new GfuiFontClass(buf);
		gfuiFont[i+4]->create(size);
	}

	fontName = GfParmGetStr(param, "Digital Font", "name", "digital.glf");
	snprintf(buf, BUFSIZE, "data/fonts/%s", fontName);
	size = (int)GfParmGetNum(param, "Digital Font", keySize[0], (char*)NULL, 8.0);
	gfuiFont[8] = new GfuiFontClass(buf);
	gfuiFont[8]->create(size);

	GfParmReleaseHandle(param);
}


GLubyte* GfLoadFont(const char* FileName, GfuiFontClass* qFont)
{
	FILE* Input;
	GLubyte* TexBytes;

	//Open font file
	if((Input = fopen(getAbsPath(FileName), "rb")) == NULL) {
		perror(FileName);
		return nullptr;
	}

	//Read glFont structure
	//fread(font, sizeof(GLFONT), 1, Input);
	fread(qFont, 24, 1, Input); // for IA64...

	//Get number of characters
	auto Num = qFont->IntEnd-qFont->IntStart+1;
	const size_t uBytes = sizeof(GLFONTCHAR)*Num;

	//Allocate memory for characters
	if((qFont->Char = (GLFONTCHAR*)malloc(uBytes)) == NULL) {
		fclose(Input);
		return nullptr;
	}

	//Read glFont characters
	fread(qFont->Char, sizeof(GLFONTCHAR), Num, Input);

	//Get texture size
	Num = qFont->TexWidth*qFont->TexHeight*2;

	//Allocate memory for texture data
	if((TexBytes = (GLubyte*)malloc(Num)) == NULL) {
		fclose(Input);
		return nullptr;
	}

	//Read texture data
	fread(TexBytes, sizeof(char), Num, Input);

	fclose(Input);

	return TexBytes;
}

GfuiFontClass::GfuiFontClass(char* FileName)
{
//	LogInfo("inside GfuiFontClass::GfuiFontClass: file = %s", FileName); // TODO: delete later
	auto TexBytes = GfLoadFont(FileName, this);
	if(TexBytes) Tex = ax_LoadTexture(nullptr, TexBytes, FileName, false, this); // TexBytes will be freed inside the function
//	LogInfo("inside GfuiFontClass::GfuiFontClass: Tex = %d %d X %d", Tex, TexWidth, TexHeight); // TODO: delete later
}


GfuiFontClass::~GfuiFontClass()
{
	if(Char) {
		ax_ReleaseTexture(Tex);
		free(Char);
	}
}


void GfuiFontClass::create(int point_size)
{
	size = point_size;
}


int GfuiFontClass::getWidth(const char* text)
{
	if(Char == NULL) {
		return 0;
	}

	float width = 0;
	g_fTextHeight = 0;

	//Get length of string
	int Length = strlen(text);

	//Loop through characters
	for(int i = 0; i < Length; i++) {
		//Get pointer to glFont character
		auto qChar = &Char[(int)text[i]-IntStart];
		width = width+qChar->dx*size;
		if(g_fTextHeight < qChar->dy) g_fTextHeight = qChar->dy;
	}
	g_fTextHeight *= size;

	return (int)(width+0.5f);
}


int GfuiFontClass::getHeight() const
{
	if(Char == NULL) return 0;
	return (const int)(Char[0].dy*size);
}


int GfuiFontClass::getDescender() const
{
	if(Char == NULL) return 0;
	return (const int)(Char[0].dy*size/2.0);
}


void GfuiFontClass::output(int X, int Y, const char* text)
{
	if(g_iDrawScene > 0) ax_DrawText(this, size, X, Y, text);
}
