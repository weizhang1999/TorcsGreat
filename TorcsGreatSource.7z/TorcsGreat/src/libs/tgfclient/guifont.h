/***************************************************************************
                        guifont.h -- Interface file for guifont
                             -------------------
    created              : Fri Aug 13 22:20:04 CEST 1999
    copyright            : (C) 1999 by Eric Espie
    email                : torcs@free.fr
    version              : $Id: guifont.h,v 1.2 2003/06/24 21:02:25 torcs Exp $
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef _GUIFONT_H_
#define _GUIFONT_H_
#include <sys/types.h>

#pragma pack(push, 1) // Set the current packing alignment to one byte

//glFont character structure (DO NOT MODIFY)
struct GLFONTCHAR
{
	float dx, dy;
	float tx1, ty1;
	float tx2, ty2;
};

//glFont structure (DO NOT MODIFY)
struct GLFONT
{
	uint Tex; // Texture identifier
	int TexWidth, TexHeight;
	int IntStart, IntEnd;
	float size; // Font size
};

struct GfuiFontClass : GLFONT
{
	GLFONTCHAR* Char = nullptr;

	GfuiFontClass(char* font);

	~GfuiFontClass();

	void create(int point_size);

	void output(int x, int y, const char* text);

	int getWidth(const char* text);
	int getHeight() const;
	int getDescender() const;
};

#pragma pack(pop) // Restore the original packing alignment from stack

extern GfuiFontClass* gfuiFont[];
inline float g_fTextHeight = 0;

#endif /* _GUIFONT_H_ */
