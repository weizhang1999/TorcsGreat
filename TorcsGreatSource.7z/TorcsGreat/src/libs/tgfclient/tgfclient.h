/***************************************************************************
                    tgfclient.h -- Interface file for The Gaming Framework
                             -------------------
    created              : Fri Aug 13 22:32:14 CEST 1999
    copyright            : (C) 1999-2014 by Eric Espie, Bernhard Wymann
    email                : torcs@free.fr
    version              : $Id: tgfclient.h,v 1.3.2.7 2015/04/18 11:04:54 berniw Exp $
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file
    	The Gaming Framework API (client part).
    @author	<a href=mailto:torcs@free.fr>Eric Espie</a>
    @version	$Id: tgfclient.h,v 1.3.2.7 2015/04/18 11:04:54 berniw Exp $
*/



#ifndef __TGFCLIENT__H__
#define __TGFCLIENT__H__

#include <tgf.h>
#include <GLES2/gl2.h>
#include <screen_properties.h>

#define NUM_JOY 8

extern void GfInitClient();

/********************
 * Screen Interface *
 ********************/

extern unsigned char* GfImgReadPng(const char* filename, int* widthp, int* heightp, float gamma);
extern void GfImgFreeTex(GLuint tex);
extern GLuint GfImgReadTex(char* filename);

extern void GfScrInit(int argc, char* argv[]);
extern void GfScrShutdown();
extern void* GfScrMenuInit(void* precMenu);
extern void GfTime2Str(char* result, int resultSize, tdble sec, int sgn);
extern void GfScrGetSize(int* ScrW, int* ScrH, int* ViewW, int* ViewH);
extern void GfScrReinit(void*);

/*****************************
 * GUI interface (low-level) *
 *****************************/

/* Widget type */
#define GFUI_LABEL     0
#define GFUI_BUTTON    1
#define GFUI_GRBUTTON  2
#define GFUI_SCROLLIST 3
#define GFUI_SCROLLBAR 4
#define GFUI_EDITBOX   5

/* Alignment */
#define GFUI_ALIGN_HL_VB 0x00
#define GFUI_ALIGN_HL_VC 0x01
#define GFUI_ALIGN_HL_VT 0x02
#define GFUI_ALIGN_HC_VB 0x10
#define GFUI_ALIGN_HC_VC 0x11
#define GFUI_ALIGN_HC_VT 0x12
#define GFUI_ALIGN_HR_VB 0x20
#define GFUI_ALIGN_HR_VC 0x21
#define GFUI_ALIGN_HR_VT 0x22

/* Mouse action */
#define GFUI_MOUSE_UP   0
#define GFUI_MOUSE_DOWN 1

/* Keyboard action */
#define GFUI_KEY_UP   0
#define GFUI_KEY_DOWN 1

/* Scroll Bar position */
#define GFUI_SB_NONE  0
#define GFUI_SB_RIGHT 1
#define GFUI_SB_LEFT  2

/* Scroll bar orientation */
#define GFUI_HORI_SCROLLBAR 0
#define GFUI_VERT_SCROLLBAR 1

/** Scroll bar call-back information */
typedef struct ScrollBarInfo
{
	int pos; /**< Current scroll bar position */
	void* userData; /**< Associated user data */
} tScrollBarInfo;

typedef void (* tfuiCallback)(void* /* userdata */);
typedef void (* tfuiSBCallback)(tScrollBarInfo*);
typedef int (* tfuiKeyCallback)(unsigned char key, int modifier, int state); /**< return 1 to prevent normal key computing */
typedef int (* tfuiSKeyCallback)(int key, int modifier, int state);  /**< return 1 to prevent normal key computing */


/* GLUT Callback functions                  */
/* should be called explicitely if          */
/* the corresponding GLUT Func is overriden */
/* after a call to GfuiActivateScreen       */
extern void GfuiDisplay();
extern void GfuiDisplayNothing();
extern void GfuiIdle();

/* Screen management */
extern void* GfuiScreenCreate();
extern void*
GfuiScreenCreateEx(float* bgColor, void* userDataOnActivate, tfuiCallback onActivate, void* userDataOnDeactivate, tfuiCallback onDeactivate,
	int mouseAllowed);
extern void GfuiScreenRelease(void* screen);
extern void GfuiScreenActivate(void* screen);
extern int GfuiScreenIsActive(void* screen);
extern void GfuiScreenReplace(void* screen);
extern void GfuiScreenDeactivate();
extern void* GfuiHookCreate(void* userDataOnActivate, tfuiCallback onActivate);
extern void GfuiHookRelease(void* hook);
extern void GfuiAddKey(void* scr, unsigned char key, const char* descr, void* userData, tfuiCallback onKeyPressed, tfuiCallback onKeyReleased);
extern void GfuiRegisterKey(unsigned char key, char* descr, void* userData, tfuiCallback onKeyPressed, tfuiCallback onKeyReleased);
extern void GfuiAddSKey(void* scr, int key, const char* descr, void* userData, tfuiCallback onKeyPressed, tfuiCallback onKeyReleased);
extern void GfuiHelpScreen(void* prevScreen);
extern void GfuiScreenShot(void* notused);
extern void GfuiScreenAddBgImg(void* scr, const char* filename);
extern void GfuiKeyEventRegister(void* scr, tfuiKeyCallback onKeyAction);
extern void GfuiSKeyEventRegister(void* scr, tfuiSKeyCallback onSKeyAction);
extern void GfuiKeyEventRegisterCurrent(tfuiKeyCallback onKeyAction);
extern void GfuiSKeyEventRegisterCurrent(tfuiSKeyCallback onSKeyAction);

/* mouse */
typedef struct MouseInfo
{
	int X;
	int Y;
	int button[3];
} tMouseInfo;

extern tMouseInfo* GfuiMouseInfo();
extern void GfuiMouseSetPos(int x, int y);
extern void GfuiMouseHide();
extern void GfuiMouseShow();
extern void GfuiMouseSetHWPresent();

#define GFUI_TEXT_SELECT_DRIVERS "Select Drivers"
#define GFUI_TEXT_SELECT_TRACK   "Select Track"
#define GFUI_TEXT_CONTINUE       "Continue"
#define GFUI_TEXT_OPTIONS        "Options"

#define GFUI_TAP_ACCEPT   "Accept: A"
#define GFUI_TAP_APPLY    "Apply: A"
#define GFUI_TAP_BACK     "Back: X"
#define GFUI_TAP_CANCEL   "Cancel: X"
#define GFUI_TAP_CONTINUE "Continue: Y"

/* all widgets */
#define GFUI_VISIBLE   1 /**< Object visibility flag  */
#define GFUI_INVISIBLE 0 /**< Object invisibility flag  */
extern int GfuiVisibilitySet(void* scr, int id, int visible);
#define GFUI_DISABLE 1
#define GFUI_ENABLE  0
extern int GfuiEnable(void* scr, int id, int flag);
extern void GfuiUnSelectCurrent();

/* labels */
#define GFUI_FONT_BIG      0
#define GFUI_FONT_LARGE    1
#define GFUI_FONT_MEDIUM   2
#define GFUI_FONT_SMALL    3
#define GFUI_FONT_BIG_C    4
#define GFUI_FONT_LARGE_C  5
#define GFUI_FONT_MEDIUM_C 6
#define GFUI_FONT_SMALL_C  7
#define GFUI_FONT_DIGIT    8
extern int GfuiLabelCreate(void* scr, const char* text, int font, int x, int y, int align, int maxlen);
extern int GfuiLabelCreateEx(void* scr, const char* text, float* fgColor, int font, int x, int y, int align, int maxlen);

extern int GfuiTipCreate(void* scr, const char* text, int maxlen);
extern int GfuiTitleCreate(void* scr, const char* text, int maxlen);

extern void GfuiLabelSetText(void* scr, int id, const char* text);
extern void GfuiLabelSetColor(void* scr, int id, float* color);

extern void GfuiPrintString(const char* text, float* fgColor, int font, int x, int y, int align);
extern int GfuiFontHeight(int font);
extern int GfuiFontWidth(int font, const char* text);


/* buttons */
#define GFUI_BTNSZ 300
extern int GfuiButtonCreate(void* scr, const char* text, int font, int x, int y, int width, int align, int mouse, void* userDataOnPush,
	tfuiCallback onPush, void* userDataOnFocus, tfuiCallback onFocus, tfuiCallback onFocusLost);
extern int GfuiLeanButtonCreate(void* scr, const char* text, int font, int x, int y, int width, int align, int mouse, void* userDataOnPush,
	tfuiCallback onPush, void* userDataOnFocus, tfuiCallback onFocus, tfuiCallback onFocusLost);
extern int GfuiButtonStateCreate(void* scr, const char* text, int font, int x, int y, int width, int align, int mouse, void* userDataOnPush,
	tfuiCallback onPush, void* userDataOnFocus, tfuiCallback onFocus, tfuiCallback onFocusLost);
extern int
GfuiGrButtonCreate(void* scr, const char* disabled, const char* enabled, const char* focused, const char* pushed, int x, int y, int align,
	int mouse, void* userDataOnPush, tfuiCallback onPush, void* userDataOnFocus, tfuiCallback onFocus, tfuiCallback onFocusLost);

extern void GfuiButtonSetText(void* scr, int id, const char* text);
extern int GfuiButtonGetFocused();

/* Edit Box */
extern int
GfuiEditboxCreate(void* scr, const char* text, int font, int x, int y, int width, int maxlen, void* userDataOnFocus, tfuiCallback onFocus,
	tfuiCallback onFocusLost, int margin = 10);
extern int GfuiEditboxGetFocused();
extern char* GfuiEditboxGetString(void* scr, int id);
extern void GfuiEditboxSetString(void* scr, int id, const char* text);

/* Scrolling lists */
extern int GfuiScrollListCreate(void* scr, int font, int x, int y, int align, int width, int height, int scrollbar, void* userDataOnSelect,
	tfuiCallback onSelect);
extern int GfuiScrollListInsertElement(void* scr, int Id, char* element, int index, void* userData);
extern int GfuiScrollListMoveSelectedElement(void* scr, int Id, int delta);
extern char* GfuiScrollListExtractSelectedElement(void* scr, int Id, void** userData);
extern char* GfuiScrollListExtractElement(void* scr, int Id, int index, void** userData);
extern char* GfuiScrollListGetSelectedElement(void* scr, int Id, void** userData);
extern char* GfuiScrollListGetElement(void* scr, int Id, int index, void** userData);

/* scroll bars */
extern int
GfuiScrollBarCreate(void* scr, int x, int y, int align, int width, int orientation, int min, int max, int len, int start, void* userData,
	tfuiSBCallback onScroll);
extern void GfuiScrollBarPosSet(void* scr, int id, int min, int max, int len, int start);
extern int GfuiScrollBarPosGet(void* scr, int id);

/* Images */
extern int GfuiStaticImageCreate(void* scr, int x, int y, int w, int h, char* name);
extern void GfuiStaticImageSet(void* scr, int id, char* name);

/*****************************
 * Menu Management Interface *
 *****************************/

extern void* GfuiMenuScreenCreate(const char* title);
extern void GfuiMenuDefaultKeysAdd(void* scr);
extern int GfuiMenuButtonCreate(void* menu, const char* text, const char* tip, void* userdata, tfuiCallback onpush, int size = GFUI_FONT_LARGE);
extern int GfuiMenuBackQuitButtonCreate(void* menu, const char* text, const char* tip, void* userdata, tfuiCallback onpush);


/*********************
 * Control interface *
 *********************/

typedef enum
{
	GFCTRL_TYPE_NOT_AFFECTED = 0, GFCTRL_TYPE_JOY_AXIS = 1, GFCTRL_TYPE_JOY_BUT = 2, GFCTRL_TYPE_KEYBOARD = 3, GFCTRL_TYPE_MOUSE_BUT = 4,
	GFCTRL_TYPE_MOUSE_AXIS = 5, GFCTRL_TYPE_SKEYBOARD = 6
} GfCtrlType;

typedef struct
{
	int index;
	GfCtrlType type;
} tCtrlRef;


/** Mouse information structure */
typedef struct
{
	int edgeup[3]; /**< Button transition from down (pressed) to up */
	int edgedn[3]; /**< Button transition from up to down */
	int button[3]; /**< Button state (1 = up) */
	float ax[4];   /**< mouse axis position (mouse considered as a joystick) */
} tCtrlMouseInfo;

extern tCtrlMouseInfo* GfctrlMouseInit();
extern int GfctrlMouseGetCurrent(tCtrlMouseInfo* mouseInfo);
extern void GfctrlMouseRelease(tCtrlMouseInfo* mouseInfo);
extern void GfctrlMouseCenter();
extern void GfctrlMouseInitCenter();
extern void GfctrlGetRefByName(const char* name, tCtrlRef* ref);
extern const char* GfctrlGetNameByRef(GfCtrlType type, int index);
extern const char* GfctrlGetDefaultSection(GfCtrlType type);
extern bool GfctrlIsEventBlacklisted(void* parmHandle, const char* driversSection, const char* event);

extern int GfuiGlutExtensionSupported(const char* str);

#endif /* __TGFCLIENT__H__ */
