/***************************************************************************

    file        : racemanmenu.cpp
    created     : Fri Jan  3 22:24:41 CET 2003
    copyright   : (C) 2003-2014 by Eric Espie, Bernhard Wymann
    email       : eric.espie@torcs.org
    version     : $Id: racemanmenu.cpp,v 1.5.2.4 2014/02/04 14:01:39 berniw Exp $

 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file

    @author	<a href=mailto:eric.espie@torcs.org>Eric Espie</a>
    @version	$Id: racemanmenu.cpp,v 1.5.2.4 2014/02/04 14:01:39 berniw Exp $
*/

#include <stdlib.h>
#include <stdio.h>
#include <tgfclient.h>
#include <raceman.h>
#include <racescreens.h>
#include <driverconfig.h>
#include <portability.h>

#include "raceengine.h"
#include "racemain.h"
#include "raceinit.h"
#include "racestate.h"

#include "racemanmenu.h"
#include "driverconfig.h"
#include "graphconfig.h"

static float red[4] = {1.0, 0.0, 0.0, 1.0};

static void* racemanMenuHdle = NULL;
static void* newTrackMenuHdle = NULL;
static tRmTrackSelect ts;
static tRmDrvSelect ds;
static tRmRaceParam rp;
static tRmFileSelect fs;

static void reConfigRunState();

static void reConfigBack(void)
{
	void* params = ReInfo->params;

	/* Go back one step in the conf */
	GfParmSetNum(params, RM_SECT_CONF, RM_ATTR_CUR_CONF, NULL, GfParmGetNum(params, RM_SECT_CONF, RM_ATTR_CUR_CONF, NULL, 1)-2);

	reConfigRunState();
}


/***************************************************************/
/* Callback hooks used only to run the automaton on activation */
static void* configHookHandle = 0;

static void configHookActivate(void* /* dummy */)
{
	reConfigRunState();
}

static void* reConfigHookInit(void)
{
	if(configHookHandle) {
		return configHookHandle;
	}

	configHookHandle = GfuiHookCreate(0, configHookActivate);
	return configHookHandle;
}

/***************************************************************/
/* Config Back Hook */

static void* ConfigBackHookHandle = 0;

static void ConfigBackHookActivate(void* /* dummy */)
{
	reConfigBack();
}

static void* reConfigBackHookInit(void)
{
	if(ConfigBackHookHandle) {
		return ConfigBackHookHandle;
	}

	ConfigBackHookHandle = GfuiHookCreate(0, ConfigBackHookActivate);
	return ConfigBackHookHandle;
}

static void reConfigRunState(void)
{
	const int BUFSIZE = 1024;
	char path[BUFSIZE];

	auto params = ReInfo->params;
	auto curConf = (int)GfParmGetNum(params, RM_SECT_CONF, RM_ATTR_CUR_CONF, NULL, 1);
	if(curConf > GfParmGetEltNb(params, RM_SECT_CONF)) {
		GfOut("End of configuration\n");
		GfParmWriteFile(NULL, ReInfo->params, ReInfo->_reName);
		GfuiScreenActivate(racemanMenuHdle);
		return; /* Back to the race menu */
	}

	snprintf(path, BUFSIZE, "%s/%d", RM_SECT_CONF, curConf);
	auto conf = GfParmGetStr(params, path, RM_ATTR_TYPE, 0);
	if(!conf) {
		GfOut("no %s here %s\n", RM_ATTR_TYPE, path);
		GfuiScreenActivate(racemanMenuHdle);
		return; /* Back to the race menu */
	}

	LogInfo("reConfigRunState: conf = %s", conf); // TODO: delete later
	GfOut("Configuration step %s\n", conf);
	if(!strcmp(conf, RM_VAL_TRACKSEL)) { // curConf: 1
		/* Track Select Menu */
		ts.nextScreen = reConfigHookInit();
//		if(curConf == 1) {
		ts.prevScreen = racemanMenuHdle;
//		} else {
//			ts.prevScreen = reConfigBackHookInit();
//		}
		ts.param = ReInfo->params;
		ts.trackItf = ReInfo->_reTrackItf;
		RmTrackSelect(&ts);
	} else if(!strcmp(conf, RM_VAL_DRVSEL)) { // curConf: 2
		/* Drivers select menu */
		ds.nextScreen = reConfigHookInit();
//		if(curConf == 1) {
		ds.prevScreen = racemanMenuHdle;
//		} else {
//			ds.prevScreen = reConfigBackHookInit();
//		}
		ds.param = ReInfo->params;
		RmDriversSelect(&ds);

	} else if(!strcmp(conf, RM_VAL_RACECONF)) { // curConf: 3
		/* Race Options menu */
		rp.nextScreen = reConfigHookInit();
//		if(curConf == 1) {
		rp.prevScreen = racemanMenuHdle;
//		} else {
//			rp.prevScreen = reConfigBackHookInit();
//		}
		rp.param = ReInfo->params;
		rp.title = GfParmGetStr(params, path, RM_ATTR_RACE, "Race");
		rp.confMask = 0;
		snprintf(path, BUFSIZE, "%s/%d/%s", RM_SECT_CONF, curConf, RM_SECT_OPTIONS);
		auto numOpt = GfParmGetEltNb(params, path);
		for(int i = 1; i < numOpt+1; i++) { /* Select options to configure */
			snprintf(path, BUFSIZE, "%s/%d/%s/%d", RM_SECT_CONF, curConf, RM_SECT_OPTIONS, i);
			auto opt = GfParmGetStr(params, path, RM_ATTR_TYPE, "");
			if(!strcmp(opt, RM_VAL_CONFRACELEN)) { /* Configure race length */
				rp.confMask |= RM_CONF_RACE_LEN;
			} else if(!strcmp(opt, RM_VAL_CONFDISPMODE)) { /* Configure display mode */
				rp.confMask |= RM_CONF_DISP_MODE;
			}
		}
		RmRaceParamMenu(&rp);
	}

//	curConf++;
//	GfParmSetNum(params, RM_SECT_CONF, RM_ATTR_CUR_CONF, NULL, curConf); // TODO: delete later
	GfParmSetNum(params, RM_SECT_CONF, RM_ATTR_CUR_CONF, NULL, 4); // End configuration
}

static void reConfigureMenu(void* qConf)
{
	void* params = ReInfo->params;
//	GfParmSetNum(params, RM_SECT_CONF, RM_ATTR_CUR_CONF, NULL, 1);
	const auto iConf = reinterpret_cast<std::uintptr_t>(qConf);
	GfParmSetNum(params, RM_SECT_CONF, RM_ATTR_CUR_CONF, NULL, (tdble)iConf); // TODO: delete later
	reConfigRunState(); /* Reset configuration automaton */
}

static void reSelectLoadFile(char* filename)
{
	const int BUFSIZE = 1024;
	char buf[BUFSIZE];

	snprintf(buf, BUFSIZE, "results/%s/%s", ReInfo->_reFilename, filename);
	GfOut("Loading Saved File %s...\n", buf);
	ReInfo->results = GfParmReadFile(buf, GFPARM_RMODE_STD|GFPARM_RMODE_CREAT);
	ReInfo->_reRaceName = ReInfo->_reName;
	RmShowStandings(ReInfo->_reGameScreen, ReInfo);
}

// FIXME: remove this static shared buffer!
const int VARBUFSIZE = 1024;
char varbuf[VARBUFSIZE];

static void reLoadMenu(void* prevHandle)
{
	void* params = ReInfo->params;

	fs.prevScreen = prevHandle;
	fs.select = reSelectLoadFile;

	const char* str = GfParmGetStr(params, RM_SECT_HEADER, RM_ATTR_NAME, 0);
	if(str) {
		fs.title = str;
	}

	snprintf(varbuf, VARBUFSIZE, "results/%s", ReInfo->_reFilename);
	fs.path = varbuf;

	RmFileSelect((void*)&fs);
}

int ReRacemanMenu(void)
{
	if(racemanMenuHdle) {
		GfuiScreenRelease(racemanMenuHdle);
	}

	racemanMenuHdle = GfuiScreenCreateEx(NULL, NULL, (tfuiCallback)NULL, NULL, (tfuiCallback)NULL, 1);

	void* params = ReInfo->params;
	LogInfo("inside ReRacemanMenu: params = %p", params); // TODO: delete later
	const char* str = GfParmGetStr(params, RM_SECT_HEADER, RM_ATTR_BGIMG, 0);
	if(str) {
		GfuiScreenAddBgImg(racemanMenuHdle, str);
	}

	str = GfParmGetStr(params, RM_SECT_HEADER, RM_ATTR_NAME, 0);
	if(str) {
		GfuiTitleCreate(racemanMenuHdle, str, strlen(str));
	}

	GfuiMenuButtonCreate(racemanMenuHdle, "New Race", "Start a New Race", NULL, ReStartNewRace);
//	GfuiMenuButtonCreate(racemanMenuHdle, "Configure Race", "Configure The Race", NULL, reConfigureMenu); // TODO: delete later
	GfuiMenuButtonCreate(racemanMenuHdle, GFUI_TEXT_SELECT_CAR, "Change Player Vehicle", racemanMenuHdle, SetPlayerOptions);
	GfuiMenuButtonCreate(racemanMenuHdle, GFUI_TEXT_SELECT_TRACK, "Select Race Track", (void*)1, reConfigureMenu);
	GfuiMenuButtonCreate(racemanMenuHdle, GFUI_TEXT_SELECT_DRIVERS, "Select Race Drivers", (void*)2, reConfigureMenu);
	GfuiMenuButtonCreate(racemanMenuHdle, GFUI_TEXT_RACE_OPTIONS, "Change Race Options", (void*)3, reConfigureMenu);
	GfuiMenuButtonCreate(racemanMenuHdle, GFUI_TEXT_GRAPHIC_CONFIG, "Configure Graphic Parameters", racemanMenuHdle, SetGraphicOptions);

/*
	GfuiMenuButtonCreate(racemanMenuHdle, "Configure Players", "Players configuration menu", TorcsDriverMenuInit(racemanMenuHdle),
		GfuiScreenActivate);
*/

//	if(GfParmGetEltNb(params, RM_SECT_TRACKS) > 1) {
//		GfuiMenuButtonCreate(racemanMenuHdle, "Load", "Load a Previously Saved Game", racemanMenuHdle, reLoadMenu);
//	}

//	GfuiMenuBackQuitButtonCreate(racemanMenuHdle, "Back to Main", "Return to previous Menu", ReInfo->_reMenuScreen, GfuiScreenActivate);

	GfuiButtonCreate(racemanMenuHdle, GFUI_TAP_APPLY, GFUI_FONT_LARGE, 210, 60, 150, GFUI_ALIGN_HC_VB, GFUI_MOUSE_UP, NULL, NULL, NULL,
		(tfuiCallback)NULL, (tfuiCallback)NULL, true);
//	GfuiButtonCreate(racemanMenuHdle, GFUI_TAP_BACK, GFUI_FONT_LARGE, 430, 60, 150, GFUI_ALIGN_HC_VB, GFUI_MOUSE_UP, ReInfo->_reMenuScreen,
//		GfuiScreenActivate, NULL, (tfuiCallback)NULL, (tfuiCallback)NULL, true);
	GfuiButtonCreate(racemanMenuHdle, GFUI_TAP_BACK, GFUI_FONT_LARGE, 430, 60, 150, GFUI_ALIGN_HC_VB, GFUI_MOUSE_UP, ReInfo->_reMenuScreen,
		NULL, NULL, (tfuiCallback)NULL, (tfuiCallback)NULL, true); // TODO: delete later

	GfuiAddKey(racemanMenuHdle, BUTTON_Y, "Settings", 0, gfuiSelectPrev, NULL);
	GfuiAddKey(racemanMenuHdle, BUTTON_X, "Quit", 0, JNI_onBackPressed, NULL); // TODO: back to main menu (races)
	GfuiMenuDefaultKeysAdd(racemanMenuHdle);
	GfuiMenuArrowKeysAdd(racemanMenuHdle);
	GfuiScreenActivate(racemanMenuHdle);
	return RM_ASYNC|RM_NEXT_STEP;
}

static void reStateManage(void* /* dummy */)
{
	ReStateManage();
}

int ReNewTrackMenu(void)
{
	void* params = ReInfo->params;
	void* results = ReInfo->results;
	const int BUFSIZE = 1024;
	char buf[BUFSIZE];

	if(newTrackMenuHdle) {
		GfuiScreenRelease(newTrackMenuHdle);
	}

	newTrackMenuHdle = GfuiScreenCreateEx(NULL, NULL, (tfuiCallback)NULL, NULL, (tfuiCallback)NULL, 1);

	const char* str = GfParmGetStr(params, RM_SECT_HEADER, RM_ATTR_BGIMG, 0);
	if(str) {
		GfuiScreenAddBgImg(newTrackMenuHdle, str);
	}

	str = GfParmGetStr(params, RM_SECT_HEADER, RM_ATTR_NAME, "");
	GfuiTitleCreate(newTrackMenuHdle, str, strlen(str));

	GfuiMenuDefaultKeysAdd(newTrackMenuHdle);

	snprintf(buf, BUFSIZE, "Race Day #%d/%d on %s", (int)GfParmGetNum(results, RE_SECT_CURRENT, RE_ATTR_CUR_TRACK, NULL, 1),
		GfParmGetEltNb(params, RM_SECT_TRACKS), ReInfo->track->name);

	GfuiLabelCreateEx(newTrackMenuHdle, buf, red, GFUI_FONT_MEDIUM_C, 320, 420, GFUI_ALIGN_HC_VB, 50);

	GfuiMenuButtonCreate(newTrackMenuHdle, "Start Event", "Start The Current Race", NULL, reStateManage);
	GfuiMenuButtonCreate(newTrackMenuHdle, "Abandon", "Abandon The Race", ReInfo->_reMenuScreen, GfuiScreenActivate);
	GfuiAddKey(newTrackMenuHdle, BUTTON_X, "Abandon", ReInfo->_reMenuScreen, GfuiScreenActivate, NULL);

	GfuiScreenActivate(newTrackMenuHdle);
	return RM_ASYNC|RM_NEXT_STEP;
}
