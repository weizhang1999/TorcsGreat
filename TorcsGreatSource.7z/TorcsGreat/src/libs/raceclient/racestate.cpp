/***************************************************************************

    file        : racestate.cpp
    created     : Sat Nov 16 12:00:42 CET 2002
    copyright   : (C) 2002-2014 by Eric Espie, Bernhard Wymann
    email       : eric.espie@torcs.org
    version     : $Id: racestate.cpp,v 1.5.2.5 2014/02/04 14:03:03 berniw Exp $

 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file

    @author	<a href=mailto:eric.espie@torcs.org>Eric Espie</a>
    @version	$Id: racestate.cpp,v 1.5.2.5 2014/02/04 14:03:03 berniw Exp $
*/

/* The Race Engine State Automaton */

#include <stdlib.h>
#include <stdio.h>
#include <tgfclient.h>
#include <raceman.h>
#include <racescreens.h>

#include "racemain.h"
#include "raceinit.h"
#include "raceengine.h"
#include "racegl.h"
#include "raceresults.h"
#include "racemanmenu.h"

#include "racestate.h"
#include "android_jni.h"
//#include <android/sensor.h>

static void* mainMenu;
static map<int, int> g_aRacemanState;

//struct SensorEngine
//{
//	ASensorManager* pSensorManager = ASensorManager_getInstance(); // Get a reference to the sensor manager that is a singleton (deprecated)
//	const ASensor* pSensorRot = ASensorManager_getDefaultSensor(pSensorManager, ASENSOR_TYPE_ROTATION_VECTOR);
//	ASensorEventQueue* pQueueRot = nullptr;
//	SensorEngine()
//	{
//		ALooper* pSensorLooper = ALooper_prepare(ALOOPER_PREPARE_ALLOW_NON_CALLBACKS); // Prepare a looper associated with the calling thread
//		if(pSensorRot) pQueueRot = ASensorManager_createEventQueue(pSensorManager, pSensorLooper, 0, nullptr, nullptr);
//	}
//	~SensorEngine()
//	{
//		if(pQueueRot) ASensorManager_destroyEventQueue(pSensorManager, pQueueRot);
//	}
//};
//
//static SensorEngine g_Sensor;
//static float g_fTotalTime = 0;
//
//inline void ax_StartSensor(int kInst)
//{
//	g_fTotalTime = 0;
//}
//
//inline void ax_ResumeSensor(int iDelay)
//{
//	const int g_iSensorRate = ASensor_getMinDelay(g_Sensor.pSensorRot); // Get the minimum delay allowed between events in microseconds
//	ASensorEventQueue_enableSensor(g_Sensor.pQueueRot, g_Sensor.pSensorRot); // You can only set the event rate after enabling the sensor
//	ASensorEventQueue_setEventRate(g_Sensor.pQueueRot, g_Sensor.pSensorRot, g_iSensorRate); // Sets rate of events in microseconds
//}
//
//inline void ax_PauseSensor()
//{
//	ASensorEventQueue_disableSensor(g_Sensor.pQueueRot, g_Sensor.pSensorRot);
//}

/* State Automaton Init */
void ReStateInit(void* prevMenu)
{
	mainMenu = prevMenu;
}

/* State Automaton Management         */
/* Called when a race menu is entered */
void ReStateManage(void)
{
#ifdef DEBUG
	if(g_aRacemanState[ReInfo->_reState] < 2) {
		const auto qAttach = g_aRacemanState[ReInfo->_reState]++ < 1 ? "" : "...";
		LogError("inside ReStateManage: ReInfo->_reState = %d%s", ReInfo->_reState, qAttach); // TODO: delete later
	}
#endif

	int mode = RM_SYNC|RM_NEXT_STEP;

//	do { // TODO: delete later
	switch(ReInfo->_reState) {
		case RE_STATE_CONFIG:
			g_aRacemanState.clear(); // Reset state counter
			GfOut("RaceEngine: state = RE_STATE_CONFIG\n");
			/* Display the race specific menu */
			mode = ReRacemanMenu();
			if(mode&RM_NEXT_STEP) {
				ReInfo->_reState = RE_STATE_EVENT_INIT;
			}
			break;

		case RE_STATE_EVENT_INIT:
			GfOut("RaceEngine: state = RE_STATE_EVENT_INIT\n");
			/* Load the event description (track and drivers list) */
			mode = ReRaceEventInit();
			if(mode&RM_NEXT_STEP) {
				ReInfo->_reState = RE_STATE_PRE_RACE;
			}
			break;

		case RE_STATE_PRE_RACE:
			GfOut("RaceEngine: state = RE_STATE_PRE_RACE\n");
			mode = RePreRace();
			if(mode&RM_NEXT_STEP) {
				ReInfo->_reState = RE_STATE_RACE_START;
			}
			break;

		case RE_STATE_RACE_START:
			GfOut("RaceEngine: state = RE_STATE_RACE_START\n");
			mode = ReRaceStart();
			if(mode&RM_NEXT_STEP) {
				ReInfo->_reState = RE_STATE_INIT_CARS;
			}
			break;

		case RE_STATE_INIT_CARS:
			GfOut("RaceEngine: state = RE_STATE_REAL_START\n");
			mode = ReInitCars(); // Need to loop for all cars
			if(mode&RM_NEXT_STEP) {
				ReInfo->_reState = RE_STATE_REAL_START;
			}
			break;

		case RE_STATE_REAL_START:
			GfOut("RaceEngine: state = RE_STATE_REAL_START\n");
			mode = reRaceRealStart(); // Need to loop for all cars
			if(mode&RM_NEXT_STEP) {
				ReInfo->_reState = RE_STATE_RACE_READY;
			}
			break;

		case RE_STATE_RACE_READY:
			GfOut("RaceEngine: state = RE_STATE_REAL_START\n");
			mode = reRaceReady();
			if(mode&RM_NEXT_STEP) {
				ReInfo->_reState = RE_STATE_RACE;
			}
			break;

		case RE_STATE_RACE:
			mode = ReUpdate();
			if(ReInfo->s->_raceState == RM_RACE_ENDED) {
				/* race finished */
				ReInfo->_reState = RE_STATE_RACE_END;
			} else if(mode&RM_END_RACE) {
				/* interrupt by player */
				ReInfo->_reState = RE_STATE_RACE_STOP;
			}
			break;

		case RE_STATE_RACE_STOP:
			GfOut("RaceEngine: state = RE_STATE_RACE_STOP\n");
			/* Interrupted by player */
			mode = ReRaceStop();
			if(mode&RM_NEXT_STEP) {
				ReInfo->_reState = RE_STATE_RACE_END;
			}
			break;

		case RE_STATE_RACE_END:
			GfOut("RaceEngine: state = RE_STATE_RACE_END\n");
			mode = ReRaceEnd();
			if(mode&RM_NEXT_STEP) {
				ReInfo->_reState = RE_STATE_POST_RACE;
			} else if(mode&RM_NEXT_RACE) {
				ReInfo->_reState = RE_STATE_RACE_START;
			}
			break;

		case RE_STATE_POST_RACE:
			GfOut("RaceEngine: state = RE_STATE_POST_RACE\n");
			mode = RePostRace();
			if(mode&RM_NEXT_STEP) {
				ReInfo->_reState = RE_STATE_EVENT_SHUTDOWN;
			} else if(mode&RM_NEXT_RACE) {
				ReInfo->_reState = RE_STATE_PRE_RACE;
			}
			break;

		case RE_STATE_EVENT_SHUTDOWN:
			GfOut("RaceEngine: state = RE_STATE_EVENT_SHUTDOWN\n");
			mode = ReEventShutdown();
			if(mode&RM_NEXT_STEP) {
				ReInfo->_reState = RE_STATE_SHUTDOWN;
			} else if(mode&RM_NEXT_RACE) {
				ReInfo->_reState = RE_STATE_EVENT_INIT;
			}
			break;

		case RE_STATE_SHUTDOWN:
		case RE_STATE_ERROR:
			GfOut("RaceEngine: state = RE_STATE_SHUTDOWN\n");
			/* Back to race menu */
			ReInfo->_reState = RE_STATE_CONFIG;
			mode = RM_SYNC;
			break;

		case RE_STATE_EXIT:
			GfScrShutdown();
			JNI_systemExit(); /* brutal isn't it ? */
	}

//	} while((mode&(RM_SYNC|RM_QUIT)) == RM_SYNC); // TODO: delete later

	if(mode&RM_QUIT) {
		GfScrShutdown();
		JNI_systemExit(); /* brutal isn't it ? */
	}

	if(mode&RM_ACTIVGAMESCR) {
		LogInfo("inside ReStateManage: mode = 0x%08x, mode&RM_ACTIVGAMESCR = 0x%08x", mode, mode&RM_ACTIVGAMESCR); // TODO: delete later
		GfuiScreenActivate(ReInfo->_reGameScreen);
	}
}

/* Change and Execute a New State  */
void ReStateApply(void* vstate)
{
	long state = (long)vstate;
	ReInfo->_reState = (int)state;
	ReStateManage();
}
