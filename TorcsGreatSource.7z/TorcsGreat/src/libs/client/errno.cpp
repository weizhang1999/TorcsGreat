extern "C"
{
    int __mb_cur_max;
    //unsigned short* _pctype;
    int errno;
}
