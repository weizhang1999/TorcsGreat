/***************************************************************************
                          tgf.cpp -- The Gaming Framework
                             -------------------
    created              : Fri Aug 13 22:31:43 CEST 1999
    copyright            : (C) 1999-2014 by Eric Espie, Bernhard Wymann
    email                : torcs@free.fr
    version              : $Id: tgf.cpp,v 1.16.2.9 2014/05/23 09:32:05 berniw Exp $
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <portability.h>

#include <tgf.h>
#include <time.h>
#include "android_jni.h"


/** Convert a time in seconds (float) to an ascii string.
    @ingroup	screen
    @param	result	buffer for the formatted string
    @param	resultSize	size of the buffer
    @param	sec	Time to convert
    @param	sgn	Flag to indicate if the sign (+) is to be displayed for positive values of time.
    @return	Time string.
 */
void GfTime2Str(char *result, int resultSize, tdble sec, int sgn)
{
	const char* sign;

	if (sec < 0.0) {
		sec = -sec;
		sign = "-";
	} else {
		if (sgn) {
			sign = "+";
		} else {
			sign = "  ";
		}
	}

	int h = (int)(sec / 3600.0);
	sec -= 3600 * h;
	int m = (int)(sec / 60.0);
	sec -= 60 * m;
	int s = (int)(sec);
	sec -= s;
	int c = (int)floor((sec) * 100.0);

	if (h) {
		snprintf(result, resultSize, "%s%2.2d:%2.2d:%2.2d:%2.2d", sign, h, m, s, c);
	} else if (m) {
		snprintf(result, resultSize, "   %s%2.2d:%2.2d:%2.2d", sign, m, s, c);
	} else {
		snprintf(result, resultSize, "      %s%2.2d:%2.2d", sign, s, c);
	}
}


int GfNearestPow2 (int x)
{
	int r;

	if (!x) {
		return 0;
	}

	x++;
	r = 1;
	while ((1 << r) < x) {
		r++;
	}
	r--;

	return (1 << r);
}


/** @brief Create directory for given path recursively, so all missing parent directories are created as well
 *  @param[in] path Path
 *  @return #GF_DIR_CREATED if directory was created or already exits
 *  <br>#GF_DIR_CREATION_FAILED if directory could not be created
 */
int GfCreateDir(char *path)
{
	if (path == NULL) {
		return GF_DIR_CREATION_FAILED;
	}

	const int BUFSIZE = 1024;
	char buf[BUFSIZE];
	strncpy(buf, path, BUFSIZE);

#ifdef WIN32
#define mkdir(x) _mkdir(x)

	// Translate path.
	const char DELIM = '\\';
	int i;
	for (i = 0; i < BUFSIZE && buf[i] != '\0'; i++) {
		if (buf[i] == '/') {
			buf[i] = DELIM;
		}
	}

#else // WIN32
#define mkdir(x) mkdir((x), S_IRWXU);

	const char DELIM = '/';

#endif // WIN32

	int err = mkdir(buf);
	if (err == -1) {
		if (errno == ENOENT) {
			char *end = strrchr(buf, DELIM);
			*end = '\0';
			GfCreateDir(buf);
			*end = DELIM;
			err = mkdir(buf);

		}
	}

	if (err == -1 && errno != EEXIST) {
		return GF_DIR_CREATION_FAILED;
	} else {
		return GF_DIR_CREATED;
	}
}


/** @brief Create directory for given file path recursively, so all missing parent directories are created as well
 *  @param[in] filenameandpath Path including file name
 *  @return #GF_DIR_CREATED if directory was created or already exits
 *  <br>#GF_DIR_CREATION_FAILED if directory could not be created
 *  @see GfCreateDir
 */
int GfCreateDirForFile(const char *filenameandpath)
{
	if (filenameandpath == 0) {
		return GF_DIR_CREATION_FAILED;
	}

	const char* lastdelim = strrchr(filenameandpath, '/');
	if (lastdelim != NULL && lastdelim != filenameandpath) {
		const int BUFSIZE = 1024;
		char buf[BUFSIZE];
		const int size = MIN(lastdelim - filenameandpath, BUFSIZE - 1);
		snprintf(buf, BUFSIZE, "%s", filenameandpath);
		buf[size] = '\0';

		return GfCreateDir(buf);
	}

	return GF_DIR_CREATED;
}
