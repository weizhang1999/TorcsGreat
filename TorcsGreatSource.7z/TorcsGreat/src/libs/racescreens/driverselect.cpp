/***************************************************************************
                  driverselect.cpp -- drivers interactive selection
                             -------------------
    created              : Mon Aug 16 20:40:44 CEST 1999
    copyright            : (C) 1999-2017 by Eric Espie, Bernhard Wymann
    email                : torcs@free.fr
    version              : $Id: driverselect.cpp,v 1.5.2.7 2017/02/26 12:36:02 berniw Exp $
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file
    Driver selection screen.
    @author Bernhard Wymann, Eric Espie
    @version $Id: driverselect.cpp,v 1.5.2.7 2017/02/26 12:36:02 berniw Exp $
*/


#include <stdlib.h>
#include <stdio.h>
#include <sys/stat.h>
#include <tgfclient.h>
#include <track.h>
#include <car.h>
#include <raceman.h>
#include <robot.h>
#include <racescreens.h>
#include <portability.h>

static void* scrHandle;
static tRmDrvSelect* ds;
static int selectedScrollList, unselectedScrollList;
static int FocDrvLabelId;
static int PickDrvNameLabelId;
static int PickDrvCarLabelId;
static int PickDrvCategoryLabelId;
static float aColor[] = {1.0, 0.0, 0.0, 1.0};
static int nbSelectedDrivers;
static int nbMaxSelectedDrivers;
static tGfuiObject* activeScrollList;
static int iActionIds[4];
static int iActionIndex;

typedef struct DrvElt
{
	int index;
	char* dname;
	char* name;
	int sel;
	int human;
	void* car;
	GF_TAILQ_ENTRY(struct DrvElt) link;
} tDrvElt;

GF_TAILQ_HEAD(DrvListHead, tDrvElt);

tDrvListHead DrvList;

static void rmFreeDrvList();


static void rmdsActivate(void* /* notused */)
{
	/* call display function of graphic */
}


static void rmdsDeactivate(void* screen)
{
	rmFreeDrvList();
	GfuiScreenRelease(scrHandle);

	if(screen) {
		GfuiScreenActivate(screen);
	} else {
		pCurrentMenuHandle = nullptr;
	}
}


static void rmdsSetFocus(void* /* dummy */)
{
	tDrvElt* curDrv;
	auto name = GfuiScrollListGetSelectedElement(scrHandle, selectedScrollList, (void**)&curDrv);
	if(name) {
		GfParmSetStr(ds->param, RM_SECT_DRIVERS, RM_ATTR_FOCUSED, curDrv->dname);
		GfParmSetNum(ds->param, RM_SECT_DRIVERS, RM_ATTR_FOCUSEDIDX, (char*)NULL, curDrv->index);
		GfuiLabelSetText(scrHandle, FocDrvLabelId, curDrv->name);
	}
}


static void rmdsSelect(void* /* dummy */)
{
	tDrvElt* curDrv;
	const int BUFSIZE = 1024;
	char buf[BUFSIZE];

	snprintf(buf, BUFSIZE, "%s", RM_SECT_DRIVERS);
	GfParmListClean(ds->param, buf);
	auto name = GfuiScrollListExtractElement(scrHandle, selectedScrollList, 0, (void**)&curDrv);
	int index = 1;

	while(name != NULL) {
		snprintf(buf, BUFSIZE, "%s/%d", RM_SECT_DRIVERS, index);
		GfParmSetNum(ds->param, buf, RM_ATTR_IDX, (char*)NULL, curDrv->index);
		GfParmSetStr(ds->param, buf, RM_ATTR_MODULE, curDrv->dname);
		index++;
		name = GfuiScrollListExtractElement(scrHandle, selectedScrollList, 0, (void**)&curDrv);
	}

	rmdsDeactivate(ds->nextScreen);
}


static void rmMove(void* vd)
{
	GfuiScrollListMoveSelectedElement(scrHandle, selectedScrollList, (long)vd);
	GfuiScrollListMoveSelectedElement(scrHandle, unselectedScrollList, (long)vd);
}


static void rmdsClickOnDriver(void* /* dummy */)
{
	const int BUFSIZE = 1024;
	char buf[BUFSIZE];

	tDrvElt* curDrv;
	auto name = GfuiScrollListGetSelectedElement(scrHandle, selectedScrollList, (void**)&curDrv);
	if(!name) {
		name = GfuiScrollListGetSelectedElement(scrHandle, unselectedScrollList, (void**)&curDrv);
	}

	if(name) {
		GfuiLabelSetText(scrHandle, PickDrvNameLabelId, curDrv->name);
		/* search driver info */
		snprintf(buf, BUFSIZE, "drivers/%s/%s.xml", curDrv->dname, curDrv->dname);
		auto robhdle = GfParmReadFile(buf, GFPARM_RMODE_STD);

		if(!robhdle) {
			snprintf(buf, BUFSIZE, "drivers/%s/%s.xml", curDrv->dname, curDrv->dname);
			robhdle = GfParmReadFile(buf, GFPARM_RMODE_STD);
		}

		if(robhdle != NULL) {
			snprintf(buf, BUFSIZE, "%s/%s/%d", ROB_SECT_ROBOTS, ROB_LIST_INDEX, curDrv->index);
			GfuiLabelSetText(scrHandle, PickDrvCarLabelId, GfParmGetName(curDrv->car));
			GfuiLabelSetText(scrHandle, PickDrvCategoryLabelId, GfParmGetStr(curDrv->car, SECT_CAR, PRM_CATEGORY, ""));
			GfParmReleaseHandle(robhdle);
		}
	}
}

static void rmSelectDeselect(void* /* dummy */ )
{
	int sel = 0;
	char* name = 0;
	tDrvElt* curDrv = nullptr;
	if(nbSelectedDrivers < nbMaxSelectedDrivers) {
		int src = unselectedScrollList;
		name = GfuiScrollListExtractSelectedElement(scrHandle, src, (void**)&curDrv);
		if(name) {
			int dst = selectedScrollList;
			GfuiScrollListInsertElement(scrHandle, dst, name, 100, (void*)curDrv);
			nbSelectedDrivers++;
		}
	}

	if(!name) {
		sel = 1;
		int src = selectedScrollList;
		name = GfuiScrollListExtractSelectedElement(scrHandle, src, (void**)&curDrv);
		if(name) {
			int dst = unselectedScrollList;
			if(curDrv->human) {
				GfuiScrollListInsertElement(scrHandle, dst, name, 0, (void*)curDrv);
			} else {
				GfuiScrollListInsertElement(scrHandle, dst, name, 100, (void*)curDrv);
			}
			nbSelectedDrivers--;
		} else {
			return;
		}
	}

	if(auto cardllname = GfParmGetStr(ds->param, RM_SECT_DRIVERS, RM_ATTR_FOCUSED, ""); sel) {
		auto robotIdx = (int)GfParmGetNum(ds->param, RM_SECT_DRIVERS, RM_ATTR_FOCUSEDIDX, (char*)NULL, 0);
		if((curDrv->index == robotIdx) && (strcmp(curDrv->dname, cardllname) == 0)) {
			/* the focused element was deselected select a new one */
			name = GfuiScrollListGetElement(scrHandle, selectedScrollList, 0, (void**)&curDrv);
			if(name) {
				GfParmSetStr(ds->param, RM_SECT_DRIVERS, RM_ATTR_FOCUSED, curDrv->dname);
				GfParmSetNum(ds->param, RM_SECT_DRIVERS, RM_ATTR_FOCUSEDIDX, (char*)NULL, curDrv->index);
				GfuiLabelSetText(scrHandle, FocDrvLabelId, curDrv->name);
			} else {
				GfParmSetStr(ds->param, RM_SECT_DRIVERS, RM_ATTR_FOCUSED, "");
				GfParmSetNum(ds->param, RM_SECT_DRIVERS, RM_ATTR_FOCUSEDIDX, (char*)NULL, 0);
				GfuiLabelSetText(scrHandle, FocDrvLabelId, "");
			}
		}
	} else {
		if((strlen(cardllname) == 0) || (curDrv->human)) {
			GfParmSetStr(ds->param, RM_SECT_DRIVERS, RM_ATTR_FOCUSED, curDrv->dname);
			GfParmSetNum(ds->param, RM_SECT_DRIVERS, RM_ATTR_FOCUSEDIDX, (char*)NULL, curDrv->index);
			GfuiLabelSetText(scrHandle, FocDrvLabelId, curDrv->name);
		}
	}
	rmdsClickOnDriver(NULL);
}


void rmScrollListNextElt(void* /* dummy */)
{
	gfuiScrollListNextElt(activeScrollList);
}

void rmScrollListPrevElt(void* /* dummy */)
{
	gfuiScrollListPrevElt(activeScrollList);
}

void rmScrollListLeft(void* /* dummy */)
{
	activeScrollList->u.scrollist.selectedElt = -1;
	activeScrollList = gfuiGetObject(scrHandle, selectedScrollList);
	gfuiScrollListNextElt(activeScrollList);
	gfuiScrollListPrevElt(activeScrollList);
}

void rmScrollListRight(void* /* dummy */)
{
	activeScrollList->u.scrollist.selectedElt = -1;
	activeScrollList = gfuiGetObject(scrHandle, unselectedScrollList);
	gfuiScrollListNextElt(activeScrollList);
	gfuiScrollListPrevElt(activeScrollList);
}

void rmSelectAction(void* /* dummy */)
{
	if(scrHandle == NULL) {
		return;
	}
	gfuiGetObject(scrHandle, iActionIds[iActionIndex])->focus = 0;
	++iActionIndex %= 4;
	gfuiSelectId(scrHandle, iActionIds[iActionIndex]);
}

void rmPerformAction(void* /* dummy */)
{
	switch(iActionIndex) {
		case 0:
			rmMove((void*)-1);
			break;
		case 1:
			rmMove((void*)1);
			break;
		case 2:
			rmSelectDeselect(nullptr);
			break;
		case 3:
			rmdsSetFocus(nullptr);
			break;
		default:
			break;
	}
}

static void rmdsAddKeys(void)
{
	GfuiAddSKey(scrHandle, GLUT_KEY_UP, "Select Previous Entry", NULL, rmScrollListPrevElt, NULL);
	GfuiAddSKey(scrHandle, GLUT_KEY_DOWN, GFUI_TEXT_SELECT_NEXT, NULL, rmScrollListNextElt, NULL);
	GfuiAddSKey(scrHandle, GLUT_KEY_LEFT, "Previous Option in list", NULL, rmScrollListLeft, NULL);
	GfuiAddSKey(scrHandle, GLUT_KEY_RIGHT, "Next Option in list", NULL, rmScrollListRight, NULL);
	GfuiAddKey(scrHandle, BUTTON_B, GFUI_TEXT_SELECT_NEXT, NULL, rmSelectAction, NULL);
	GfuiAddKey(scrHandle, BUTTON_Y, "Perform Action", NULL, rmPerformAction, NULL);
	GfuiAddKey(scrHandle, BUTTON_A, "Accept Selection", NULL, rmdsSelect, NULL);
	GfuiAddKey(scrHandle, BUTTON_X, "Cancel Selection", ds->prevScreen, rmdsDeactivate, NULL);
}


/** @brief Drivers list selection, the race manager parameter set is handed over in vs, tRmDrvSelect.param
 *  @ingroup racemantools
 *  @param[in,out] vs Pointer on tRmDrvSelect structure (cast to void)
 *  @note The race manager parameter set is modified in memory but not persisted.
 */
void RmDriversSelect(void* vs)
{
	tDrvElt* curDrv;
	struct stat st;
	const int BUFSIZE = 1024;
	char buf[BUFSIZE];
	char path[BUFSIZE];
	char dname[BUFSIZE];

#define B_BASE  380
#define B_HT    30

	ds = (tRmDrvSelect*)vs;
	GF_TAILQ_INIT(&DrvList);

	scrHandle = GfuiScreenCreateEx((float*)NULL, NULL, rmdsActivate, NULL, (tfuiCallback)NULL, 1);
	GfuiScreenAddBgImg(scrHandle, "data/img/splash-qrdrv.png");

	GfuiTitleCreate(scrHandle, GFUI_TEXT_SELECT_DRIVERS, sizeof(GFUI_TEXT_SELECT_DRIVERS));
	GfuiLabelCreate(scrHandle, "Selected", GFUI_FONT_LARGE, 125, 400, GFUI_ALIGN_HC_VB, 0);
	GfuiLabelCreate(scrHandle, "Button B/Y:", GFUI_FONT_LARGE, 320, 400, GFUI_ALIGN_HC_VB, 0);
	GfuiLabelCreate(scrHandle, "Not Selected", GFUI_FONT_LARGE, 515, 400, GFUI_ALIGN_HC_VB, 0);

	selectedScrollList =
		GfuiScrollListCreate(scrHandle, GFUI_FONT_MEDIUM_C, 30, 80, GFUI_ALIGN_HL_VB, 200, 310, GFUI_SB_NONE, NULL, rmdsClickOnDriver);
	unselectedScrollList =
		GfuiScrollListCreate(scrHandle, GFUI_FONT_MEDIUM_C, 410, 80, GFUI_ALIGN_HL_VB, 200, 310, GFUI_SB_NONE, NULL, rmdsClickOnDriver);

	iActionIds[0] = GfuiMenuButtonCreate(scrHandle, "Move Up", "Move Driver Up", (void*)-1, rmMove, GFUI_FONT_MEDIUM);
	iActionIds[1] = GfuiMenuButtonCreate(scrHandle, "Move Down", "Move Driver Down", (void*)1, rmMove, GFUI_FONT_MEDIUM);
	iActionIds[2] = GfuiMenuButtonCreate(scrHandle, "(De)Select", "Select or Deselect Driver", (void*)0, rmSelectDeselect, GFUI_FONT_MEDIUM);
	iActionIds[3] = GfuiMenuButtonCreate(scrHandle, "Set Focus", "Set Driver On Focus", NULL, rmdsSetFocus, GFUI_FONT_MEDIUM);

	auto list = (tModList*)NULL;
//	snprintf(buf, BUFSIZE, "%sdrivers", GetLibDir());
	GfModInfoDir(CAR_IDENT, "drivers", 1, &list);
//	LogInfo("RmDriversSelect: list = %p", list); // TODO: delete later

	auto curmod = list;
	if(curmod != NULL) {
		do {
			curmod = curmod->next;
			for(int i = 0; i < MAX_MOD_ITF; i++) {
				if(curmod->modInfo[i].name) {
					auto sp = strrchr(curmod->sopath, '/');
					if(sp == NULL) {
						sp = curmod->sopath;
					} else {
						sp++;
					}
					strcpy(dname, sp+3); // Remove leading "lib"
					dname[strlen(dname)-strlen(DLLEXT)-1] = 0; /* cut .so or .dll */
					snprintf(buf, BUFSIZE, "drivers/%s/%s.xml", dname, dname);
					auto robhdle = GfParmReadFile(buf, GFPARM_RMODE_STD);
					if(!robhdle) {
						snprintf(buf, BUFSIZE, "drivers/%s/%s.xml", dname, dname);
						robhdle = GfParmReadFile(buf, GFPARM_RMODE_STD);
					}
					snprintf(path, BUFSIZE, "%s/%s/%d", ROB_SECT_ROBOTS, ROB_LIST_INDEX, curmod->modInfo[i].index);
					const char* carName = GfParmGetStr(robhdle, path, ROB_ATTR_CAR, "");
					const int human = strcmp(GfParmGetStr(robhdle, path, ROB_ATTR_TYPE, ROB_VAL_ROBOT), ROB_VAL_ROBOT) ? 1 : 0;
					snprintf(path, BUFSIZE, "%scars/%s/%s.xml", UTIL_BasePath(), carName, carName);
//					LogInfo("RmDriversSelect: name = %s path = %s", curmod->modInfo[i].name, path); // TODO: delete later
					if(!stat(path, &st)) {
						auto carhdle = GfParmReadFile(path, GFPARM_RMODE_STD);
						if(carhdle) {
							curDrv = (tDrvElt*)calloc(1, sizeof(tDrvElt));
							curDrv->index = curmod->modInfo[i].index;
							curDrv->dname = strdup(dname);
							curDrv->name = strdup(curmod->modInfo[i].name);
							curDrv->car = carhdle;
							if(human) {
								curDrv->human = 1;
								GF_TAILQ_INSERT_HEAD(&DrvList, curDrv, link);
							} else {
								curDrv->human = 0;
								GF_TAILQ_INSERT_TAIL(&DrvList, curDrv, link);
							}
						} else {
							LogError("Driver %s not selected because car %s is not readable", curmod->modInfo[i].name, carName);
							GfOut("Driver %s not selected because car %s is not readable\n", curmod->modInfo[i].name, carName);
						}
					} else {
						LogError("Driver %s not selected because car %s is not present", curmod->modInfo[i].name, carName);
						GfOut("Driver %s not selected because car %s is not present\n", curmod->modInfo[i].name, carName);
					}
					GfParmReleaseHandle(robhdle);
				}
			}
		} while(curmod != list);

		GfModFreeInfoList(&list);
	}

	nbSelectedDrivers = 0;
	nbMaxSelectedDrivers = (int)GfParmGetNum(ds->param, RM_SECT_DRIVERS, RM_ATTR_MAXNUM, NULL, 0);
//	LogInfo("RmDriversSelect: nbSelectedDrivers = %d nbMaxSelectedDrivers = %d", nbSelectedDrivers, nbMaxSelectedDrivers); // TODO: delete later
	const auto nCars = GfParmGetEltNb(ds->param, RM_SECT_DRIVERS);
//	LogInfo("RmDriversSelect: nCars = %d nbMaxSelectedDrivers = %d", nCars, nbMaxSelectedDrivers); // TODO: delete later
	int index = 1;
	for(int i = 1; i < nCars+1; i++) {
		snprintf(dname, BUFSIZE, "%s/%d", RM_SECT_DRIVERS, i);
		const auto cardllname = GfParmGetStr(ds->param, dname, RM_ATTR_MODULE, "");
		const auto robotIdx = (int)GfParmGetNum(ds->param, dname, RM_ATTR_IDX, (char*)NULL, tModInfo::INVALID_INDEX);
		const auto robotName = GfParmGetStr(ds->param, dname, RM_ATTR_DRVNAME, "");

		curDrv = GF_TAILQ_FIRST(&DrvList);
//		LogInfo("RmDriversSelect: i = %d curDrv = %p", i, curDrv); // TODO: delete later
		if(curDrv != NULL) {
			do {
//				LogInfo("RmDriversSelect: curDrv->name = %s robotName = %s", curDrv->name, robotName); // TODO: delete later
//				LogError("RmDriversSelect: curDrv->dname = %s cardllname = %s", curDrv->dname, cardllname); // TODO: delete later
				if((curDrv->index == robotIdx || strcmp(curDrv->name, robotName) == 0) && (strcmp(curDrv->dname, cardllname) == 0)) {
					if(nbSelectedDrivers < nbMaxSelectedDrivers) {
						GfuiScrollListInsertElement(scrHandle, selectedScrollList, curDrv->name, index, (void*)curDrv);
						curDrv->sel = index++;
						nbSelectedDrivers++;
					}
					break;
				}
			} while((curDrv = GF_TAILQ_NEXT(curDrv, link)) != NULL);
		}
	}

	curDrv = GF_TAILQ_FIRST(&DrvList);
	if(curDrv != NULL) {
		do {
			if(curDrv->sel == 0) {
				GfuiScrollListInsertElement(scrHandle, unselectedScrollList, curDrv->name, 1000, (void*)curDrv);
			}
		} while((curDrv = GF_TAILQ_NEXT(curDrv, link)) != NULL);
	}

	GfuiLabelCreate(scrHandle, "Focused:", GFUI_FONT_MEDIUM, 320, B_BASE-5*B_HT, GFUI_ALIGN_HC_VB, 0);
	const auto cardllname = GfParmGetStr(ds->param, RM_SECT_DRIVERS, RM_ATTR_FOCUSED, "");
	const auto robotIdx = (int)GfParmGetNum(ds->param, RM_SECT_DRIVERS, RM_ATTR_FOCUSEDIDX, (char*)NULL, 0);
	curDrv = GF_TAILQ_FIRST(&DrvList);
	if(curDrv != NULL) {
		do {
			if((curDrv->index == robotIdx) && (strcmp(curDrv->dname, cardllname) == 0)) {
				break;
			}
		} while((curDrv = GF_TAILQ_NEXT(curDrv, link)) != NULL);
	}

	if(curDrv == NULL) {
		curDrv = GF_TAILQ_FIRST(&DrvList);
	}

	const auto iHeight = GfuiFontHeight(GFUI_FONT_MEDIUM);
	if(curDrv == NULL) {
		FocDrvLabelId = GfuiLabelCreate(scrHandle, "", GFUI_FONT_MEDIUM_C, 320, B_BASE-5*B_HT-iHeight, GFUI_ALIGN_HC_VB, 256);
	} else {
		FocDrvLabelId = GfuiLabelCreate(scrHandle, curDrv->name, GFUI_FONT_MEDIUM_C, 320, B_BASE-5*B_HT-iHeight, GFUI_ALIGN_HC_VB, 256);
	}

	/* Picked Driver Info */
	GfuiLabelCreate(scrHandle, "Driver:", GFUI_FONT_MEDIUM, 320, B_BASE-7*B_HT, GFUI_ALIGN_HC_VB, 0);
	PickDrvNameLabelId = GfuiLabelCreateEx(scrHandle, "", aColor, GFUI_FONT_MEDIUM_C, 320, B_BASE-7*B_HT-iHeight, GFUI_ALIGN_HC_VB, 256);
	GfuiLabelCreate(scrHandle, "Car:", GFUI_FONT_MEDIUM, 320, B_BASE-8*B_HT, GFUI_ALIGN_HC_VB, 0);
	PickDrvCarLabelId = GfuiLabelCreateEx(scrHandle, "", aColor, GFUI_FONT_MEDIUM_C, 320, B_BASE-8*B_HT-iHeight, GFUI_ALIGN_HC_VB, 256);
	GfuiLabelCreate(scrHandle, "Category:", GFUI_FONT_MEDIUM, 320, B_BASE-9*B_HT, GFUI_ALIGN_HC_VB, 0);
	PickDrvCategoryLabelId = GfuiLabelCreateEx(scrHandle, "", aColor, GFUI_FONT_MEDIUM_C, 320, B_BASE-9*B_HT-iHeight, GFUI_ALIGN_HC_VB, 256);

	GfuiButtonCreate(scrHandle, GFUI_TAP_ACCEPT, GFUI_FONT_LARGE, 210, 60, 150, GFUI_ALIGN_HC_VB, GFUI_MOUSE_UP, NULL, rmdsSelect, NULL,
		(tfuiCallback)NULL, (tfuiCallback)NULL);
	GfuiButtonCreate(scrHandle, GFUI_TAP_CANCEL, GFUI_FONT_LARGE, 430, 60, 150, GFUI_ALIGN_HC_VB, GFUI_MOUSE_UP, ds->prevScreen,
		rmdsDeactivate, NULL, (tfuiCallback)NULL, (tfuiCallback)NULL);

	rmdsAddKeys();
	activeScrollList = gfuiGetObject(scrHandle, unselectedScrollList);
	gfuiScrollListNextElt(activeScrollList);
	GfuiScreenActivate(scrHandle);
	iActionIndex = 1;
	rmSelectAction(nullptr); // Tip display clear screen hack (call this function here)
}


static void rmFreeDrvList(void)
{
	tDrvElt* cur;

	while((cur = GF_TAILQ_FIRST(&DrvList)) != NULL) {
		GF_TAILQ_REMOVE(&DrvList, cur, link);
		free(cur->name);
		free(cur->dname);
		GfParmReleaseHandle(cur->car);
		free(cur);
	}
}
