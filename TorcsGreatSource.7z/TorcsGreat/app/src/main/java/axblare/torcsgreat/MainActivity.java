/////////////////////////////////////////////////////////////////////////////
//                                                                         //
//   Torcs Great is an Android port of the famous open source game TORCS   //
//   Copyright (c) 2019-2020, Wei Zhang <mailto:weizhang1999@gmail.com>.   //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
//
// See the original TORCS game at <https://sourceforge.net/projects/torcs/>.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

package axblare.torcsgreat;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.graphics.Point;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StatFs;
import android.os.SystemClock;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;
import java.util.Random;

import androidx.annotation.Keep;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import static axblare.torcsgreat.AppSettings.*;

public class MainActivity extends AppCompatActivity {
	private static final String mLogTag = "LogTag"; // String id for logcat
	private static final int iDebugLevel = 1; // Debug level (larger for more)
	private static int iCurrentMusic = 0; // Current music index (0 or 1)
	private static TextToSpeech mTextToSpeech; // Text to speech engine
	private static MediaPlayer mMediaPlayer; // Android media player
	private static Random mRandom = new Random(); // Random number
	private static Handler mHandler; // Handler for runnable loop
	private static Point mSize = new Point(); // Display size
	private TextView mTextInfo; // Text info view reference
	private TextView[] mTextView = new TextView[8]; // Buttons

	static boolean bSmallScreen; // Phone has small screen size
	private AdsFan mAdsFan; // Facebook Audience Network
	private AdsMob mAdsMob; // Google AdMob Network

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		if(iDebugLevel > 0) Log.d(mLogTag, "onCreate: savedInstanceState = "+savedInstanceState);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

		WindowManager mWindowManager = (WindowManager)getSystemService(Context.WINDOW_SERVICE);
		Objects.requireNonNull(mWindowManager).getDefaultDisplay().getSize(mSize);
		if(mSize.x < mSize.y) return; // Landscape mode only

		try {
			if(iDebugLevel > 0) Log.i(mLogTag, "Creating game paths");
			setGameDirs(getApplicationContext()); // Make app paths available for checking file existence
			ApplicationInfo info = getPackageManager().getApplicationInfo(BuildConfig.APPLICATION_ID, PackageManager.GET_SHARED_LIBRARY_FILES);
			setAppPath(mAppDir, info.nativeLibraryDir+"/");
		} catch(PackageManager.NameNotFoundException e) {
			e.printStackTrace();
		}

		int iSampleRate = 44100; // Audio sample rate (default 44100)
		int iBufferSize = 1024; // Audio buffer size (default 1024)
		final AudioManager mAudioManager = (AudioManager)getSystemService(Context.AUDIO_SERVICE); // Get the native audio system
		if(mAudioManager != null) {
			iSampleRate = Integer.valueOf(mAudioManager.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE));
			iBufferSize = Integer.valueOf(mAudioManager.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER));
		}
		InitSound(iSampleRate, iBufferSize);
		mTextToSpeech = new TextToSpeech(this, status->{
			if(status != TextToSpeech.ERROR) mTextToSpeech.setLanguage(Locale.US);
		});
		startTextSpeech(" ", TextToSpeech.QUEUE_FLUSH); // Run it once to make later call faster

		MyRenderer.mAssetManager = getAssets();
		mSurfView = findViewById(R.id.surf_view); // Get the views defined in layout
		mSurfView.setEGLContextClientVersion(2); // Support OpenGL ES 2.0 device or later
		mSurfView.setEGLConfigChooser(8, 8, 8, 8, 16, 8); // Pick 16-bit depth with stencil
		mSurfView.setRenderer(new MyRenderer()); // This method must be called before setRenderMode
		mSurfView.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY); // The renderer is called continuously

		mTextInfo = findViewById(R.id.text_info);
		mTextView[0] = findViewById(R.id.button_up);
		mTextView[1] = findViewById(R.id.button_down);
		mTextView[2] = findViewById(R.id.button_left);
		mTextView[3] = findViewById(R.id.button_right);
		mTextView[4] = findViewById(R.id.button_b);
		mTextView[5] = findViewById(R.id.button_a);
		mTextView[6] = findViewById(R.id.button_y);
		mTextView[7] = findViewById(R.id.button_x);
		loadPersistData(this); // Load saved settings
		updateViewLayout(true); // Resize view layouts
		if(!isUnzipped()) showAppSettings(); // Show settings dialog // TODO: uncomment later

		bSmallScreen = getResources().getBoolean(R.bool.small_screen);
		mAdsFan = new AdsFan(this);
		mAdsMob = new AdsMob(this);
		mAdsMob.showAdView(mAdsFan.showAdView(false)); // Show banner ad

		mHandler = new Handler();
		mSurfView.post(new Runnable() {
			@Override
			public void run() {
				mHandler.postDelayed(new Runnable() {
					@Override
					public void run() {
						if(isTrue(bRunning)) { // No more looping
							if(iDebugLevel > 0) Log.e(mLogTag, "Stopping handler runnable");
							return;
						}
						mHandler.postDelayed(this, 100); // Loop with time delay 100 ms
						if(bDialogBox) return; // Do nothing if dialog window is open
						if(isUnzipped()) { // All good to go
							if(mSurfView.getWidth() > 0 && mSurfView.getHeight() > 0) { // Avoid crash
								if(!isTrue(bRunning)) {
									setTrue(bRunning);
									resetGameViews();
									if(iDebugLevel > 0) Log.e(mLogTag, "Running game thread");
									startCarRacing();
								}
							}
						} else { // Need game data
							String mInfo; // Information string for current operation
							if(isDownloaded()) { // Need to unzip
								if(!isTrue(bUnzipping)) {
									setTrue(bUnzipping);
									Intent intent = new Intent(getApplicationContext(), AppSettings.class);
									enqueueWork(getApplicationContext(), AppSettings.class, 1, intent);
								}
								mInfo = mErrMsg != null ? mErrMsg : getString(R.string.text_unzipping)+unzippedPercent()+"%";
							} else { // Need to download
								if(!isTrue(bFetching)) { // Need to download
									StatFs mStatFs = new StatFs(Environment.getExternalStorageDirectory().getAbsolutePath());
									final long lStorage = mStatFs.getAvailableBytes()/1048576;
									if(lStorage < 287) { // Check for free storage space
										mInfo = getString(R.string.text_storage)+lStorage+" MB.";
										runOnUiThread(()->mTextInfo.setText(mInfo));
										return;
									}
									setTrue(bFetching);
									runOnUiThread(()->{
										startDownload(0);
										startDownload(1);
										startDownload(2);
										startDownload(3);
									});
								}
								mInfo = mErrMsg != null ? mErrMsg : getString(R.string.text_downloading)+downloadedPercent()+"%";
								requireInternetConnection();
							}
							runOnUiThread(()->mTextInfo.setText(isFlashTime() ? mInfo : getString(R.string.please_wait)));
						}
					}
				}, 0);
			}
		});
	}

	@Override
	protected void onResume() {
		if(iDebugLevel > 0) Log.d(mLogTag, "onResume: mMediaPlayer = "+mMediaPlayer);
		super.onResume();
		if(mMediaPlayer != null && bMusicEffect && iCurrentMusic == 0) {
			mMediaPlayer.start();
		}
	}

	@Override
	protected void onPause() {
		if(iDebugLevel > 0) Log.e(mLogTag, "onPause: isFinishing() = "+isFinishing());
		if(mMediaPlayer != null && !isFinishing()) {
			mMediaPlayer.pause();
		}
		super.onPause();
	}

	@Override
	protected void onDestroy() {
		if(iDebugLevel > 0) Log.e(mLogTag, "onDestroy");
		if(isFinishing()) cancelDownload();
		mHandler.removeCallbacksAndMessages(null);
		StopTextSpeech(); // Stop the text to speech engine
		if(mTextToSpeech != null) mTextToSpeech.shutdown(); // Shut down the text to speech engine
		ReleaseMediaPlayer(); // Release media player
		setRenderPaused(true);
		mAdsFan.destroyAll();
		mAdsMob.destroyAll();
		super.onDestroy();
	}

	@Keep
	@Override
	public void onBackPressed() {
		runOnUiThread(()->{
			if(iDebugLevel > 0) Log.e(mLogTag, "onBackPressed");
			final AlertDialog.Builder mBuilder = new AlertDialog.Builder(this);
			mBuilder.setIcon(R.drawable.ic_dialog_alert).setTitle(R.string.dialog_exit);
			mBuilder.setMessage(getString(R.string.text_exit));
			mBuilder.setNeutralButton(R.string.button_no, (dialog, id)->dialog.cancel());
			mBuilder.setPositiveButton(R.string.button_yes, (dialogInterface, i)->{
				cancelDownload();
				System.exit(0);
			});
			final AlertDialog mAlert = mBuilder.create();
			mAlert.show();
		});
	}

	private boolean isFlashTime() {
		return (SystemClock.elapsedRealtime()&0x400) != 0;
	}

	private void requireInternetConnection() {
		ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo netInfo = cm != null ? cm.getActiveNetworkInfo() : null;
		if(netInfo != null && netInfo.isConnectedOrConnecting()) return;
		final long lStartTime = SystemClock.elapsedRealtime()%5550;
		if(lStartTime > 5530) showToastString(getString(R.string.no_internet), -1);
	}

	void awardCredit(int iCoins) {
		if(isTrue(bRunning)) setRenderPaused(false);
		if(iCoins <= 0 || !isTrue(bRunning)) return;
		iCoins *= 1+mRandom.nextInt(4); // Scale factor range [1, 4]
		if(iDebugLevel > 0) Log.i(mLogTag, "awardCredit: iCoins = "+iCoins);
		final String mThanks = getString(R.string.thank_you)+iCoins+getString(R.string.unit_period);
		showToastString(mThanks, 1);
		lPlayerCoins += iCoins;
		savePersistData(this);
	}

	@Keep
	private void showToastString(String text, int iSpeak) {
		runOnUiThread(()->{
			if(iSpeak >= 0) startTextSpeech(text, iSpeak);
			Toast toast = Toast.makeText(getApplicationContext(), text, Toast.LENGTH_LONG);
			ViewGroup group = (ViewGroup)toast.getView();
			TextView messageTextView = (TextView)group.getChildAt(0);
			messageTextView.setTextSize(Math.min(mSize.x, mSize.y)/32);
			toast.setGravity(Gravity.CENTER, 0, iOffset);
			toast.show();
		});
	}

	@Keep
	@SuppressLint("InflateParams")
	void showAppSettings() {
		runOnUiThread(()->{
			bDialogBox = true;
			AlertDialog.Builder mBuilder = new AlertDialog.Builder(this, R.style.SettingsDialog);
			mBuilder.setView(getLayoutInflater().inflate(R.layout.settings_app, null));
			if(!isUnzipped()) {
				mBuilder.setNeutralButton(R.string.end_game, (dialog, id)->System.exit(0));
			} else {
				mBuilder.setNeutralButton(R.string.watch_video, (dialog, id)->showPopupAd(0, 0, false));
			}
			mBuilder.setPositiveButton(R.string.continue_game, (dialog, id)->{
				if(mMediaPlayer != null) {
					if(bMusicEffect && iCurrentMusic >= 0) {
						mMediaPlayer.start();
					} else {
						mMediaPlayer.pause();
					}
				}
				savePersistData(this);
				bDialogBox = false;
				dialog.dismiss();
				continueRacing();
			});
			final AlertDialog mAlert = mBuilder.create();
			mAlert.setCanceledOnTouchOutside(false);
			mAlert.setCancelable(false);
			mAlert.show();

			final SimpleDateFormat mFormat = new SimpleDateFormat(" yyyy-MM-dd HH:mm", Locale.US);
			String mAbout = getString(R.string.app_name)+" "+BuildConfig.VERSION_NAME+mFormat.format(new Date(BuildConfig.TIMESTAMP));
			TextView mDateInfo = mAlert.findViewById(R.id.game_settings);
			Objects.requireNonNull(mDateInfo).setText(mAbout);
			TextView mTextLevel = mAlert.findViewById(R.id.value_races);
			Objects.requireNonNull(mTextLevel).setText(NumberFormat.getIntegerInstance().format(iPlayerRaces));
			TextView mTextKilos = mAlert.findViewById(R.id.value_kilos);
			Objects.requireNonNull(mTextKilos).setText(NumberFormat.getIntegerInstance().format(fPlayerKilos));
			TextView mTextFight = mAlert.findViewById(R.id.value_coins);
			Objects.requireNonNull(mTextFight).setText(NumberFormat.getIntegerInstance().format(lPlayerCoins));
			CheckBox mCheckSound = mAlert.findViewById(R.id.check_sound);
			Objects.requireNonNull(mCheckSound).setChecked(bSoundEffect);
			mCheckSound.setOnClickListener(view->bSoundEffect = mCheckSound.isChecked());
			CheckBox mCheckMusic = mAlert.findViewById(R.id.check_music);
			Objects.requireNonNull(mCheckMusic).setChecked(bMusicEffect);
			mCheckMusic.setOnClickListener(view->bMusicEffect = mCheckMusic.isChecked());
			CheckBox mCheckVoice = mAlert.findViewById(R.id.check_voice);
			Objects.requireNonNull(mCheckVoice).setChecked(bVoiceEffect);
			mCheckVoice.setOnClickListener(view->bVoiceEffect = mCheckVoice.isChecked());
			TextView mPrivacyPolicy = mAlert.findViewById(R.id.privacy_policy);
			Objects.requireNonNull(mPrivacyPolicy).setOnClickListener(v->{
				final String mPrivacyLink = "https://sites.google.com/view/axblare/torcs-great";
				startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(mPrivacyLink)));
			});
			TextView mAssets = mAlert.findViewById(R.id.text_assets);
			Objects.requireNonNull(mAssets).setEnabled(!isUnzipped());
		});
	}

	private static final int BUTTON_U = 0x01;
	private static final int BUTTON_D = 0x02;
	private static final int BUTTON_L = 0x04;
	private static final int BUTTON_R = 0x08;
	private static final int BUTTON_B = 0x10;
	private static final int BUTTON_A = 0x20;
	private static final int BUTTON_Y = 0x40;
	private static final int BUTTON_X = 0x80;
	private static final int[] iKeys = {BUTTON_U, BUTTON_D, BUTTON_L, BUTTON_R, BUTTON_B, BUTTON_A, BUTTON_Y, BUTTON_X};

	private GLSurfaceView mSurfView;
	private static int iOffset = 0;
	private static final float fAspectRatio = 0.625f; // Display aspect ratio (height to width)

	@SuppressLint("ClickableViewAccessibility")
	void updateViewLayout(final boolean bListener) {
		final int iAdView = (int)(getResources().getDimension(R.dimen.ad_margin)+getResources().getDimension(R.dimen.ad_height)+0.5f);
		final int iMargin = (int)(getResources().getDimension(R.dimen.small_margin)+0.5f);
		int iWidth, iHeight;
		iHeight = mSize.y-iAdView-iMargin;
		iHeight = (iHeight-iMargin*3)/4;
		iHeight = iHeight*4+iMargin*3;
		iWidth = (int)(iHeight/fAspectRatio+0.5f);
		mSurfView.getLayoutParams().width = iWidth;
		mSurfView.getLayoutParams().height = iHeight;
		mTextInfo.getLayoutParams().width = iWidth;
		mTextInfo.getLayoutParams().height = iHeight;
		iWidth = (mSize.x-iWidth)/2-iMargin;
		iHeight = (iHeight-iMargin*3)/4;
		iOffset = (mSurfView.getTop()+mSurfView.getHeight()-mSize.y)/2;
		final int iPadding = -(int)(getResources().getDimension(R.dimen.arrow_text)+0.5f)/4;
		for(int i = 0; i < 8; i++) {
			mTextView[i].setWidth(iWidth);
			mTextView[i].setHeight(iHeight);
			mTextView[i].setPadding(0, i < 4 ? iPadding : iPadding/3, 0, 0);
			if(bListener) {
				final int iButton = i;
				mTextView[i].setOnTouchListener((v, event)->{
					if(event.getAction() == MotionEvent.ACTION_DOWN) {
						setTouchAction(iKeys[iButton], 1);
					} else if(event.getAction() == MotionEvent.ACTION_UP) {
						setTouchAction(iKeys[iButton], 0);
					}
					return true;
				});
			}
		}
	}

	private void resetGameViews() {
		runOnUiThread(()->{
			updateViewLayout(false); // Update view layouts
			mTextInfo.setVisibility(View.GONE);
			int[] location = new int[2];
			mSurfView.getLocationOnScreen(location);
			final int x = location[0];
			final int y = location[1];
			final int w = mSurfView.getWidth();
			final int h = mSurfView.getHeight();
			if(iDebugLevel > 0) Log.i(mLogTag, "Display: "+mSize.x+"x"+mSize.y+" Viewport: x="+x+" y="+y+" w="+w+" h="+h);
			setRenderPaused(false); // Start drawing frames
		});
	}

	static void setRenderPaused(final boolean bPause) {
		MyRenderer.bStartRenderer = !bPause;
	}

	@Keep
	private static void startTextSpeech(String text, int queue) {
		if(!bVoiceEffect || mTextToSpeech == null) return; // Text speech option is turned off
		mTextToSpeech.speak(text, queue, null, null);
	}

	private static void StopTextSpeech() {
		if(mTextToSpeech != null && mTextToSpeech.isSpeaking()) mTextToSpeech.stop();
	}

	private void StartMediaPlayer(final int iMidi) {
		if(IsMediaPlaying()) return;
		if(mMediaPlayer == null) {
			mMediaPlayer = new MediaPlayer();
		}
		mMediaPlayer.reset();
		try {
			AssetFileDescriptor afd = getResources().openRawResourceFd(iMidi == 0 ? R.raw.torcs0 : R.raw.torcs1);
			if(afd == null) return;
			mMediaPlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
			afd.close();
			mMediaPlayer.prepare();
		} catch(IOException e) {
			Log.e(mLogTag, "not available for playing, check");
		}
		mMediaPlayer.setLooping(iMidi == 1);
		if(mMediaPlayer != null) {
			iCurrentMusic = iMidi;
			mMediaPlayer.start(); // Play the file (it takes some time to start)
		}
	}

	public static boolean IsMediaPlaying() {
		return mMediaPlayer != null && mMediaPlayer.isPlaying();
	}

	public static void StopMediaPlayer() {
		if(IsMediaPlaying()) mMediaPlayer.stop();
		iCurrentMusic = 0;
	}

	public static void ReleaseMediaPlayer() {
		if(mMediaPlayer == null) return; // Media player is not available
		StopMediaPlayer();
		mMediaPlayer.release();
		mMediaPlayer = null;
	}

	@Keep
	public void playMusicFile(final int iMidi) {
		if(!bMusicEffect || iMidi == iCurrentMusic && IsMediaPlaying()) return;
		if(iMidi < 0) {
			StopMediaPlayer(); // Stop current music
		} else {
			StartMediaPlayer(iMidi); // Play ending music
		}
	}

	@Keep
	public void renderScreen(final boolean bDirty) {
		runOnUiThread(this::requireInternetConnection);
//		runOnUiThread(()->{
//			mSurfView.setRenderMode(bDirty ? GLSurfaceView.RENDERMODE_WHEN_DIRTY : GLSurfaceView.RENDERMODE_CONTINUOUSLY);
//			mSurfView.requestRender(); // Render only when requestRender() is called
//		});
	}

	@Keep
	public void showPopupAd(final int iCount, final float fKilos, final boolean bEnded) {
		runOnUiThread(()->{
			iPlayerRaces += iCount;
			fPlayerKilos += fKilos;
			savePersistData(this);
			String mString = getString(bEnded ? R.string.race_finish : R.string.take_break);
			if(mAdsFan.showRewardedVideoAd()) {
				if(iDebugLevel > 0) Log.d(mLogTag, "Show rewarded video ad: iCount = "+iCount);
				mString += getString(R.string.wait_for);
				mAdsMob.showAdView(mAdsFan.showAdView(true)); // Update banner ad
			} else if(fKilos > 1 && (mAdsFan.showInterstitialAd() || mAdsMob.showInterstitialAd())) { // No interstitial ad for short race
				if(iDebugLevel > 0) Log.d(mLogTag, "Show interstitial ad: iCount = "+iCount);
				mString += getString(R.string.right_back);
			} else if(mAdsMob.showRewardedVideoAd()) {
				if(iDebugLevel > 0) Log.d(mLogTag, "Show rewarded video ad: iCount = "+iCount);
				mString += getString(R.string.wait_for);
				mAdsMob.showAdView(mAdsFan.showAdView(false)); // Reset banner ad
			}
			showToastString(mString, 1);
		});
	}

	@Keep
	public static void systemExit() {
		System.exit(0);
	}

	static { System.loadLibrary("torcs"); }
	public native void setAppPath(String app, String lib); // Non-static method pass class object to C++
	public static native void InitSound(int iFreq, int iSize);
	public static native void EnableSound(boolean bEnabled);
	public static native void setTouchAction(int area, int down);
	public static native void startCarRacing();
	public static native void continueRacing();
}
