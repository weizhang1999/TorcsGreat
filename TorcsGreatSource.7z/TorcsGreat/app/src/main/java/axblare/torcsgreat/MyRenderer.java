/////////////////////////////////////////////////////////////////////////////
//                                                                         //
//   Torcs Great is an Android port of the famous open source game TORCS   //
//   Copyright (c) 2019-2020, Wei Zhang <mailto:weizhang1999@gmail.com>.   //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
//
// See the original TORCS game at <https://sourceforge.net/projects/torcs/>.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

package axblare.torcsgreat;

import android.content.res.AssetManager;
import android.opengl.GLSurfaceView;
import android.util.Log;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

class MyRenderer implements GLSurfaceView.Renderer {
	private static final String mLogTag = "LogTag"; // String id for logcat
	private static final int iDebugLevel = 0; // Debug level (larger for more)
	private static int iGameState = 0; // Game state of the racing simulator
	static AssetManager mAssetManager; // Asset manager for language patch
	static boolean bStartRenderer; // The renderer can now start drawing

	@Override
	public void onSurfaceCreated(GL10 gl, EGLConfig config) {
		if(iDebugLevel > 0) Log.d(mLogTag, "onSurfaceCreated: iGameState = "+iGameState);
		LoadGameAssets(mAssetManager);
	}

	@Override
	public void onSurfaceChanged(GL10 gl, int width, int height) {
		if(iDebugLevel > 1) Log.d(mLogTag, "onSurfaceChanged: iGameState = "+iGameState);
		ResetViewport(width, height);
	}

	@Override
	public void onDrawFrame(GL10 gl) {
		if(iDebugLevel > 2) Log.d(mLogTag, "onDrawFrame: iGameState = "+iGameState);
		if(bStartRenderer) iGameState = RenderFrame(iGameState);
	}

	public static native void LoadGameAssets(AssetManager hMan);
	public static native void ResetViewport(int iW, int iH);
	public static native int RenderFrame(int iState);
}
