/////////////////////////////////////////////////////////////////////////////
//                                                                         //
//   Torcs Great is an Android port of the famous open source game TORCS   //
//   Copyright (c) 2019-2020, Wei Zhang <mailto:weizhang1999@gmail.com>.   //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
//
// See the original TORCS game at <https://sourceforge.net/projects/torcs/>.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

package axblare.torcsgreat;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Point;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.os.SystemClock;
import android.speech.tts.TextToSpeech;
import android.text.SpannableStringBuilder;
import android.text.style.RelativeSizeSpan;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.play.core.appupdate.AppUpdateInfo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.install.model.UpdateAvailability;
import com.google.android.play.core.tasks.Task;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Random;

import androidx.annotation.Keep;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import static axblare.torcsgreat.MyRender.*;
import static axblare.torcsgreat.MySettings.*;

public class MyKernel extends AppCompatActivity {
	private static final String mLogTag = "LogTag"; // String id for logcat
	private static final int iDebug = 0; // Debug level (larger for more info)
	private static int iCurrentMusic = 0; // Current music index (0 or 1)
	private static final Map<String, Integer> mResIds = new HashMap<>();
	private static TextToSpeech mTextToSpeech; // Text to speech engine
	private static MediaPlayer mMediaPlayer; // Android media player
	private static final Random mRandom = new Random(); // Random number
	private static final Handler mHandler = new Handler(); // Loop handler
	private static final Point mSize = new Point(); // Display size
	private AdsMob mAdsMob; // Ad reference
	private TextView mTextInfo; // Text info view reference
	private final TextView[] mTextView = new TextView[8]; // Buttons

	private static final String State_iLoopCounter = "iLoopCounter"; // Looped number of the handler
	private static final String State_iRacingState = "iRacingState"; // State of the racing simulator
	private static final String State_bGameRunning = "bGameRunning"; // Main game has started running
	private static int iLoopCounter = 0; // Loops that the game has finished so far
	private static volatile boolean bGameRunning; // Game has started running
	private static boolean bRewardVideo; // Reward video ad is shown

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		if(iDebug > 0) Log.d(mLogTag, "onCreate: savedInstanceState = "+savedInstanceState);
		super.onCreate(savedInstanceState);
		WindowManager mWindowManager = (WindowManager)getSystemService(Context.WINDOW_SERVICE);
		Objects.requireNonNull(mWindowManager).getDefaultDisplay().getSize(mSize);
		if(mSize.x < mSize.y) return; // Landscape mode only

		mResIds.put("locale_player", R.string.locale_player);
		mResIds.put("locale_human", R.string.locale_human);
		mResIds.put("locale_robot", R.string.locale_robot);

		loadPersistData(this); // Load saved settings
		setContentView(R.layout.activity_main);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		if(iDebug > 0) Log.i(mLogTag, "Creating game paths");
		setGameDirs(getApplicationContext()); // Make app paths available for checking file existence
		mResources = getResources();
		mAssetManager = getAssets();
		if(savedInstanceState == null) {
			if(iDebug > 0) Log.d(mLogTag, "App folder: "+mAppDir); // List data folder
			setAppPath(mAppDir); // Set app path once only
		} else {
			iLoopCounter = savedInstanceState.getInt(State_iLoopCounter);
//			iRacingState = savedInstanceState.getInt(State_iRacingState); // FIXME crash after showing ads (can only restart)
			bGameRunning = savedInstanceState.getBoolean(State_bGameRunning);
			if(iDebug > 0) Log.e(mLogTag, "Restoring instance state: iRacingState = "+iRacingState);
		}

		int iSampleRate = 44100; // Audio sample rate (default 44100)
		int iBufferSize = 1024; // Audio buffer size (default 1024)
		final AudioManager mAudioManager = (AudioManager)getSystemService(Context.AUDIO_SERVICE); // Get the native audio system
		if(mAudioManager != null) {
			iSampleRate = Integer.parseInt(mAudioManager.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE));
			iBufferSize = Integer.parseInt(mAudioManager.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER));
		}
		InitSound(iSampleRate, iBufferSize);
		if(mMediaPlayer == null) mMediaPlayer = new MediaPlayer(); // Initialize once only
		mTextToSpeech = new TextToSpeech(this, status->{
			if(status != TextToSpeech.ERROR) {
				Locale mLocale = Locale.getDefault(); // Currently used language
				if(mTextToSpeech.setLanguage(mLocale) == TextToSpeech.LANG_NOT_SUPPORTED) mLocale = Locale.US; // Available on all devices
				mTextToSpeech.setLanguage(mLocale);
				Configuration mConfiguration = new Configuration(mResources.getConfiguration());
				mConfiguration.setLocale(mLocale);
				mResources = createConfigurationContext(mConfiguration).getResources();
				startTextSpeech(" ", TextToSpeech.QUEUE_ADD); // Run it once to make later call faster
			}
		});

		mTextInfo = findViewById(R.id.text_info);
		mTextView[0] = findViewById(R.id.button_up);
		mTextView[1] = findViewById(R.id.button_down);
		mTextView[2] = findViewById(R.id.button_left);
		mTextView[3] = findViewById(R.id.button_right);
		mTextView[4] = findViewById(R.id.button_b);
		mTextView[5] = findViewById(R.id.button_a);
		mTextView[6] = findViewById(R.id.button_y);
		mTextView[7] = findViewById(R.id.button_x);
		iColorSilver = ContextCompat.getColor(this, R.color.colorSilver);
		iColorGold = ContextCompat.getColor(this, R.color.colorGold);

		mSurfView = findViewById(R.id.surf_view); // Get OpenGL view defined in layout
		if(iDebug > 0) Log.i(mLogTag, "Require OpenGL ES 3.0 device or later");
		mSurfView.setEGLContextClientVersion(3); // Support OpenGL ES 3.0 device or later
		mSurfView.setEGLConfigChooser(new MyConfig()); // Pick 24-bit depth and 8-bit stencil
		mSurfView.setRenderer(new MyRender()); // This method must be called before setRenderMode
		mSurfView.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY); // Renderer is called continuously
		mSurfView.setPreserveEGLContextOnPause(true); // EGL context is preserved when GLSurfaceView is paused
		mSurfView.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
			@Override
			public boolean onPreDraw() { // At this point, all views in the tree have been measured and given a frame
				if(!mSurfView.getViewTreeObserver().isAlive()) return true; // Need to call this again until it is alive
				mSurfView.getViewTreeObserver().removeOnPreDrawListener(this); // Remove listener so code will run once only
				if(iDebug > 0) Log.w(mLogTag, "OnPreDrawListener: Width = "+mSurfView.getWidth()+" Height = "+mSurfView.getHeight());

				updateViewLayouts(); // Resize view layouts
				mAdsMob = new AdsMob(MyKernel.this, mResources, new int[]{R.id.ad_layout, 1, 1, 1});
				if(bGameRunning) { // No dialog or looping is needed (resuming game)
					if(iDebug > 0) Log.w(mLogTag, "Resuming from the running game state");
					resetGameViews();
					return true;
				}

				if(!isUnzipped()) showAppSettings(); // Show app settings dialog
				mHandler.postDelayed(new Runnable() {
					@Override
					public void run() {
						iLoopCounter++; // Increase the loop counter
						mHandler.postDelayed(this, 100); // Loop with time delay 100 ms
						if(bDialogBox) return; // Do nothing if dialog window is open
						if(isUnzipped()) { // All good to go
							if(!bGameRunning) {
								if(iDebug > 0) Log.w(mLogTag, "Stopping handler runnable (new game)");
								mHandler.removeCallbacks(this); // Remove any pending posts of this runnable
								new Handler(Looper.getMainLooper()).postDelayed(()->{
									if(iDebug > 0) Log.w(mLogTag, "Starting game thread: iLoopCounter = "+iLoopCounter);
									bGameRunning = true;
									resetGameViews();
									startCarRacing();
								}, 1000); // Start after 1000 milliseconds (let the handler stop first)
							}
						} else { // Need game data
							final String mWait = getString(R.string.takes_time)+"\n"+getString(R.string.please_wait);
							if(isDownloaded()) { // Need to unzip
								if(!isTrue(bUnzipping)) {
									setTrue(bUnzipping);
									Intent intent = new Intent(getApplicationContext(), MySettings.class);
									enqueueWork(getApplicationContext(), MySettings.class, 1, intent);
								}
								final String mInfo =
										getString(R.string.text_unzipping)+"\n"+getString(R.string.game_assets)+"\n"+unzippedPercent()+"%";
								runOnUiThread(()->mTextInfo.setText(isFlashTime() ? mWait : mErrMsg != null ? mErrMsg : mInfo));
							} else { // Need to download
								if(!isTrue(bFetching)) { // Need to download
									String mPath = Objects.requireNonNull(getExternalFilesDir(null)).getAbsolutePath();
									final long lStorage = new StatFs(mPath).getAvailableBytes()/1048576;
									if(lStorage < 287) { // Check for free storage space
										mErrMsg = getString(R.string.need_space)+"\n"+getString(R.string.storage_low)+"\n"+lStorage+" MB.";
									} else {
										setTrue(bFetching);
										startDownload(MyKernel.this);
									}
								}
								final String mInfo =
										getString(R.string.text_downloading)+"\n"+getString(R.string.game_assets)+"\n"+downloadedPercent()+"%";
								runOnUiThread(()->mTextInfo.setText(isFlashTime() ? mWait : mErrMsg != null ? mErrMsg : mInfo));
								requireInternetConnection();
							}
						}
					}
				}, 0);
				return true;
			}
		});
	}

	@Override
	protected void onResume() {
		if(iDebug > 0) Log.d(mLogTag, "onResume: mMediaPlayer = "+mMediaPlayer);
		super.onResume();
		ResumeMediaPlayer();
		if(mSurfView != null) mSurfView.onResume(); // Need to call this (black screen otherwise)
		if(bGameRunning) setRenderPaused(false); // Enable renderer after downloading game assets
	}

	@Override
	protected void onPause() {
		if(iDebug > 0) Log.e(mLogTag, "onPause: isFinishing() = "+isFinishing());
		if(mMediaPlayer != null) {
			mMediaPlayer.pause();
		}
		if(bGameRunning) setRenderPaused(true);
		if(mSurfView != null) mSurfView.onPause(); // Need to call this (black screen otherwise)
		super.onPause();
	}

	@Override
	protected void onSaveInstanceState(@NonNull Bundle outState) {
		if(iDebug > 0) Log.d(mLogTag, "onSaveInstanceState: isFinishing() = "+isFinishing());
		outState.putInt(State_iLoopCounter, iLoopCounter);
		outState.putInt(State_iRacingState, isFinishing() || iRacingState < 2 ? 0 : iRacingState); // Start over if finishing or not started
		outState.putBoolean(State_bGameRunning, !isFinishing() && bGameRunning);
		if(isFinishing()) {
			ReleaseMediaPlayer(); // Release media play resources
			StopTextSpeech(); // Stop the text to speech engine // KEEP IT Running
			if(mAdsMob != null) mAdsMob.destroyAll();
		}
		super.onSaveInstanceState(outState);
	}

	@Keep
	@Override
	public void onBackPressed() {
		runOnUiThread(this::showAppSettings); // Run on main thread (may be called by renderer)
	}

	boolean isFlashTime() {
		return (SystemClock.elapsedRealtime()&0x400) != 0;
	}

	private void requireInternetConnection() {
		ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo netInfo = cm != null ? cm.getActiveNetworkInfo() : null;
		if(netInfo != null && netInfo.isConnectedOrConnecting()) return;
		if(SystemClock.elapsedRealtime()%3550 > 3500) showToastString(mResources.getString(R.string.no_internet), -1);
	}

	static void awardCredit(final MyKernel mActivity, int iCoins) {
		if(bGameRunning) setRenderPaused(false);
		if(iCoins <= 0 || !bGameRunning) {
			resumeRacing();
			return;
		}
		iCoins *= 2+mRandom.nextInt(9); // Scale factor range [2, 10]
		if(iDebug > 0) Log.i(mLogTag, "awardCredit: iCoins = "+iCoins);
		if(bRewardVideo) {
			String mString = mResources.getString(R.string.locale_thanks)+"\n";
			mString += mResources.getString(R.string.locale_accept)+" "+iCoins+" "+mResources.getString(R.string.locale_coins);
			mActivity.showToastString(mString, TextToSpeech.QUEUE_ADD);
		}
		lPlayerCoins += iCoins;
		savePersistData(mActivity);
	}

	void restartGame() { // TODO better get rid of this
		startActivity(Intent.makeRestartActivityTask(getIntent().getComponent())); // Restart to avoid graphics problems (need to fix)
		System.exit(0); // Must kill the old process
	}

	private void watchVideoAd() {
		final AlertDialog.Builder mBuilder = new AlertDialog.Builder(this, R.style.SettingsPopup);
		mBuilder.setIconAttribute(android.R.attr.alertDialogIcon).setTitle(R.string.dialog_exit);
		mBuilder.setMessage(getBiggerText(mResources.getString(R.string.text_video), 1.125f));
		mBuilder.setNeutralButton(R.string.button_nope, (dialog, id)->resumeRacing());
		mBuilder.setPositiveButton(R.string.button_yes, (dialogInterface, i)->showPopupAd(0, 0, false));
		final AlertDialog mAlert = mBuilder.create();
		mAlert.show();
	}

	private String getLocaleString(final String mString) {
		final Integer iResource = mResIds.get(mString);
		return iResource != null ? mResources.getString(iResource) : mString;
	}

	private SpannableStringBuilder getBiggerText(final String text, final float size) {
		SpannableStringBuilder biggerText = new SpannableStringBuilder(text);
		biggerText.setSpan(new RelativeSizeSpan(size), 0, text.length(), 0);
		return biggerText;
	}

	@Keep
	void showToastString(String text, int talk) {
		if(talk >= 0) startTextSpeech(text, talk);
		runOnUiThread(()->{
			Toast toast = Toast.makeText(getApplicationContext(), getBiggerText(getLocaleString(text), 1.5f), Toast.LENGTH_SHORT);
			toast.show();
		});
	}

	@SuppressLint("InflateParams")
	private void showAppSettings() {
		bDialogBox = true;
		if(iRacingState > 1) pauseRacing();
		final boolean bEnable = bGameRunning;
		AlertDialog.Builder mBuilder = new AlertDialog.Builder(this, R.style.SettingsDialog);
		mBuilder.setView(getLayoutInflater().inflate(R.layout.settings_app, null));
		mBuilder.setNeutralButton(R.string.end_game, (dialog, id)->{
			savePersistData(this);
			if(!bEnable) MyKernel.systemExit(); // Exit immediately if game is not running
			showToastString(mResources.getString(R.string.like_game), TextToSpeech.QUEUE_FLUSH);
			new Handler(Looper.getMainLooper()).postDelayed(MyKernel::systemExit, 6000); // Exit after 6 seconds
		});
		if(bEnable) {
//			mBuilder.setNegativeButton(R.string.watch_ad, (dialog, id)->watchVideoAd()); // FIXME crash after showing ads (can only restart)
		} else {
			try {
				AppUpdateManager appUpdateManager = AppUpdateManagerFactory.create(this); // Create instance of the manager
				Task<AppUpdateInfo> appUpdateInfoTask = appUpdateManager.getAppUpdateInfo(); // Return an intent object to check for an update
				appUpdateInfoTask.addOnSuccessListener(appUpdateInfo->{
					if(appUpdateInfo != null && appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE) {
						showToastString(mResources.getString(R.string.new_version), TextToSpeech.QUEUE_ADD);
					}
				});
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		mBuilder.setPositiveButton(R.string.continue_game, (dialog, id)->{
			savePersistData(this);
			ResumeMediaPlayer();
			bDialogBox = false;
			dialog.dismiss();
			resumeRacing();
		});
		final AlertDialog mAlert = mBuilder.create();
		mAlert.setCanceledOnTouchOutside(false);
		mAlert.setCancelable(false);
		if(mAdsMob != null) mAdsMob.showAdView(false); // Hide banner ad
		mAlert.setOnDismissListener(menu1->{
			if(mAdsMob != null) mAdsMob.showAdView(true); // Show banner ad
		});
		mAlert.show();
		if(bEnable) {
			mAlert.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.RED);
		}

		String mAbout = mResources.getString(R.string.app_name)+" "+BuildConfig.VERSION_NAME;
		TextView mDateInfo = mAlert.findViewById(R.id.game_settings);
		Objects.requireNonNull(mDateInfo).setText(mAbout);
		TextView mTextLevel = mAlert.findViewById(R.id.value_races);
		Objects.requireNonNull(mTextLevel).setText(NumberFormat.getIntegerInstance().format(iPlayerRaces));
		TextView mTextKilos = mAlert.findViewById(R.id.value_kilos);
		Objects.requireNonNull(mTextKilos).setText(new DecimalFormat("###,##0.00").format(fPlayerKilos)); // Keep 2 decimals
		TextView mTextFight = mAlert.findViewById(R.id.value_coins);
		Objects.requireNonNull(mTextFight).setText(NumberFormat.getIntegerInstance().format(lPlayerCoins));
		RadioGroup mGroupMode = mAlert.findViewById(R.id.group_modes);
		if(mGroupMode != null) {
			((RadioButton)mGroupMode.getChildAt(iCameraModes)).setChecked(true);
			mGroupMode.setOnCheckedChangeListener((group, id)->{
				for(int i = 0; i < mGroupMode.getChildCount(); i++) {
					if(((RadioButton)mGroupMode.getChildAt(i)).isChecked()) {
						iCameraModes = i;
						break;
					}
				}
				setCameraView(iCameraModes);
			});
		}
		CheckBox mCheckSound = mAlert.findViewById(R.id.check_sound);
		Objects.requireNonNull(mCheckSound).setChecked(bSoundEffect);
		mCheckSound.setOnClickListener(view->bSoundEffect = mCheckSound.isChecked());
		CheckBox mCheckMusic = mAlert.findViewById(R.id.check_music);
		Objects.requireNonNull(mCheckMusic).setChecked(bMusicEffect);
		mCheckMusic.setOnClickListener(view->bMusicEffect = mCheckMusic.isChecked());
		CheckBox mCheckVoice = mAlert.findViewById(R.id.check_speech);
		Objects.requireNonNull(mCheckVoice).setChecked(bVoiceEffect);
		mCheckVoice.setOnClickListener(view->bVoiceEffect = mCheckVoice.isChecked());
		TextView mPrivacyPolicy = mAlert.findViewById(R.id.privacy_policy);
		Objects.requireNonNull(mPrivacyPolicy).setOnClickListener(v->{
			final String mPrivacyLink = "https://sites.google.com/view/axblare/torcs-great";
			startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(mPrivacyLink)));
		});
	}

	private static final int BUTTON_U = 0x01;
	private static final int BUTTON_D = 0x02;
	private static final int BUTTON_L = 0x04;
	private static final int BUTTON_R = 0x08;
	private static final int BUTTON_B = 0x10;
	private static final int BUTTON_A = 0x20;
	private static final int BUTTON_Y = 0x40;
	private static final int BUTTON_X = 0x80;
	private static final int[] iKeys = {BUTTON_U, BUTTON_D, BUTTON_L, BUTTON_R, BUTTON_B, BUTTON_A, BUTTON_Y, BUTTON_X};

	private GLSurfaceView mSurfView;
	private static int iColorSilver;
	private static int iColorGold;
	private volatile int iCurrentKey = 0;
	private volatile int iLightButton = 0;

	private void lightButton(final int iButton, final boolean bLight) {
		for(int i = 0; i < iKeys.length; i++) {
			if(iButton == iKeys[i]) {
				mTextView[i].setBackgroundColor(bLight ? iColorGold : iColorSilver);
				iLightButton = bLight ? iButton : 0;
				return;
			}
		}
	}

	@SuppressLint("ClickableViewAccessibility")
	void updateViewLayouts() {
		final int iWidth = Math.round(mSurfView.getHeight()/0.625f);
		final int jWidth = Math.round((mSize.x-iWidth)/2.0f-mResources.getDimension(R.dimen.small_margin));
		mSurfView.getLayoutParams().width = iWidth;
		mTextInfo.getLayoutParams().width = iWidth;
		final int iPadding = -Math.round(mResources.getDimension(R.dimen.arrow_text))/4;
		for(int i = 0; i < 8; i++) {
			mTextView[i].setWidth(jWidth);
			mTextView[i].setPadding(0, i < 4 ? iPadding : iPadding/3, 0, 0);
			final int iButton = iKeys[i];
			mTextView[i].setOnTouchListener((v, event)->{
				final int iAction = event.getAction();
				if(iAction == MotionEvent.ACTION_DOWN) {
					setRenderPaused(false);
					lightButton(iButton, true);
					setTouchAction(iButton, 1);
				} else if(iAction == MotionEvent.ACTION_UP) {
					lightButton(iButton, false);
					setTouchAction(iButton, 0);
				}
				return true;
			});
			if(i > 0) continue;
			mSurfView.setOnTouchListener((v, event)->{
//				final int iX = Math.round(event.getX()*(mSurfView.getWidth()-1)/(iWidth-1));
//				final int iY = Math.round(event.getY()*(mSurfView.getHeight()-1)/(iHeight-1));
				final int iAction = event.getAction();
				if(iAction == MotionEvent.ACTION_DOWN) {
					setRenderPaused(false);
//					mouse_x = iX;
//					mouse_y = iY;
//					long_click = false;
//					mouse_move = false;
//					setTouchEvent(iModifier|MOUSE_L|MOUSE_D, true, iX, iY); // Left mouse button is pressed
//				} else if(iAction == MotionEvent.ACTION_MOVE && Math.abs(mouse_x-iX)+Math.abs(mouse_y-iY) > 9) {
//					mouse_x = iX;
//					mouse_y = iY;
//					mouse_move = true;
//					setTouchEvent(iModifier|MOUSE_M, true, iX, iY); // Mouse button is dragged
//				} else if(iAction == MotionEvent.ACTION_UP) {
//					mouse_x = iX;
//					mouse_y = iY;
//					setTouchEvent(iModifier|MOUSE_L, false, iX, iY); // Left mouse button is released
//					if(long_click) setTouchEvent(iModifier|MOUSE_R, false, iX, iY); // Right mouse button is released
				}
				return false;
			});
		}
		if(iDebug > 0) Log.e(mLogTag, "updateViewLayouts: iWidth = "+iWidth+" jWidth = "+jWidth);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if(iDebug > 2) Log.d(mLogTag, "onKeyUp: keyCode = "+keyCode+" iCurrentKey = "+iCurrentKey);
		if(iLightButton != 0) lightButton(iLightButton, false);
		switch(keyCode) { // TODO: define a map to assign directional keys (inconsistent behavior on different devices)
			case KeyEvent.KEYCODE_DPAD_UP:
				iCurrentKey = keyCode;
				lightButton(BUTTON_L, true);
				setTouchAction(BUTTON_L, 1);
				break;
			case KeyEvent.KEYCODE_DPAD_DOWN:
				iCurrentKey = keyCode;
				lightButton(BUTTON_R, true);
				setTouchAction(BUTTON_R, 1);
				break;
			case KeyEvent.KEYCODE_DPAD_LEFT:
				iCurrentKey = keyCode;
				lightButton(BUTTON_D, true);
				setTouchAction(BUTTON_D, 1);
				break;
			case KeyEvent.KEYCODE_DPAD_RIGHT:
				iCurrentKey = keyCode;
				lightButton(BUTTON_U, true);
				setTouchAction(BUTTON_U, 1);
				break;
			case KeyEvent.KEYCODE_B:
			case KeyEvent.KEYCODE_ESCAPE:
			case KeyEvent.KEYCODE_ALT_LEFT:
			case KeyEvent.KEYCODE_ALT_RIGHT:
				iCurrentKey = keyCode;
				lightButton(BUTTON_B, true);
				setTouchAction(BUTTON_B, 1);
				break;
			case KeyEvent.KEYCODE_A:
			case KeyEvent.KEYCODE_SHIFT_LEFT:
			case KeyEvent.KEYCODE_SHIFT_RIGHT:
				iCurrentKey = keyCode;
				lightButton(BUTTON_A, true);
				setTouchAction(BUTTON_A, 1);
				break;
			case KeyEvent.KEYCODE_Y:
			case KeyEvent.KEYCODE_SPACE:
			case KeyEvent.KEYCODE_ENTER:
				iCurrentKey = keyCode;
				lightButton(BUTTON_Y, true);
				setTouchAction(BUTTON_Y, 1);
				break;
			case KeyEvent.KEYCODE_X:
			case KeyEvent.KEYCODE_CTRL_LEFT:
			case KeyEvent.KEYCODE_CTRL_RIGHT:
				iCurrentKey = keyCode;
				lightButton(BUTTON_X, true);
				setTouchAction(BUTTON_X, 1);
				break;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event) {
		if(iDebug > 2) Log.e(mLogTag, "onKeyUp: keyCode = "+keyCode+" iCurrentKey = "+iCurrentKey);
		iCurrentKey = 0; // Reset pressed key
		lightButton(iLightButton, false);
		setTouchAction(0, 0);
		return super.onKeyUp(keyCode, event);
	}

//	private void setTouchEvent(int area, boolean down, int x, int y) {
//		if((area&MOUSE_ACTION) != 0) {
//			MouseQueue.add(MOUSE_EVENT(area, x, y));
//			iMouseAction = area;
//		} else if(down) {
//			iTouchButton = area;
//		} else {
//			iTouchButton &= area;
//			iTouchButton &= MODIFIER_KEY;
//		}
//		setTouchAction(area, down, x, y);
//	}

	private void resetGameViews() {
		runOnUiThread(()->{
			mTextInfo.setVisibility(View.GONE);
			int[] location = new int[2];
			mSurfView.getLocationOnScreen(location);
			final int x = location[0];
			final int y = location[1];
			final int w = mSurfView.getWidth();
			final int h = mSurfView.getHeight();
			if(iDebug > 0) Log.i(mLogTag, "Display: "+mSize.x+"x"+mSize.y+" Viewport: x="+x+" y="+y+" w="+w+" h="+h);
			setRenderPaused(false);
		});
	}

	static void setRenderPaused(final boolean bPause) {
		bStartRenderer = !bPause;
	}

	@Keep
	private void startTextSpeech(String mString, int iQueue) {
		runOnUiThread(()->{
			if(!bVoiceEffect || mTextToSpeech == null) return; // Text speech is disabled
			mTextToSpeech.speak(getLocaleString(mString), iQueue, null, null);
		});
	}

	private static void StopTextSpeech() {
		if(mTextToSpeech != null && mTextToSpeech.isSpeaking()) mTextToSpeech.stop();
	}

	private void StartMediaPlayer(final int iMidi) {
		mMediaPlayer.reset();
		try {
			AssetFileDescriptor afd = mResources.openRawResourceFd(iMidi == 0 ? R.raw.torcs0 : R.raw.torcs1);
			if(afd == null) return;
			mMediaPlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
			afd.close();
			mMediaPlayer.prepare();
		} catch(IOException e) {
			Log.e(mLogTag, "not available for playing, check");
		}
		mMediaPlayer.setLooping(iMidi == 1);
		if(mMediaPlayer != null) {
			iCurrentMusic = iMidi;
			mMediaPlayer.start(); // Play the file (it takes some time to start)
		}
	}

	public static boolean IsMediaPlaying() {
		return mMediaPlayer != null && mMediaPlayer.isPlaying();
	}

	public static void StopMediaPlayer() {
		if(IsMediaPlaying()) mMediaPlayer.stop();
		iCurrentMusic = 0;
	}

	public static void ResumeMediaPlayer() {
		if(mMediaPlayer != null) {
			if(bMusicEffect && iCurrentMusic >= 0) {
				mMediaPlayer.start();
			} else {
				mMediaPlayer.pause();
			}
		}
	}

	public static void ReleaseMediaPlayer() {
		if(mMediaPlayer == null) return; // Media player is not available
		StopMediaPlayer();
		mMediaPlayer.release();
		mMediaPlayer = null;
	}

	@Keep
	public void playMusicFile(final int iMidi) {
		runOnUiThread(()->{
			if(!bMusicEffect || iMidi == iCurrentMusic && IsMediaPlaying()) return;
			StopMediaPlayer(); // Stop current music
			if(iMidi < 0) return; // No music to play
			StartMediaPlayer(iMidi); // Play new music
		});
	}

	@Keep
	public void setCameraMode(final int mode) {
		iCameraModes = mode;
		savePersistData(this);
		showToastString(mResources.getString(R.string.locale_camera), TextToSpeech.QUEUE_FLUSH);
	}

	@Keep
	public void runRenderer() {
		mSurfView.requestRender();
		requireInternetConnection();
	}

	@Keep
	public void showPopupAd(final int iCount, final float fKilos, final boolean bEnded) {
		runOnUiThread(()->{
			if(mAdsMob == null) return;
			iPlayerRaces += iCount;
			fPlayerKilos += fKilos;
			savePersistData(this);
			String mString = mResources.getString(bEnded ? R.string.locale_finish : R.string.locale_break);
			bRewardVideo = false;
			if(mAdsMob.showRewardedIntersAd(this)) {
				bRewardVideo = true;
			} else if(fKilos > 1 && mAdsMob.showInterstitialAd(this)) {
				mString += "\n"+mResources.getString(R.string.locale_back);
			} else if(mAdsMob.showRewardedAd(this)) {
				bRewardVideo = true;
			}
			if(bRewardVideo) {
				mString += "\n"+mResources.getString(R.string.locale_wait);
			}
			showToastString(mString, TextToSpeech.QUEUE_FLUSH);
		});
	}

	@Keep
	public static void systemExit() {
		System.exit(0);
	}

	static { // Load all drivers to make them always available by increasing library reference count
		System.loadLibrary("berniw");
		System.loadLibrary("berniw2");
		System.loadLibrary("berniw3");
		System.loadLibrary("bt");
		System.loadLibrary("damned");
		System.loadLibrary("human");
		System.loadLibrary("inferno");
		System.loadLibrary("inferno2");
		System.loadLibrary("lliaw");
		System.loadLibrary("olethros");
		System.loadLibrary("tita");
	}
	public native void setAppPath(String app); // Non-static method pass class object to C++
	public static native void InitSound(int iFreq, int iSize);
	public static native void EnableSound(boolean bEnabled);
	public static native void setTouchAction(int area, int down);
	public static native void setCameraView(int mode);
	public static native void startCarRacing();
	public static native void pauseRacing();
	public static native void resumeRacing();
}
