package axblare.torcsgreat;

import android.widget.LinearLayout;

import com.facebook.ads.AdSettings;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.facebook.ads.AudienceNetworkAds;

class AdsFan {
	private AdView mAdView; // Banner ad view reference

	AdsFan(final MainActivity mActivity) {
		AudienceNetworkAds.initialize(mActivity); // Initialize the Audience Network SDK
		AdSettings.setIntegrationErrorMode(AdSettings.IntegrationErrorMode.INTEGRATION_ERROR_CALLBACK_MODE); // Choose callback mode
		final AdSize mAdSize = MainActivity.bSmallScreen ? AdSize.BANNER_HEIGHT_50 : AdSize.BANNER_HEIGHT_90;
		mAdView = new AdView(mActivity, mActivity.getString(R.string.fb_banner), mAdSize); // Instantiate an AdView object
		LinearLayout mLinearLayout = mActivity.findViewById(R.id.ad_layout); // Find the Ad Container
		mLinearLayout.addView(mAdView); // Add the ad view to your activity layout
		mAdView.loadAd(); // Load a new banner ad
		mActivity.awardCredit(0); // Reward the player 0 coins
	}

	boolean showAdView(final boolean bShow) {
		return bShow;
	}

	boolean showInterstitialAd() {
		return false;
	}

	boolean showRewardedVideoAd() {
		return false;
	}

	void destroyAll() {
		if(mAdView != null) {
			mAdView.destroy();
			mAdView = null;
		}
	}
}
