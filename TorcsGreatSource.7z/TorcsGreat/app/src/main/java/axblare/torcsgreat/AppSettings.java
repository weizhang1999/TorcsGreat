/////////////////////////////////////////////////////////////////////////////
//                                                                         //
//   Torcs Great is an Android port of the famous open source game TORCS   //
//   Copyright (c) 2019-2020, Wei Zhang <mailto:weizhang1999@gmail.com>.   //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
//
// See the original TORCS game at <https://sourceforge.net/projects/torcs/>.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

package axblare.torcsgreat;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;

import com.downloader.Error;
import com.downloader.OnDownloadListener;
import com.downloader.PRDownloader;
import com.downloader.PRDownloaderConfig;
import com.hzy.lib7z.IExtractCallback;
import com.hzy.lib7z.Z7Extractor;

import java.io.File;
import java.io.IOException;
import java.util.Locale;
import java.util.Objects;

import androidx.annotation.NonNull;
import androidx.core.app.JobIntentService;

public class AppSettings extends JobIntentService {
	private static final String mLogTag = "LogTag"; // String id for logcat
	private static final int iDebugLevel = 0; // Debug level (larger for more)
	private static final String KEY_PLAYER_RACES = "PLAYER_RACES";
	private static final String KEY_PLAYER_KILOS = "PLAYER_KILOS";
	private static final String KEY_PLAYER_COINS = "PLAYER_COINS";
	private static final String KEY_SOUND_EFFECT = "SOUND_EFFECT";
	private static final String KEY_MUSIC_EFFECT = "MUSIC_EFFECT";
	private static final String KEY_VOICE_EFFECT = "VOICE_EFFECT";
	static int iPlayerRaces = 0; // Races the player has completed
	static float fPlayerKilos = 0; // Kilos the player has accumulated
	static long lPlayerCoins = 0; // Coins the player has (current balance)
	static boolean bSoundEffect = true; // Sound effect is on
	static boolean bMusicEffect = true; // Music effect is on
	static boolean bVoiceEffect = true; // Voice effect is on
	static boolean bDialogBox = false; // Dialog window is shown (settings)

	private static final String mAssetLinks = "https://github.com/weizhang1999/TorcsGreat/blob/master/TorcsGreatAsset%d.7z?raw=true";
	private static final String[] mAssetFiles = {"Asset0.7z", "Asset1.7z", "Asset2.7z", "Asset3.7z"}; // Asset files
	private static final String[] bFetched = {"bFetched0", "bFetched1", "bFetched2", "bFetched3"}; // Fetched files
	private static final long lPackedSize = 25640988+25673676+25058764+24637686; // Packed asset data 96.3 MB (101,011,114 bytes)
	private static final long lAssetUnzip = 268268772; // Uncompressed game asset data total size 255 MB (268,268,772 bytes)
	private static long[] lDownloads = {0, 0, 0, 0}; // Size of the packed game asset data that have been downloaded
	private static long lUnzipped = 0; // Size of the packed game asset data that have been unzipped
	static final String mSubDir = "results/"; // Sub dir name for the download and history data
	static String mAppDir; // Absolute path where the application can place its game assets
	static String mSrcDir; // Source directory (where the downloaded data files are saved)
	static String mErrMsg; // Error message for downloading and unzipping the game assets

	static final String bRunning = "bRunning"; // Racing game has started running
	static final String bFetching = "bFetching"; // Game data file is downloading
	static final String bUnzipping = "bUnzipping"; // Game data file is unzipping

	static void loadPersistData(final MainActivity mActivity) {
		SharedPreferences mPreference = PreferenceManager.getDefaultSharedPreferences(mActivity);
		iPlayerRaces = mPreference.getInt(KEY_PLAYER_RACES, iPlayerRaces);
		fPlayerKilos = mPreference.getFloat(KEY_PLAYER_KILOS, fPlayerKilos);
		lPlayerCoins = mPreference.getLong(KEY_PLAYER_COINS, lPlayerCoins);
		bSoundEffect = mPreference.getBoolean(KEY_SOUND_EFFECT, bSoundEffect);
		bMusicEffect = mPreference.getBoolean(KEY_MUSIC_EFFECT, bMusicEffect);
		bVoiceEffect = mPreference.getBoolean(KEY_VOICE_EFFECT, bVoiceEffect);
		MainActivity.EnableSound(bSoundEffect);
	}

	static void savePersistData(final MainActivity mActivity) {
		SharedPreferences.Editor mEditor = PreferenceManager.getDefaultSharedPreferences(mActivity).edit();
		mEditor.putInt(KEY_PLAYER_RACES, iPlayerRaces);
		mEditor.putFloat(KEY_PLAYER_KILOS, fPlayerKilos);
		mEditor.putLong(KEY_PLAYER_COINS, lPlayerCoins);
		mEditor.putBoolean(KEY_SOUND_EFFECT, bSoundEffect);
		mEditor.putBoolean(KEY_MUSIC_EFFECT, bMusicEffect);
		mEditor.putBoolean(KEY_VOICE_EFFECT, bVoiceEffect);
		mEditor.apply(); // Save current settings
		MainActivity.EnableSound(bSoundEffect);
	}

	private static void deleteRecursive(File mFile) {
		if(mFile.isDirectory()) {
			for(File child : Objects.requireNonNull(mFile.listFiles()))
				deleteRecursive(child);
		}
		mFile.delete();
	}

	private static void makeSubDir(final String mSubDir) {
		File mFile = new File(mSrcDir, mSubDir);
		try {
			if(!mFile.exists() || !mFile.isDirectory()) mFile.mkdir();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	static void setGameDirs(final Context mContext) {
		PRDownloader.initialize(mContext, PRDownloaderConfig.newBuilder().setReadTimeout(90000).setConnectTimeout(90000).build());
		mAppDir = mContext.getExternalFilesDir(null)+"/";
		mSrcDir = mAppDir+mSubDir;
		if(iDebugLevel > 0) Log.d(mLogTag, "App folder: "+mAppDir); // List data folder
		setFalse(bRunning);
		deleteRecursive(new File(mSrcDir));
		createSaveDirs();
		clearFileFlags();
		delete7zFiles(); // Delete the source zip files not needed anymore
	}

	private static boolean isNotDir(final String mName, final boolean bMake) {
		if(mName == null) return true;
		File mFile = new File(mName);
		final boolean bAbsent = !mFile.exists() || !mFile.isDirectory();
		try {
			if(bMake && bAbsent) mFile.mkdir();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return bAbsent;
	}

	private static void createSaveDirs() {
		isNotDir(mSrcDir, true);
		makeSubDir("champ");
		makeSubDir("dtmrace");
		makeSubDir("endrace");
		makeSubDir("ncrace");
		makeSubDir("practice");
		makeSubDir("quickrace");
	}

	private static void clearFileFlags() {
		if(iDebugLevel > 0) Log.e(mLogTag, "Clearing useless files");
		for(final String mFile : bFetched) {
			setFalse(mFile);
		}
		setFalse(bFetching);
		setFalse(bUnzipping);
	}

	private static int getFileFlags(final String[] bFiles) {
		int iFlags = 0;
		for(final String mFile : bFiles) {
			if(isTrue(mFile)) iFlags++;
		}
		return iFlags;
	}

	static boolean isUnzipped() {
		return getFileFlags(mAssetFiles) == mAssetFiles.length;
	}

	static boolean isDownloaded() {
		return getFileFlags(bFetched) == bFetched.length;
	}

	static boolean isTrue(final String mBoolean) {
		return new File(mAppDir, mBoolean).exists();
	}

	static void setTrue(final String mBoolean) {
		try {
			new File(mAppDir, mBoolean).createNewFile();
		} catch(IOException e) {
			e.printStackTrace();
		}
	}

	static void setFalse(final String mBoolean) {
		File mFile = new File(mAppDir, mBoolean);
		if(mFile.exists()) mFile.delete();
	}

	private static void delete7z(final String mBoolean) {
		File mFile = new File(mSrcDir, mBoolean);
		if(mFile.exists()) mFile.delete();
	}

	private static void delete7zFiles() {
		if(isNotDir(mSrcDir, false)) return;
		File[] mFiles = new File(mSrcDir).listFiles();
		if(mFiles == null || mFiles.length == 0) return;
		for(File mFile : mFiles) {
			final String mName = mFile.getName();
			if(mName.contains(".7z")) { // Delete 7z files
				mFile.delete();
			}
		}
	}

	static void startDownload(final int iAsset) {
		createSaveDirs(); // Make path available for downloading zip file
		if(iDebugLevel > 0) Log.d(mLogTag, "Downloading "+mAssetFiles[iAsset]);
		PRDownloader.download(String.format(Locale.US, mAssetLinks, iAsset), mSrcDir, mAssetFiles[iAsset]).build().setOnProgressListener(
				progress->lDownloads[iAsset] = progress.currentBytes).start(new OnDownloadListener() {
			@Override
			public void onDownloadComplete() {
				setTrue(bFetched[iAsset]);
			}
			@Override
			public void onError(Error error) {
				mErrMsg = "Download error: "+error.toString();
				if(iDebugLevel > 0) Log.d(mLogTag, mErrMsg);
			}
		});
	}

	static void cancelDownload() {
		if(iDebugLevel > 0) Log.d(mLogTag, "Cancelling download...");
		try {
			PRDownloader.cancelAll(); // Cancel all the requests
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	static int downloadedPercent() {
		final int iPercent = (int)(((lDownloads[0]+lDownloads[1]+lDownloads[2]+lDownloads[3])*100L)/lPackedSize);
		return iPercent < 100 ? iPercent : 100;
	}

	static int unzippedPercent() {
		final int iPercent = (int)(lUnzipped*100L/lAssetUnzip);
		return iPercent < 100 ? iPercent : 100; // Avoid wrong information
	}

	@Override
	protected void onHandleWork(@NonNull Intent intent) {
		lUnzipped = 0; // Reset the unzipped data size
		for(final String mFile : mAssetFiles) {
			unzipAssetFile(mFile);
		}
	}

	private static void unzipAssetFile(final String mAssetFile) {
		Z7Extractor.extractFile(mSrcDir+mAssetFile, mAppDir, new IExtractCallback() {
			@Override
			public void onStart() {
				if(iDebugLevel > 0) Log.e(mLogTag, "Z7Extractor.extractFile starting "+mAssetFile);
			}

			@Override
			public void onGetFileNum(int fileNum) {
				if(iDebugLevel > 0) Log.i(mLogTag, "Z7Extractor.extractFile fileNum "+fileNum);
			}

			@Override
			public void onProgress(String name, long size) {
				if(size > 0) lUnzipped += size; // Update the progress
			}

			@Override
			public void onError(int errorCode, String message) {
				mErrMsg = "Unzip error: "+message;
				if(iDebugLevel > 0) Log.e(mLogTag, mErrMsg);
			}

			@Override
			public void onSucceed() {
				if(iDebugLevel > 0) Log.i(mLogTag, "Z7Extractor.extractFile finished "+mAssetFile+" lUnzipped = "+lUnzipped);
				delete7z(mAssetFile); // Delete the 7z file not needed anymore
				setTrue(mAssetFile); // Create an empty file
				if(isUnzipped()) {
					createSaveDirs(); // Make dirs available
					clearFileFlags();
				}
			}
		});
	}
}
