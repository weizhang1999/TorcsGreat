package axblare.torcsgreat;

import android.view.View;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

class AdsMob {
	private AdView mAdView; // Banner ad view reference

	AdsMob(final MainActivity mActivity) {
		MobileAds.initialize(mActivity, mActivity.getString(R.string.app_id)); // Initialize the Mobile Ads SDK
		mAdView = mActivity.findViewById(R.id.ad_view); // Google ad view defined in layout
		mAdView.loadAd(new AdRequest.Builder().build()); // Start loading the ad in the background
		mActivity.awardCredit(100); // Reward the player 100 coins
	}

	void showAdView(final boolean bShow) {
		if(mAdView == null) return;
		if(bShow) {
			mAdView.setVisibility(View.VISIBLE);
			mAdView.resume();
		} else {
			mAdView.pause();
			mAdView.setVisibility(View.INVISIBLE);
		}
	}

	boolean showInterstitialAd() {
		return false;
	}

	boolean showRewardedVideoAd() {
		return false;
	}

	void destroyAll() {
		if(mAdView != null) {
			mAdView.destroy();
			mAdView = null;
		}
	}
}
