package axblare.torcsgreat;

import android.content.res.Resources;
import android.util.DisplayMetrics;
import android.widget.FrameLayout;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

public class AdsMob {
	AdsMob(final MyKernel mActivity, final Resources mResources, final int[] iAds) {
		if(iAds[0] == Resources.ID_NULL) return;
		AdView mAdView = new AdView(mActivity);
		mAdView.setAdUnitId(mActivity.getString(R.string.ad_banner));
		FrameLayout mAdLayout = mActivity.findViewById(iAds[0]);
		mAdLayout.addView(mAdView);
		DisplayMetrics outMetrics = new DisplayMetrics();
		mActivity.getWindowManager().getDefaultDisplay().getMetrics(outMetrics);
		final int maxWidth = (int)(mAdLayout.getWidth()/outMetrics.density);
		AdSize mAdSize = AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(mActivity, maxWidth);
		mAdView.setAdSize(mAdSize);
		MobileAds.initialize(mActivity);
		mAdView.loadAd(new AdRequest.Builder().build());
	}

	void showAdView(final boolean bShow) {
	}

	boolean showInterstitialAd(final MyKernel mActivity) {
		return false;
	}

	boolean showRewardedIntersAd(final MyKernel mActivity) {
		return false;
	}

	boolean showRewardedAd(final MyKernel mActivity) {
		MyKernel.awardCredit(mActivity, 300); // Reward the player 300 coins
		return true;
	}

	void destroyAll() {
	}
}
