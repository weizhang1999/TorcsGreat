package axblare.torcsgreat;

import android.opengl.EGL14;
import android.opengl.GLSurfaceView;
import android.util.Log;

import java.util.Arrays;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLDisplay;

class MyConfig implements GLSurfaceView.EGLConfigChooser {
	private static final String mLogTag = "LogTag"; // String id for logcat
	private static final int iDebug = 0; // Debug level (larger for more info)

	@Override
	public EGLConfig chooseConfig(EGL10 egl10, EGLDisplay eglDisplay) {
		EGLConfig[] eglConfigs = new EGLConfig[1];
		int[] configCounts = new int[1];
		int[] configSpecs = {
				EGL10.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, // Support creating OpenGL ES 2.0 contexts
				EGL10.EGL_SAMPLE_BUFFERS, 1, // Currently operation with more than one multisample buffer is undefined
				EGL10.EGL_SAMPLES, 4, // This is for 4x MSAA using rotated grid multisampling with negligible performance loss
				EGL10.EGL_RED_SIZE, 8, EGL10.EGL_GREEN_SIZE, 8, EGL10.EGL_BLUE_SIZE, 8, EGL10.EGL_ALPHA_SIZE, 8, // RGBA components
				EGL10.EGL_DEPTH_SIZE, 24, EGL10.EGL_STENCIL_SIZE, 8, // Depth (24 bits) and stencil (8 bits)
				EGL10.EGL_NONE}; // End of array
		egl10.eglChooseConfig(eglDisplay, configSpecs, eglConfigs, 1, configCounts);

		if(configCounts[0] > 0) {
			if(iDebug > 0) Log.d(mLogTag, "Multisampling has been enabled");
			return eglConfigs[0];
		} else { // No normal multisampling config was found
			if(iDebug > 0) Log.e(mLogTag, "Multisampling is not available"); // Start from index 6 without multisampling
			egl10.eglChooseConfig(eglDisplay, Arrays.copyOfRange(configSpecs, 6, configSpecs.length), eglConfigs, 1, configCounts);
			return configCounts[0] > 0 ? eglConfigs[0] : null;
		}
	}
}
