/////////////////////////////////////////////////////////////////////////////
//                                                                         //
//   Torcs Great is an Android port of the famous open source game TORCS   //
//   Copyright (c) 2019-2020, Wei Zhang <mailto:weizhang1999@gmail.com>.   //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
//
// See the original TORCS game at <https://sourceforge.net/projects/torcs/>.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

package axblare.torcsgreat;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;

import com.google.android.play.core.assetpacks.AssetPackLocation;
import com.google.android.play.core.assetpacks.AssetPackManager;
import com.google.android.play.core.assetpacks.AssetPackManagerFactory;
import com.google.android.play.core.assetpacks.model.AssetPackStatus;
import com.hzy.lib7z.IExtractCallback;
import com.hzy.lib7z.Z7Extractor;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.ReadableByteChannel;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import androidx.annotation.NonNull;
import androidx.core.app.JobIntentService;
import androidx.preference.PreferenceManager;

import static android.app.Activity.*;

public class MySettings extends JobIntentService {
	private static final String mLogTag = "LogTag"; // String id for logcat
	private static final int iDebug = 0; // Debug level (larger for more info)
	private static final String KEY_PLAYER_RACES = "PLAYER_RACES";
	private static final String KEY_PLAYER_KILOS = "PLAYER_KILOS";
	private static final String KEY_PLAYER_COINS = "PLAYER_COINS";
	private static final String KEY_ASSETS_PACKS = "ASSETS_PACKS";
	private static final String KEY_CAMERA_MODES = "CAMERA_MODES";
	private static final String KEY_SOUND_EFFECT = "SOUND_EFFECT";
	private static final String KEY_MUSIC_EFFECT = "MUSIC_EFFECT";
	private static final String KEY_VOICE_EFFECT = "VOICE_EFFECT";
	static int iPlayerRaces = 0; // Races the player has completed
	static float fPlayerKilos = 0; // Kilos the player has accumulated
	static long lPlayerCoins = 0; // Coins the player has (current balance)
	static int iAssetsPacks = 4; // Number of asset packs requested by player
	static int iCameraModes = 0; // Current camera view mode range of [0, 4]
	static boolean bSoundEffect = true; // Sound effect is on
	static boolean bMusicEffect = true; // Music effect is on
	static boolean bVoiceEffect = true; // Voice effect is on
	static boolean bDialogBox = false; // Dialog window is shown (settings)

	private static final String[] mAssetPacks = {"pack0", "pack1", "pack2", "pack3"}; // Asset packs
	private static final String[] mAssetFiles = {"Asset0.7z", "Asset1.7z", "Asset2.7z", "Asset3.7z"}; // Asset files
	private static final long[] lPackedSize = {25640988, 25673676, 25058764, 24637686}; // Size of the packed game asset data
	private static final long[] lAssetUnzip = {82023016, 87152094, 60244663, 38848999}; // Uncompressed game asset data size
	private static final long[] lDownloaded = {0, 0, 0, 0}; // Size of the packed game asset data that have been downloaded
	private static final boolean[] bDownloaded = new boolean[mAssetPacks.length]; // Asset pack download has been finished
	private static long lTotalSize = 0; // Size of the packed game asset data to be downloaded 96.3 MB (101,011,114 bytes)
	private static long lUnzipSize = 0; // Uncompressed game asset data total size 255 MB (268,268,772 bytes)
	private static long lUnzipped = 0; // Size of the packed game asset data that have been unzipped
	static final String mSubDir = "results/"; // Sub dir name for the download and history data
	static final String[] mRaces = {"champ", "dtmrace", "endrace", "ncrace", "practice", "quickrace"}; // Race type folder names
	static final int[] iRaces = {R.raw.champ, R.raw.dtmrace, R.raw.endrace, R.raw.ncrace, R.raw.practice, R.raw.quickrace}; // Race type ids
	static String mAppDir; // Absolute path where the application can place its game assets
	static String mSrcDir; // Source directory (where the downloaded data files are saved)
	static String mErrMsg; // Error message for downloading and unzipping the game assets
	static Resources mResources; // Resources manager for language patch

	static final String bFetching = "bFetching"; // Game data file is downloading
	static final String bUnzipping = "bUnzipping"; // Game data file is unzipping

	static AssetPackManager assetPackManager; // Manage downloads of asset packs
	static boolean waitForWifiConfirmationShown;

	static void loadPersistData(final MyKernel mActivity) {
		SharedPreferences mPreference = PreferenceManager.getDefaultSharedPreferences(mActivity);
		iPlayerRaces = mPreference.getInt(KEY_PLAYER_RACES, iPlayerRaces);
		fPlayerKilos = mPreference.getFloat(KEY_PLAYER_KILOS, fPlayerKilos);
		lPlayerCoins = mPreference.getLong(KEY_PLAYER_COINS, lPlayerCoins);
		iAssetsPacks = mPreference.getInt(KEY_ASSETS_PACKS, iAssetsPacks);
		iCameraModes = mPreference.getInt(KEY_CAMERA_MODES, iCameraModes);
		bSoundEffect = mPreference.getBoolean(KEY_SOUND_EFFECT, bSoundEffect);
		bMusicEffect = mPreference.getBoolean(KEY_MUSIC_EFFECT, bMusicEffect);
		bVoiceEffect = mPreference.getBoolean(KEY_VOICE_EFFECT, bVoiceEffect);
		MyKernel.setCameraView(iCameraModes);
		MyKernel.EnableSound(bSoundEffect);
	}

	static void savePersistData(final MyKernel mActivity) {
		SharedPreferences.Editor mEditor = PreferenceManager.getDefaultSharedPreferences(mActivity).edit();
		mEditor.putInt(KEY_PLAYER_RACES, iPlayerRaces);
		mEditor.putFloat(KEY_PLAYER_KILOS, fPlayerKilos);
		mEditor.putLong(KEY_PLAYER_COINS, lPlayerCoins);
		mEditor.putInt(KEY_ASSETS_PACKS, iAssetsPacks);
		mEditor.putInt(KEY_CAMERA_MODES, iCameraModes);
		mEditor.putBoolean(KEY_SOUND_EFFECT, bSoundEffect);
		mEditor.putBoolean(KEY_MUSIC_EFFECT, bMusicEffect);
		mEditor.putBoolean(KEY_VOICE_EFFECT, bVoiceEffect);
		mEditor.apply(); // Save current settings
		MyKernel.EnableSound(bSoundEffect);
	}

	private static void deleteRecursive(File mFile) {
		if(mFile.isDirectory()) {
			for(File child : Objects.requireNonNull(mFile.listFiles()))
				deleteRecursive(child);
		}
		mFile.delete();
	}

	private static void makeSubDir(final String mSubDir) {
		File mFile = new File(mSrcDir, mSubDir);
		try {
			if(!mFile.exists() || !mFile.isDirectory()) mFile.mkdir();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	static void setGameDirs(final Context mContext) {
		assetPackManager = AssetPackManagerFactory.getInstance(mContext);
		mAppDir = mContext.getExternalFilesDir(null)+"/";
		mSrcDir = mAppDir+mSubDir;
		for(String child : mRaces) {
			deleteRecursive(new File(mSrcDir, child));
		}
		createSaveDirs();
		clearFileFlags();
	}

	private static void isNotDir(final String mName) {
		if(mName == null) return;
		File mFile = new File(mName);
		final boolean bAbsent = !mFile.exists() || !mFile.isDirectory();
		try {
			if(bAbsent) mFile.mkdir();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	private static void createSaveDirs() {
		if(iDebug > 0) Log.d(mLogTag, "App folder: "+mAppDir); // List data folder
		isNotDir(mSrcDir);
		for(String child : mRaces) {
			makeSubDir(child);
		}
	}

	private static void clearFileFlags() {
		if(iDebug > 0) Log.e(mLogTag, "Clearing useless files");
		setFalse(bFetching);
		setFalse(bUnzipping);
	}

	static boolean isUnzipped() {
		for(int i = 0; i < iAssetsPacks; i++) {
			if(!isTrue(mAssetFiles[i])) return false;
		}
		return true;
	}

	static boolean isDownloaded() {
		if(assetPackManager == null) return false;
		for(int i = 0; i < iAssetsPacks; i++) {
			if(isTrue(mAssetFiles[i])) continue; // Asset pack has been unzipped and may be deleted already
			AssetPackLocation assetPackPath = assetPackManager.getPackLocation(mAssetPacks[i]);
			if(assetPackPath == null || assetPackPath.assetsPath() == null || !bDownloaded[i]) return false;
		}
		return true;
	}

	static boolean isTrue(final String mBoolean) {
		return new File(mAppDir, mBoolean).exists();
	}

	static void setTrue(final String mBoolean) {
		try {
			new File(mAppDir, mBoolean).createNewFile();
		} catch(IOException e) {
			e.printStackTrace();
		}
	}

	static void setFalse(final String mBoolean) {
		File mFile = new File(mAppDir, mBoolean);
		if(mFile.exists()) mFile.delete();
	}

	static void startDownload(final MyKernel mActivity) {
		createSaveDirs(); // Make path available for downloading zip file
		List<String> packNames = new ArrayList<>();
		for(int i = 0; i < iAssetsPacks; i++) {
			if(iDebug > 0) Log.d(mLogTag, "Downloading "+mAssetFiles[i]);
			packNames.add(mAssetPacks[i]);
			lTotalSize += lPackedSize[i];
			lUnzipSize += lAssetUnzip[i];
		}
		if(packNames.isEmpty()) return;
		try {
			assetPackManager.registerListener(assetPackState->{
				switch(assetPackState.status()) {
					case AssetPackStatus.PENDING:
						mErrMsg = "Pending";
						break;

					case AssetPackStatus.DOWNLOADING:
						for(int i = 0; i < iAssetsPacks; i++) {
							if(mAssetPacks[i].equals(assetPackState.name())) {
								lDownloaded[i] = assetPackState.bytesDownloaded();
								break;
							}
						}
						mErrMsg = null;
						break;

					case AssetPackStatus.TRANSFERRING:
						// 100% downloaded and assets are being transferred.
						// Notify user to wait until transfer is complete.
						Log.i(mLogTag, "Transferring");
						break;

					case AssetPackStatus.COMPLETED:
						// Asset pack is ready to use. Start the game.
						for(int i = 0; i < iAssetsPacks; i++) {
							if(mAssetPacks[i].equals(assetPackState.name())) {
								bDownloaded[i] = true;
								break;
							}
						}
						Log.i(mLogTag, "Completed");
						mErrMsg = null;
						break;

					case AssetPackStatus.FAILED:
						// Request failed. Notify user.
						mErrMsg = "errorCode="+assetPackState.errorCode();
						Log.e(mLogTag, mErrMsg);
						break;

					case AssetPackStatus.CANCELED:
						// Request canceled. Notify user.
						mErrMsg = "Canceled";
						break;

					case AssetPackStatus.WAITING_FOR_WIFI:
						if(!waitForWifiConfirmationShown) {
							assetPackManager.showCellularDataConfirmation(mActivity).addOnSuccessListener(resultCode->{
								if(resultCode == RESULT_OK) {
									Log.d(mLogTag, "Confirmation dialog has been accepted.");
								} else if(resultCode == RESULT_CANCELED) {
									Log.d(mLogTag, "Confirmation dialog has been denied by the user.");
								}
							});
							waitForWifiConfirmationShown = true;
						}
						mErrMsg = "Waiting for wifi";
						break;

					case AssetPackStatus.NOT_INSTALLED:
						// Asset pack is not downloaded yet.
						mErrMsg = "Not installed";
						break;
					case AssetPackStatus.UNKNOWN:
						mErrMsg = "Unknown error";
						break;
				}
			});
			assetPackManager.fetch(packNames);
			assetPackManager.getPackStates(packNames).addOnFailureListener(e->mErrMsg = mResources.getString(R.string.asset_fetch));
		} catch(Exception e) {
			mErrMsg = mResources.getString(R.string.asset_fetch);
			e.printStackTrace();
		}
	}

	static int downloadedPercent() {
		long lDownloads = 0;
		for(int i = 0; i < iAssetsPacks; i++) {
			lDownloads += lDownloaded[i];
		}
		if(lTotalSize <= 0) return 0;
		final int iPercent = (int)((lDownloads*100L)/lTotalSize);
		return Math.min(iPercent, 100);
	}

	static int unzippedPercent() {
		if(lUnzipSize <= 0) return 0;
		final int iPercent = (int)(lUnzipped*100L/lUnzipSize);
		return Math.min(iPercent, 100); // Avoid wrong information
	}

	private static void copyFile(final String mTarget, final int iPatch) throws IOException {
		try(InputStream is = mResources.openRawResource(iPatch)) {
			ReadableByteChannel src = Channels.newChannel(is);
			FileChannel dst = new FileOutputStream(mTarget, false).getChannel();
			dst.transferFrom(src, 0, is.available());
			src.close();
			dst.close();
		}
	}

	static void copyGameFiles() {
		if(iDebug > 0) Log.e(mLogTag, "copyGameFiles...");
		try {
			final String mRaceMan = mAppDir+"config/raceman/";
			for(int i = 0; i < mRaces.length; i++) {
				copyFile(mRaceMan+mRaces[i]+".xml", iRaces[i]); // Need to replace config files when asset pack changed
			}
		} catch(IOException|NullPointerException e) {
			e.printStackTrace();
		}
		SystemClock.sleep(2000); // Wait 2000 ms after copying files
	}

	@Override
	protected void onHandleWork(@NonNull Intent intent) {
		if(iDebug > 0) Log.e(mLogTag, "JobIntentService unzipping: iAssetsPacks = "+iAssetsPacks);
		assetPackManager.clearListeners();
		lUnzipped = 0; // Reset the unzipped data size
		for(int i = 0; i < iAssetsPacks; i++) {
			final String mAssetPack = mAssetPacks[i];
			AssetPackLocation assetPackPath = assetPackManager.getPackLocation(mAssetPack);
			if(assetPackPath == null) return; // Asset pack is not ready
			final String mAssetFile = mAssetFiles[i];
			Z7Extractor.extractFile(assetPackPath.assetsPath()+"/"+mAssetFile, mAppDir, new IExtractCallback() { // Add slash separator
				@Override
				public void onStart() {
					if(iDebug > 0) Log.e(mLogTag, "Z7Extractor.extractFile starting "+mAssetFile);
				}

				@Override
				public void onGetFileNum(int fileNum) {
					if(iDebug > 0) Log.i(mLogTag, "Z7Extractor.extractFile fileNum "+fileNum);
				}

				@Override
				public void onProgress(String name, long size) {
					if(size > 0) lUnzipped += size; // Update progress
				}

				@Override
				public void onError(int errorCode, String message) {
					mErrMsg = "Unzip error: "+message;
					if(iDebug > 0) Log.e(mLogTag, mErrMsg);
				}

				@Override
				public void onSucceed() {
					if(iDebug > 0) Log.i(mLogTag, "Z7Extractor.extractFile finished "+mAssetFile);
					setTrue(mAssetFile); // Create an empty file to notify ready to go (before removing asset pack)
					new Handler(Looper.getMainLooper()).postDelayed(()->{
						assetPackManager.removePack(mAssetPack); // Remove the pack file not needed anymore
						if(iDebug > 0) Log.i(mLogTag, "JobIntentService finished "+mAssetPack+" lUnzipped = "+lUnzipped);
					}, 2000); // Wait 2000 ms after unzipping files (to give the loop handler enough time to respond)
				}
			});
		}
		copyGameFiles();
		clearFileFlags();
		createSaveDirs(); // Make dirs available
		if(iDebug > 0) Log.i(mLogTag, "JobIntentService finished: lUnzipped = "+lUnzipped);
	}
}
